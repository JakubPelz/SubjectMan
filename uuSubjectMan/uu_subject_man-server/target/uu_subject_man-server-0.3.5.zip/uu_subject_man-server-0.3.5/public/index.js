/*!
 * UAF COMMERCIAL LICENSE
 * ----------------------
 * 1. PREAMBLE and Definitions
 *   1.1 These UAF Commercial License Terms ("UAF CLT") govern licensing of the Unicorn Application Framework (UAF).
 *     The Customer and Unicorn concluded an agreement for the provision of Solution that is using UAF or its parts
 *     (the "Agreement").
 *   1.2 The provisions of these UAF CLT shall govern the relationship between the Customer and Unicorn regarding
 *     the UAF License granted under the Agreement. For the avoidance of doubt, in case of any conflict between these
 *     UAF CLT and the Agreement, the provisions of the Agreement always prevail.
 *   1.3 The "UAF Components", and each of them individually as "UAF Component", shall mean the components of the Unicorn
 *     Application Framework, which are listed and described in the Attachment I to these UAF CLT.
 *   1.4 "UAF" shall mean the Unicorn Application Framework the scope of which is described in Attachment I, including all
 *     associated documentation and preparatory design materials, in particular blueprints, models, user manuals,
 *     training materials, comprehensive instructions and guidelines for drafting, production, operation and maintenance of
 *     software solutions, reference architecture, ready-made components and tools, use cases and tutorials.
 *   1.5 The "Knowledge Base" shall mean the online materials, internet fora and other resources made available by Unicorn
 *     online with regard to the UAF, intended for the broad customer and developer community.
 *   1.6 The "License" shall mean the binding terms and conditions for use of the UAF by the Customer. The License is
 *     described in Clause 2 and may be further specified or modified by the Agreement.
 *   1.7 The "Solution" shall mean any product or service developed under the Agreement using the UAF or any of
 *     UAF Components or its other parts, further specified in the Agreement.
 * 2. LICENSE GRANT
 *   2.1 The Customer shall be hereby granted a non-exclusive and non-transferable worldwide license to use the UAF for
 *     the purpose of the Solution described in the Agreement. For this purpose, the Customer shall be entitled to modify
 *     the UAF and create derivative works based on the UAF.
 *   2.2 The Customer is entitled to grant third parties a sub-license allowing them to use the UAF or any derivative works
 *     based on the UAF under commercial terms of its choice, provided that:
 *     2.2.1 use of the UAF and any derivative works based on the UAF by third parties is limited to testing, handover and
 *       operation of the Solution or its use as a service,
 *     2.2.2 third parties are not entitled to use the UAF or any derivative works based on the UAF independently of
 *       the Solution,
 *     2.2.3 third parties are not provided access to source code of the UAF unless such right is granted by the Agreement
 *       or if they conclude a commercial license agreement with Unicorn.
 *   2.3 The Solution or its parts based on the UAF shall bear a prominent copyright notice "Based on Unicorn Application
 *     Framework Copyright (c) Unicorn" integrated
 *     2.3.1 in the graphical user interface of the Solution or its relevant part or
 *     2.3.2 in accompanying file if the Solution or its relevant part do not have graphical user interface or
 *     2.3.3 in Solution's documentation.
 *   2.4 The License shall be valid for the whole duration of copyright to the UAF, unless other duration of the License is
 *     specified in the Agreement.
 *   2.5 The Customer is entitled to access the Knowledge Base only if expressly agreed in the Agreement.
 *   2.6 The Unicorn retains all rights to the UAF not covered by the provisions of this Clause 2. Unless explicitly
 *     permitted by applicable law, the Customer may not use the UAF in any other way than provided by the provisions of
 *     this Clause 2 and may not allow such use on its behalf by any of its employees or agents.
 *   2.7 The price for the License is included in the price stipulated in the Agreement.
 * 3. MODIFICATIONS
 *   3.1 The Customer explicitly acknowledges that the UAF is under continuous development and any UAF Component or other
 *     part of the UAF may be modified, replaced or removed by the Unicorn from the UAF in any of its future versions.
 *   3.2 This License covers also any new version of UAF if some parts of the UAF are modified or replaced.
 *   3.3 If any part of the UAF is removed by Unicorn in any of its future versions, the License for such version of
 *     the UAF is reduced appropriately and covers only the remaining parts of UAF. Sub-licenses previously granted to
 *     third parties in accordance with Clause 2.2 remain unaffected.
 * 4. THIRD PARTY LICENSE TERMS
 *   4.1 UAF is using third party software tools (the "Third Party Software") that is an integral part of the UAF. Some of
 *     these tools are free software or open-source SW.
 *   4.2 The list of Third Party Software used in the UAF including its license terms and authors is provided as part of
 *     Attachment I to these UAF CLT.
 *   4.3 For the use of the above mentioned Third Party Software, the Customer acknowledges its license terms referred to
 *     in Attachment I to these UAF CLT.
 * 5. NO TRADEMARK OR PATENT LICENSE
 *   5.1 These UAF CLT cover only copyright use of the UAF. If not expressly agreed otherwise, the Customer shall not be
 *     granted any trademark and/or patent license here under and nothing in these UAF CLT shall be interpreted in a way it
 *     does so.
 * 6. LIMITED WARRANTY
 *   6.1 IF NOT STIPULATED OTHER WISE OR REQUIRED BY APPLICABLE LAW, THE UAF IS PROVIDED ON "AS IS" BASIS,
 *     WITH NO WARRANTY OF, INCLUDING WITHOUT LIMITATION, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE ENTIRE
 *     RISK AS TO THE QUALITY AND PERFORMANCE OF THE UAF IS CARRIED SOLELY BY THE CUSTOMER, UNLESS OTHERWISE AGREED BETWEEN
 *     THE UNICORN AND THE CUSTOMER IN THE AGREEMENT.
 * 7. LIMITATION OF LIABILITY
 *   7.1 TO THE EXTENT PERMITTED BY APPLICABLE LAW, THE UNICORN WILL NOT BE HELD LIABLE FOR ANY DAMAGES CAUSED BY
 *     THE DISTRIBUTION OR USE OF THE UAF. THIS ALSO INCLUDES ANY CONSEQUENTIAL AND/OR INCIDENTAL DAMAGES, MONETARY OR NOT,
 *     THAT ARE CONNECTED WITH THE DISTRIBUTION OR USE OF THE UAF, UNLESS OTHERWISE AGREED BETWEEN THE UNICORN AND
 *     THE CUSTOMER IN THE AGREEMENT.
 * 8. THIRD PARTY CLAIMS
 *   8.1 The Unicorn will defend or settle, at its option and expense, any action brought against the Customer in a member
 *     state of the European Union which concerns an allegation that the UAF provided infringes a patent or copyright or
 *     misappropriates a trade secret in such jurisdiction. The Unicorn shall pay costs and damages finally awarded against
 *     the Customer that are attributable to such action. The Customer declares to understand and agrees that following
 *     conditions must be fulfilled in order to make Unicorn's obligations under this Clause 8 effective and enforceable:
 *     The Customer must (a) notify Unicorn promptly in writing of the action or any reasonable threat of it,
 *     (b) provide the Unicorn with all reasonable information and assistance it will request to settle or defend the action, and
 *     (c) grant the Unicorn sole authority and control of the defense or settlement of the action.
 *   8.2 If a claim is made under Clause 8.1 the Unicorn may, at its sole option and expense:
 *     (a) replace or modify the UAF so that it becomes non-infringing,
 *     (b) procure for the Customer the right to continue using the UAF unmodified.
 *   8.3 The Unicorn shall not be held liable to the Customer if the action is based on:
 *     (a) the combination of UAF with any product not provided by Unicorn,
 *     (b) the modification of the UAF other than by Unicorn,
 *     (c) the use of other than a current unaltered release of the UAF,
 *     (d) a product that the Customer makes, uses, or sells,
 *     (e) infringement by the Customer that is deemed willful. In the case under (e) the Customer shall reimburse
 *     the Unicorn for its reasonable attorney fees and other costs related to the action.
 *   8.4 THIS CLAUSE IS SUBJECT TO CLAUSE 7 AND STATES UNICORN'S ENTIRE LIABILITY, CUSTOMER'S SOLE AND EXCLUSIVE REMEDY,
 *     FOR DEFENSE, SETTLEMENT AND DAMAGES, WITH RESPECT TO ANY ALLEGED PATENT OR COPYRIGHT INFRINGEMENT OR TRADE SECRET
 *     MISAPPROPRIATION BY ANY ITEM PROVIDED UNDER THESE TERMS, UNLESS OTHERWISE AGREEMENT BETWEEN UNICORN AND THE CUSTOMER
 *     IN THE AGREEMENT.
 * 9. GENERAL PROVISIONS
 *   9.1 By entering into the Agreement, the Customer signifies its assent to and acceptance of these UAF CLT.
 *   9.2 The License is effective from the moment of execution of the Agreement, if the Agreement does not specify later
 *     date. Where the provisions of the Agreement regarding the License and provisions of these UAF CLT differ, provisions
 *     of the Agreement shall prevail.
 *   9.3 If any provision of the Agreement regarding the License or these UAF CLT is held by a court of competent
 *     jurisdiction to be void, invalid, unenforceable or illegal, such provision shall be severed from the Agreement or
 *     these UAF CLT and the remaining provisions will remain in full force and effect.
 *   9.4 The provisions of Clauses 7 and 8 shall survive any expiration or termination of the Agreement.
 *   9.5 All rights and obligations between the Unicorn and the Customer arising on the basis of these UAF CLT or
 *     in connection with them are governed by the laws of the Czech Republic with the exclusion of both the rules on
 *     the conflict of laws and the United Nations Convention on Contracts for the International Sale of Goods (CISG).
 *   9.6 The resolution of all disputes arising from or connected here to shall be under sole jurisdiction of the courts of
 *     the Czech Republic.
 */
!function(e,t){
"object"==typeof exports&&"object"==typeof module?module.exports=t(require("uu5g04"),require("uu5g04-hooks"),require("uu5g04-bricks"),require("uu5tilesg02"),require("uu_plus4u5g01"),require("uu_plus4u5g01-app"),require("module"),require("uu_plus4u5g01-bricks"),require("uu_oidcg01"),require("react"),require("uu5g04-forms"),require("uu_territoryg01"),require("uu_territoryg01-artifactifc"),require("uu_contentkitg01")):"function"==typeof define&&define.amd?define("index",["uu5g04","uu5g04-hooks","uu5g04-bricks","uu5tilesg02","uu_plus4u5g01","uu_plus4u5g01-app","module","uu_plus4u5g01-bricks","uu_oidcg01","react","uu5g04-forms","uu_territoryg01","uu_territoryg01-artifactifc","uu_contentkitg01"],t):"object"==typeof exports?exports.index=t(require("uu5g04"),require("uu5g04-hooks"),require("uu5g04-bricks"),require("uu5tilesg02"),require("uu_plus4u5g01"),require("uu_plus4u5g01-app"),require("module"),require("uu_plus4u5g01-bricks"),require("uu_oidcg01"),require("react"),require("uu5g04-forms"),require("uu_territoryg01"),require("uu_territoryg01-artifactifc"),require("uu_contentkitg01")):e.index=t(e.uu5g04,e["uu5g04-hooks"],e["uu5g04-bricks"],e.uu5tilesg02,e.uu_plus4u5g01,e["uu_plus4u5g01-app"],e[void 0],e["uu_plus4u5g01-bricks"],e.uu_oidcg01,e.react,e["uu5g04-forms"],e.uu_territoryg01,e["uu_territoryg01-artifactifc"],e.uu_contentkitg01)
}(window,(function(e,t,n,r,o,a,c,i,l,u,s,m,d,p){return function(e){function t(t){for(var n,o,a=t[0],c=t[1],i=0,u=[];i<a.length;i++)o=a[i],
Object.prototype.hasOwnProperty.call(r,o)&&r[o]&&u.push(r[o][0]),r[o]=0;for(n in c)Object.prototype.hasOwnProperty.call(c,n)&&(e[n]=c[n]);for(l&&l(t);u.length;)u.shift()()}var n={},r={1:0}
;function o(t){if(n[t])return n[t].exports;var r=n[t]={i:t,l:!1,exports:{}};return e[t].call(r.exports,r,r.exports,o),r.l=!0,r.exports}o.e=function(e){var t=[],n=r[e];if(0!==n)if(n)t.push(n[2]);else{
var a=new Promise((function(t,o){n=r[e]=[t,o]}));t.push(n[2]=a);var c,i=document.createElement("script");i.charset="utf-8",i.timeout=120,o.nc&&i.setAttribute("nonce",o.nc),i.src=function(e){
return o.p+"chunks/index/"+e+"-219374b09929f89f4250.min.js"}(e),0!==i.src.indexOf(window.location.origin+"/")&&(i.crossOrigin="anonymous");var l=new Error;c=function(t){i.onerror=i.onload=null,
clearTimeout(u);var n=r[e];if(0!==n){if(n){var o=t&&("load"===t.type?"missing":t.type),a=t&&t.target&&t.target.src;l.message="Loading chunk "+e+" failed.\n("+o+": "+a+")",l.name="ChunkLoadError",
l.type=o,l.request=a,n[1](l)}r[e]=void 0}};var u=setTimeout((function(){c({type:"timeout",target:i})}),12e4);i.onerror=i.onload=c,document.head.appendChild(i)}return Promise.all(t)},o.m=e,o.c=n,
o.d=function(e,t,n){o.o(e,t)||Object.defineProperty(e,t,{enumerable:!0,get:n})},o.r=function(e){"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{
value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0})},o.t=function(e,t){if(1&t&&(e=o(e)),8&t)return e;if(4&t&&"object"==typeof e&&e&&e.__esModule)return e;var n=Object.create(null)
;if(o.r(n),Object.defineProperty(n,"default",{enumerable:!0,value:e}),2&t&&"string"!=typeof e)for(var r in e)o.d(n,r,function(t){return e[t]}.bind(null,r));return n},o.n=function(e){
var t=e&&e.__esModule?function(){return e.default}:function(){return e};return o.d(t,"a",t),t},o.o=function(e,t){return Object.prototype.hasOwnProperty.call(e,t)},o.p="",o.oe=function(e){
throw console.error(e),e};var a=window.__webpack_jsonp_uu_subject_man_hi_0_3_5_index=window.__webpack_jsonp_uu_subject_man_hi_0_3_5_index||[],c=a.push.bind(a);a.push=t,a=a.slice()
;for(var i=0;i<a.length;i++)t(a[i]);var l=c;return o(o.s=12)}([function(t,n){t.exports=e},function(e,n){e.exports=t},function(e,t,n){"use strict";var r=n(0),o=n.n(r),a=n(9);function c(e,t){
var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter((function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable}))),n.push.apply(n,r)}
return n}function i(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{};t%2?c(Object(n),!0).forEach((function(t){l(e,t,n[t])
})):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):c(Object(n)).forEach((function(t){Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(n,t))}))
}return e}function l(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}var u=a.a.TAG+"Core.";t.a=i(i({},a.a),{},{TAG:u,
Css:o.a.Common.Css.createCssModule(u.replace(/\.$/,"").toLowerCase().replace(/\./g,"-").replace(/[^a-z-]/g,""),"uu_subject_man-hi/uu_subject_man-hi@0.3.5")})},function(e,t,n){"use strict"
;var r=n(0),o=n.n(r),a=n(6),c=n.n(a);function i(e,t,n,r,o,a,c){try{var i=e[a](c),l=i.value}catch(e){return void n(e)}i.done?t(l):Promise.resolve(l).then(r,o)}function l(e){return function(){
var t=this,n=arguments;return new Promise((function(r,o){var a=e.apply(t,n);function c(e){i(a,r,o,c,l,"next",e)}function l(e){i(a,r,o,c,l,"throw",e)}c(void 0)}))}}var u={
APP_BASE_URI:location.protocol+"//"+location.host+o.a.Environment.getAppBasePath(),call:function(e,t,n,r){return l(regeneratorRuntime.mark((function o(){var a
;return regeneratorRuntime.wrap((function(o){for(;;)switch(o.prev=o.next){case 0:return o.next=2,c.a.Common.Calls.call(e,t,n,r);case 2:return a=o.sent,o.abrupt("return",a.data);case 4:case"end":
return o.stop()}}),o)})))()},loadDemoContent:function(e){var t=u.getCommandUri("loadDemoContent");return u.call("get",t,e)},loadIdentityProfiles:function(){
var e=u.getCommandUri("sys/uuAppWorkspace/initUve");return u.call("get",e,{})},initWorkspace:function(e){var t=u.getCommandUri("sys/uuAppWorkspace/init");return u.call("post",t,e)},
getWorkspace:function(){var e=u.getCommandUri("sys/uuAppWorkspace/get");return u.call("get",e,{})},initAndGetWorkspace:function(e){return l(regeneratorRuntime.mark((function t(){
return regeneratorRuntime.wrap((function(t){for(;;)switch(t.prev=t.next){case 0:return t.next=2,u.initWorkspace(e);case 2:return t.next=4,u.getWorkspace();case 4:return t.abrupt("return",t.sent)
;case 5:case"end":return t.stop()}}),t)})))()},loadStudyProgrammeInstance:function(e){var t=u.getCommandUri("sys/uuAppWorkspace/load");return u.call("get",t,e)},listStudyProgrammes:function(e){
return l(regeneratorRuntime.mark((function t(){var n,r;return regeneratorRuntime.wrap((function(t){for(;;)switch(t.prev=t.next){case 0:return n=u.getCommandUri("studyProgramme/list"),t.next=3,
u.call("get",n,e);case 3:return r=t.sent,t.abrupt("return",r);case 5:case"end":return t.stop()}}),t)})))()},getStudyProgramme:function(e){return l(regeneratorRuntime.mark((function t(){var n,r
;return regeneratorRuntime.wrap((function(t){for(;;)switch(t.prev=t.next){case 0:return n=u.getCommandUri("studyProgramme/get"),t.next=3,u.call("get",n,e);case 3:return r=t.sent,t.abrupt("return",r)
;case 5:case"end":return t.stop()}}),t)})))()},createStudyProgramme:function(e){return l(regeneratorRuntime.mark((function t(){var n,r;return regeneratorRuntime.wrap((function(t){
for(;;)switch(t.prev=t.next){case 0:return n=u.getCommandUri("studyProgramme/create"),t.next=3,u.call("post",n,e);case 3:return r=t.sent,t.abrupt("return",r);case 5:case"end":return t.stop()}}),t)
})))()},updateStudyProgramme:function(e){return l(regeneratorRuntime.mark((function t(){var n,r;return regeneratorRuntime.wrap((function(t){for(;;)switch(t.prev=t.next){case 0:
return n=u.getCommandUri("studyProgramme/update"),t.next=3,u.call("post",n,e);case 3:return r=t.sent,t.abrupt("return",r);case 5:case"end":return t.stop()}}),t)})))()},listSubjects:function(e){
return l(regeneratorRuntime.mark((function t(){var n,r;return regeneratorRuntime.wrap((function(t){for(;;)switch(t.prev=t.next){case 0:return n=u.getCommandUri("subject/list"),t.next=3,
u.call("get",n,e);case 3:return r=t.sent,t.abrupt("return",r);case 5:case"end":return t.stop()}}),t)})))()},listSubjectsByStudyProgramme:function(e){return l(regeneratorRuntime.mark((function t(){
var n,r;return regeneratorRuntime.wrap((function(t){for(;;)switch(t.prev=t.next){case 0:return n=u.getCommandUri("subject/listByStudyProgramme"),t.next=3,u.call("get",n,e);case 3:return r=t.sent,
t.abrupt("return",r);case 5:case"end":return t.stop()}}),t)})))()},getSubject:function(e){return l(regeneratorRuntime.mark((function t(){var n,r;return regeneratorRuntime.wrap((function(t){
for(;;)switch(t.prev=t.next){case 0:return n=u.getCommandUri("subject/get"),t.next=3,u.call("get",n,e);case 3:return r=t.sent,t.abrupt("return",r);case 5:case"end":return t.stop()}}),t)})))()},
createSubject:function(e){return l(regeneratorRuntime.mark((function t(){var n,r;return regeneratorRuntime.wrap((function(t){for(;;)switch(t.prev=t.next){case 0:
return n=u.getCommandUri("subject/create"),t.next=3,u.call("post",n,e);case 3:return r=t.sent,t.abrupt("return",r);case 5:case"end":return t.stop()}}),t)})))()},updateSubject:function(e){
return l(regeneratorRuntime.mark((function t(){var n,r;return regeneratorRuntime.wrap((function(t){for(;;)switch(t.prev=t.next){case 0:return n=u.getCommandUri("subject/update"),t.next=3,
u.call("post",n,e);case 3:return r=t.sent,t.abrupt("return",r);case 5:case"end":return t.stop()}}),t)})))()},asignSubject:function(e){return l(regeneratorRuntime.mark((function t(){var n,r
;return regeneratorRuntime.wrap((function(t){for(;;)switch(t.prev=t.next){case 0:return n=u.getCommandUri("subject/assignSubject"),t.next=3,u.call("post",n,e);case 3:return r=t.sent,
t.abrupt("return",r);case 5:case"end":return t.stop()}}),t)})))()},removeSubject:function(e){return l(regeneratorRuntime.mark((function t(){var n,r;return regeneratorRuntime.wrap((function(t){
for(;;)switch(t.prev=t.next){case 0:return n=u.getCommandUri("subject/removeSubject"),t.next=3,u.call("post",n,e);case 3:return r=t.sent,t.abrupt("return",r);case 5:case"end":return t.stop()}}),t)
})))()},listTopicsInSubject:function(e){return l(regeneratorRuntime.mark((function t(){var n,r;return regeneratorRuntime.wrap((function(t){for(;;)switch(t.prev=t.next){case 0:
return n=u.getCommandUri("topic/list"),t.next=3,u.call("get",n,e);case 3:return r=t.sent,t.abrupt("return",r);case 5:case"end":return t.stop()}}),t)})))()},addTopic:function(e){
return l(regeneratorRuntime.mark((function t(){var n,r;return regeneratorRuntime.wrap((function(t){for(;;)switch(t.prev=t.next){case 0:return n=u.getCommandUri("topic/create"),t.next=3,
u.call("post",n,e);case 3:return r=t.sent,t.abrupt("return",r);case 5:case"end":return t.stop()}}),t)})))()},addDigitalContent:function(e){return l(regeneratorRuntime.mark((function t(){var n,r
;return regeneratorRuntime.wrap((function(t){for(;;)switch(t.prev=t.next){case 0:return n=u.getCommandUri("topic/digitalContentAdd"),t.next=3,u.call("post",n,e);case 3:return r=t.sent,
t.abrupt("return",r);case 5:case"end":return t.stop()}}),t)})))()},removeDigitalContent:function(e){return l(regeneratorRuntime.mark((function t(){var n,r;return regeneratorRuntime.wrap((function(t){
for(;;)switch(t.prev=t.next){case 0:return n=u.getCommandUri("topic/digitalContentRemove"),t.next=3,u.call("post",n,e);case 3:return r=t.sent,t.abrupt("return",r);case 5:case"end":return t.stop()}
}),t)})))()},getCommandUri:function(e){return u.APP_BASE_URI+e.replace(/^\/+/,"")}};t.a=u},function(e,t){e.exports=n},function(e,t){e.exports=r},function(e,t){e.exports=o},function(e,t,n){"use strict"
;t.a={appName:{cs:"Aplikace uuSubject",en:"Application uuSubject"},left:{home:{cs:"Vítejte",en:"Welcome"},about:{cs:"O aplikaci",en:"About Application"},studyProgrammesList:{cs:"Studijní programy",
en:"Study programmes"},subjectsList:{cs:"Seznam předmětů",en:"Subjects list"}},about:{header:{cs:"O aplikaci uuSubject",en:"About application uuSubject"},creatorsHeader:{cs:"Tvůrci aplikace",
en:"Application creators"},termsOfUse:{cs:"Podmínky užívání",en:"Terms of use"}},bottom:{termsOfUse:{cs:"Podmínky užívání",en:"Terms of use"}},welcome:{cs:"Vítejte na stránkách aplikace uuSubjectMan",
en:"Welcome to uuSubjectManApplication"},auth:{welcome:{cs:"Vítejte",en:"Welcome"},intro:{
cs:'<uu5string/>Tato šablona obsahuje připravenou klientskou a serverovou část. Jednotlivé komponety, které jsou zde zobrazeny,\n          jsou určeny k tomu, aby demonstrovaly možnosti a způsob použití. Je vhodné je upravit, zkopírovat či smazat pro\n          potřeby vyvíjené aplikace. Více o struktuře uuApp se dozvíte v dokumetaci viz&nbsp;\n          <UU5.Bricks.Link\n            href="https://uuapp.plus4u.net/uu-bookkit-maing01/e884539c8511447a977c7ff070e7f2cf/book"\n            target="_blank"\n            content="uuAppDevKit"\n          />.',
en:'<uu5string/>This template consist of prepared client and server side. Shown components demonstrate possibilities and way of\n          using. For application developing purposes they are suitable for modifying, copying and deleting. More about\n          uuApp Structure see documentation&nbsp;\n          <UU5.Bricks.Link\n            href="https://uuapp.plus4u.net/uu-bookkit-maing01/e884539c8511447a977c7ff070e7f2cf/book/page?code=stepByStepApp"\n            target="_blank"\n            content="uuAppDevKit"\n          />.'
},clientSide:{cs:"<uu5string/>Klientská část je implementovaná s využitím komponent z knihoven <UU5.Bricks.LinkUU5 /> a <UU5.Bricks.LinkUuPlus4U5 />.",
en:"<uu5string/>Libraries <UU5.Bricks.LinkUU5/> and <UU5.Bricks.LinkUuPlus4U5 /> are used for developing of client side."},serverSide:{
cs:'<uu5string/>Pro spuštení serverové části je potřeba provést inicializaci workspace podle návodu viz\n          <UU5.Bricks.Link\n            href="https://uuapp.plus4u.net/uu-bookkit-maing01/e884539c8511447a977c7ff070e7f2cf/book/page?code=stepByStepApp"\n            target="_blank"\n            content="uuApp Template Developer Guide"\n          />.',
en:'<uu5string/>It is necessary to initialize application workspace for running server side. See manual\n          <UU5.Bricks.Link\n            href="https://uuapp.plus4u.net/uu-bookkit-maing01/e884539c8511447a977c7ff070e7f2cf/book/page?code=stepByStepApp"\n            target="_blank"\n            content="uuApp Template Developer Guide"\n          />.'
}},unauth:{welcome:{cs:"Vítej návštěvníku",en:"Welcome visitor"},continueToMain:{cs:"Pokračovat na web produktu",en:"Continue to the product web"},notAuthorized:{
cs:"Nemáte dostatečná práva k použití aplikace",en:"You do not have sufficient rights to use the application"}},unauthInit:{buyYourOwn:{cs:"Můžete si koupit vlastní uuSubject.",
en:"You can buy your own uuSubject."},notAuthorized:{cs:"Nemáte právo inicializovat tuto aplikaci uuSubject.",en:"You don't have rights to initialize this uuSubject."}},controlPanel:{rightsError:{
cs:"K zobrazení komponenty nemáte dostatečná práva.",en:"You do not have sufficient rights to display this component."},btNotConnected:{cs:"Aplikace není napojená na Business Territory",
en:"The application is not connected to a Business Territory"}}}},function(e,t,n){"use strict";var r=n(0),o=n.n(r),a=n(9);function c(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){
var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter((function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable}))),n.push.apply(n,r)}return n}function i(e){
for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{};t%2?c(Object(n),!0).forEach((function(t){l(e,t,n[t])
})):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):c(Object(n)).forEach((function(t){Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(n,t))}))
}return e}function l(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}var u=a.a.TAG+"Routes.";t.a=i(i({},a.a),{},{TAG:u,
Css:o.a.Common.Css.createCssModule(u.replace(/\.$/,"").toLowerCase().replace(/\./g,"-").replace(/[^a-z-]/g,""),"uu_subject_man-hi/uu_subject_man-hi@0.3.5")})},function(e,t,n){"use strict"
;var r=n(0),o=n.n(r),a="UuSubjectMan.";t.a={TAG:a,
Css:o.a.Common.Css.createCssModule(a.replace(/\.$/,"").toLowerCase().replace(/\./g,"-").replace(/[^a-z-]/g,""),"uu_subject_man-hi/uu_subject_man-hi@0.3.5"),
Profiles:["Authorities","Executives","AwidLicenseOwner","Public","Teachers","StudyDepartment","Student"]}},function(e,t){e.exports=a},function(e,t,n){"use strict";e.exports=n(17)},function(e,t,n){
e.exports=n(13)},function(e,t,n){function r(e){return(r="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(e){return typeof e}:function(e){
return e&&"function"==typeof Symbol&&e.constructor===Symbol&&e!==Symbol.prototype?"symbol":typeof e})(e)}
var o=n(14),a="undefined"!=typeof document,c=((o?o.uri:a&&(document.currentScript||Array.prototype.slice.call(document.getElementsByTagName("script"),-1)[0]||{}).src)||"").toString()
;"/0.0.0/"===(c=c.split(/\//).slice(0,-1).join("/")+"/").substr(-"/0.0.0/".length)&&(c=c.substr(0,c.length-"/0.0.0/".length)+"/0.3.5/"),n.p=c,e.exports=n(19);var i=e.exports
;i&&"object"===r(i)&&("version"in i||(i.version="0.3.5"),"name"in i||(i.name="uu_subject_man-hi".split(/[\/\\]/).pop()),"namespace"in i||(i.namespace="UuSubjectMan"))},function(e,t){e.exports=c
},function(e,t){e.exports=i},function(e,t){e.exports=l},function(e,t,n){"use strict";Object.defineProperty(t,"__esModule",{value:!0});var r,o=(r=n(18))&&"object"==typeof r&&"default"in r?r.default:r
;function a(e){return a.warnAboutHMRDisabled&&(a.warnAboutHMRDisabled=!0,console.error("React-Hot-Loader: misconfiguration detected, using production version in non-production environment."),
console.error("React-Hot-Loader: Hot Module Replacement is not enabled.")),o.Children.only(e.children)}a.warnAboutHMRDisabled=!1;var c=function e(){return e.shouldWrapWithAppContainer?function(e){
return function(t){return o.createElement(a,null,o.createElement(e,t))}}:function(e){return e}};c.shouldWrapWithAppContainer=!1;t.AppContainer=a,t.hot=c,t.areComponentsEqual=function(e,t){return e===t
},t.setConfig=function(){},t.cold=function(e){return e},t.configureComponent=function(){}},function(e,t){e.exports=u},function(e,t,n){"use strict";n.r(t),n.d(t,"render",(function(){return In}))
;var r=n(11),o=n(0),a=n.n(o),c=n(1),i=n(6),l=n.n(i),u=(n(10),n(2)),s=a.a.Common.Context.create(),m=n(3),d=n(9);function p(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){
var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter((function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable}))),n.push.apply(n,r)}return n}function f(e){
for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{};t%2?p(Object(n),!0).forEach((function(t){b(e,t,n[t])
})):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):p(Object(n)).forEach((function(t){Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(n,t))}))
}return e}function b(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}var g=d.a.TAG+"Bricks.",C=f(f({},d.a),{},{TAG:g,
Css:a.a.Common.Css.createCssModule(g.replace(/\.$/,"").toLowerCase().replace(/\./g,"-").replace(/[^a-z-]/g,""),"uu_subject_man-hi/uu_subject_man-hi@0.3.5")});function v(e,t,n,r,o,a,c){try{
var i=e[a](c),l=i.value}catch(e){return void n(e)}i.done?t(l):Promise.resolve(l).then(r,o)}function y(e){return function(){var t=this,n=arguments;return new Promise((function(r,o){var a=e.apply(t,n)
;function c(e){v(a,r,o,c,i,"next",e)}function i(e){v(a,r,o,c,i,"throw",e)}c(void 0)}))}}var h=Object(c.createComponent)({displayName:C.TAG+"JokeInstanceProvider",render:function(e){
var t=e.children,n=Object(c.useSession)();console.debug(n.session.isAuthenticated());var r=Object(c.useDataObject)({handlerMap:{load:function(){return o.apply(this,arguments)}}});function o(){
return(o=y(regeneratorRuntime.mark((function e(){var t;return regeneratorRuntime.wrap((function(e){for(;;)switch(e.prev=e.next){case 0:if(!n.session.isAuthenticated()){e.next=12;break}return e.next=3,
m.a.loadStudyProgrammeInstance();case 3:if(t=e.sent,console.debug(t.authorizedProfiles),!t.authorizedProfiles){e.next=9;break}return e.abrupt("return",{authorizedProfiles:t.authorizedProfiles})
;case 9:return e.abrupt("return",{authorizedProfiles:[]});case 10:e.next=13;break;case 12:return e.abrupt("return",{authorizedProfiles:[]});case 13:case"end":return e.stop()}}),e)
})))).apply(this,arguments)}return UU5.Common.Element.create(s.Provider,{value:r},t)}}),O=(n(4),n(7));function j(){return(j=Object.assign||function(e){for(var t=1;t<arguments.length;t++){
var n=arguments[t];for(var r in n)Object.prototype.hasOwnProperty.call(n,r)&&(e[r]=n[r])}return e}).apply(this,arguments)}function k(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){
var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter((function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable}))),n.push.apply(n,r)}return n}function E(e){
for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{};t%2?k(Object(n),!0).forEach((function(t){P(e,t,n[t])
})):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):k(Object(n)).forEach((function(t){Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(n,t))}))
}return e}function P(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}var w,S={displayName:u.a.TAG+"Left"
},B=Object(c.createVisualComponent)(E(E({},S),{},{render:function(e){return a.a.Common.Element.create(l.a.App.Left,j({},e,{logoProps:{backgroundColor:a.a.Environment.colors.blue.c700,
backgroundColorTo:a.a.Environment.colors.blue.c500,title:"uuSubjectMan",companyLogo:"../assets/index.png",generation:"2"},aboutItems:[{content:a.a.Common.Element.create(a.a.Bricks.Lsi,{
lsi:O.a.left.about}),href:"about"}],helpHref:null}),a.a.Common.Element.create(l.a.App.MenuTree,{borderBottom:!0,items:[{id:"home",href:"home",content:a.a.Common.Element.create(a.a.Bricks.Lsi,{
lsi:O.a.left.home})},{id:"studyProgrammes",href:"studyProgrammes",content:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:O.a.left.studyProgrammesList})},{id:"subjectsList",href:"subjectsList",
content:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:O.a.left.subjectsList})}]}))}}));function L(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e)
;t&&(r=r.filter((function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable}))),n.push.apply(n,r)}return n}function x(e){for(var t=1;t<arguments.length;t++){
var n=null!=arguments[t]?arguments[t]:{};t%2?L(Object(n),!0).forEach((function(t){D(e,t,n[t])
})):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):L(Object(n)).forEach((function(t){Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(n,t))}))
}return e}function D(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}var A,T,R,U,z={displayName:u.a.TAG+"Bottom"},F=function(){
return u.a.Css.css(w||(e=["\n    padding: 8px 0;\n    text-align: center;\n    border-top: 1px solid rgba(0, 0, 0, 0.12);\n    color: gray;\n  "],t||(t=e.slice(0)),
w=Object.freeze(Object.defineProperties(e,{raw:{value:Object.freeze(t)}}))));var e,t},N=Object(c.createVisualComponent)(x(x({},z),{},{render:function(e){
var t=a.a.Common.VisualComponent.getAttrs(e,F());return a.a.Common.Element.create("div",t,"uuSubjectMan-","0.3.5"," © Unicorn,"," ",a.a.Common.Element.create(a.a.Bricks.Link,{target:"_blank",
href:"TODO"},a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:O.a.bottom.termsOfUse})))}})),_=(n(15),n(16),n(8));function V(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){
var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter((function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable}))),n.push.apply(n,r)}return n}function M(e){
for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{};t%2?V(Object(n),!0).forEach((function(t){I(e,t,n[t])
})):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):V(Object(n)).forEach((function(t){Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(n,t))}))
}return e}function I(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}function q(e,t){return t||(t=e.slice(0)),
Object.freeze(Object.defineProperties(e,{raw:{value:Object.freeze(t)}}))}var W,G={displayName:C.TAG+"WelcomeRow"},H=function(){
return C.Css.css(A||(A=q(["\n    padding: 24px 0;\n    max-width: 624px;\n    margin: 0 auto;\n  "])))},Y=function(){
return C.Css.css(T||(T=q(["\n    text-align: center;\n\n    ","\n  "])),a.a.Utils.ScreenSize.getMinMediaQueries("s","text-align: left;"))},J=function(){
return C.Css.css(R||(R=q(["\n    padding-right: 24px;\n    text-align: center;\n  \n    ","\n  \n    .uu5-bricks-icon {\n      font-size: 48px;\n    }\n  "])),a.a.Utils.ScreenSize.getMinMediaQueries("s","text-align: right;"))
},K=function(e){return C.Css.css(U||(U=q(["\n    margin-top: ",";\n    margin-bottom: ",";\n  "])),e,e)},$=Object(c.createVisualComponent)(M(M({},G),{},{propTypes:{icon:a.a.PropTypes.string,
textPadding:a.a.PropTypes.string},defaultProps:{icon:void 0,textPadding:null},render:function(e){
var t=e.icon,n=e.textPadding,r=e.children,o=a.a.Common.Tools.fillUnit("-"+n),c=a.a.Common.VisualComponent.getAttrs(e,H())
;return a.a.Common.Element.create(a.a.Bricks.Row,c,a.a.Common.Element.create(a.a.Bricks.Column,{className:J(),colWidth:"xs-12 s-2"},a.a.Common.Element.create(a.a.Bricks.Icon,{icon:t,className:K(o)
})),a.a.Common.Element.create(a.a.Bricks.Column,{className:Y(),colWidth:"xs-12 s-10",content:a.a.Utils.Content.getChildren(r,e,G)}))}}));function Q(e,t){var n=Object.keys(e)
;if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter((function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable}))),n.push.apply(n,r)}return n}function Z(e){
for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{};t%2?Q(Object(n),!0).forEach((function(t){X(e,t,n[t])
})):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):Q(Object(n)).forEach((function(t){Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(n,t))}))
}return e}function X(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}var ee,te={displayName:_.a.TAG+"Home"},ne=function(){
return _.a.Css.css(W||(e=["\n    padding: 56px 0 20px;\n    max-width: 624px;\n    margin: 0 auto;\n    text-align: center;\n  \n    ","\n  \n    .uu5-bricks-header {\n      margin-top: 8px;\n    }\n    \n    .plus4u5-bricks-user-photo {\n      margin: 0 auto;\n    }\n  "],
t||(t=e.slice(0)),W=Object.freeze(Object.defineProperties(e,{raw:{value:Object.freeze(t)}}))),a.a.Utils.ScreenSize.getMinMediaQueries("s","text-align: left;"));var e,t
},re=Object(c.createVisualComponent)(Z(Z({},te),{},{render:function(e){var t=a.a.Common.VisualComponent.getAttrs(e)
;return a.a.Common.Element.create("div",t,a.a.Common.Element.create(l.a.App.ArtifactSetter,{territoryBaseUri:"",artifactId:""}),a.a.Common.Element.create(a.a.Bricks.Row,{className:ne()
},a.a.Common.Element.create(a.a.Bricks.Column,null,a.a.Common.Element.create(a.a.Bricks.Header,{level:"3",content:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:O.a.welcome})
}))),a.a.Common.Element.create(a.a.Bricks.Row,{className:ne()},a.a.Common.Element.create(a.a.Common.Identity,null,(function(e){var t=e.identity
;return t?a.a.Common.Element.create(a.a.Common.Fragment,null,a.a.Common.Element.create(a.a.Bricks.Column,{colWidth:"x-12 s-3"},a.a.Common.Element.create(l.a.Bricks.UserPhoto,{width:"100px"
})),a.a.Common.Element.create(a.a.Bricks.Column,{colWidth:"x-12 s-9"},a.a.Common.Element.create(a.a.Bricks.Header,{level:"2",content:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:O.a.auth.welcome})
}),a.a.Common.Element.create(a.a.Bricks.Header,{level:"2",content:null==t?void 0:t.name
}))):a.a.Common.Element.create(a.a.Common.Fragment,null,a.a.Common.Element.create(a.a.Bricks.Column,null,a.a.Common.Element.create(a.a.Bricks.Header,{level:"2",
content:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:O.a.unauth.welcome})}),a.a.Common.Element.create(a.a.Bricks.Header,{level:"2",content:null==t?void 0:t.name})))}))),a.a.Common.Element.create($,{
textPadding:"14px",icon:"mdi-human-greeting"},a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:O.a.auth.intro})),a.a.Common.Element.create($,{textPadding:"10px",icon:"mdi-monitor"
},a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:O.a.auth.clientSide})),a.a.Common.Element.create($,{textPadding:"8px",icon:"mdi-server"},a.a.Common.Element.create(a.a.Bricks.Lsi,{
lsi:O.a.auth.serverSide})))}})),oe={header:{cs:"Přídání studijního programu",en:"Add new study programme"},info:{cs:"Přídání studijního programu",en:"Add new study programme"},form:{name:{cs:"Název",
en:"Name"},description:{cs:"Popis",en:"Description"},degree:{bachelor:{cs:"Bakalářské",en:"Bachelor"},magister:{cs:"Magisterské",en:"Magister"},cs:"Stupeň vzdělání",en:"Degree"},form:{fullTime:{
cs:"Prezenční",en:"Full time"},partTime:{cs:"Distanční",en:"Part time"},cs:"Forma vyučování",en:"Form"},languages:{czech:{cs:"Česky",en:"Czech"},english:{cs:"Anglicky",en:"English"},
cs:"Vyučovací jazyk",en:"Language"},credits:{cs:"Počet kreditů za celé studium",en:"Credist per studium"}},submit:{cs:"Přidej",en:"Add"}},ae=Object(c.createVisualComponentWithRef)({
displayName:C.TAG+"StudyProgrammeAddForm",propTypes:{studyProgramme:a.a.PropTypes.object,onSave:a.a.PropTypes.func,onSaveDone:a.a.PropTypes.func,onSaveFail:a.a.PropTypes.func,
onCancel:a.a.PropTypes.func},defaultProps:{studyProgramme:null,onSave:function(){},onSaveDone:function(){},onSaveFail:function(){},onCancel:function(){}},render:function(e){
return a.a.Common.Element.create(a.a.Forms.Form,{onSave:e.onSave,onSaveDone:e.onSaveDone,onSaveFail:e.onSaveFail,onCancel:e.onCancel},a.a.Common.Element.create(a.a.Forms.Text,{
label:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:oe.form.name}),name:"name",value:null!=e&&e.studyProgramme?null==e?void 0:e.studyProgramme.name:void 0,inputAttrs:{maxLength:255},controlled:!1,
required:!0}),a.a.Common.Element.create(a.a.Forms.Text,{label:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:oe.form.description}),name:"description",
value:null!=e&&e.studyProgramme?null==e?void 0:e.studyProgramme.description:void 0,inputAttrs:{maxLength:255},controlled:!1}),a.a.Common.Element.create(a.a.Forms.Select,{
label:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:oe.form.degree}),name:"degree",value:null!=e&&e.studyProgramme?null==e?void 0:e.studyProgramme.degree:void 0,required:!0
},a.a.Common.Element.create(a.a.Forms.Select.Option,{value:"bachelor",content:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:oe.form.degree.bachelor})
}),a.a.Common.Element.create(a.a.Forms.Select.Option,{value:"magister",content:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:oe.form.degree.magister})})),a.a.Common.Element.create(a.a.Forms.Select,{
label:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:oe.form.form}),name:"forms",value:null!=e&&e.studyProgramme?null==e?void 0:e.studyProgramme.forms:void 0,required:!0
},a.a.Common.Element.create(a.a.Forms.Select.Option,{value:"full-time",content:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:oe.form.form.fullTime})
}),a.a.Common.Element.create(a.a.Forms.Select.Option,{value:"part-time",content:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:oe.form.form.partTime})})),a.a.Common.Element.create(a.a.Forms.Select,{
label:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:oe.form.languages}),name:"languages",value:null!=e&&e.studyProgramme?null==e?void 0:e.studyProgramme.languages:void 0,required:!0
},a.a.Common.Element.create(a.a.Forms.Select.Option,{value:"CZ",content:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:oe.form.languages.czech})}),a.a.Common.Element.create(a.a.Forms.Select.Option,{
value:"EN",content:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:oe.form.languages.english})})),a.a.Common.Element.create(a.a.Forms.Number,{label:a.a.Common.Element.create(a.a.Bricks.Lsi,{
lsi:oe.form.credits}),name:"credits",value:null!=e&&e.studyProgramme?null==e?void 0:e.studyProgramme.credits:void 0,min:0,max:300,step:1,valueType:"number",required:!0
}),a.a.Common.Element.create(a.a.Forms.Controls,{controlled:!1}))}}),ce=n(5),ie=n.n(ce),le={menuActions:{editProgramme:{cs:"Edituj stud. program",en:"Edit programme"}},tile:{header:{
cs:"Studijní program",en:"Study programme"},name:{cs:"Název: ",en:"Name: "},description:{cs:"Popis: ",en:"Descr.: "},form:{cs:"Forma: ",en:"Form: "},language:{cs:"Jazyk: ",en:"Lang.: "},degree:{
cs:"Stupeň vzdělání: ",en:"Study degree: "},created:{cs:"Vytvořeno: ",en:"Created: "}}},ue="Teachers",se="StudyCoordinators",me="Students";function de(e,t){var n=Object.keys(e)
;if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter((function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable}))),n.push.apply(n,r)}return n}
function pe(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{};t%2?de(Object(n),!0).forEach((function(t){fe(e,t,n[t])
})):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):de(Object(n)).forEach((function(t){Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(n,t))
}))}return e}function fe(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}var be,ge={displayName:"UU5.Bricks.VisualComponent",
nestingLevel:"bigBoxCollection"},Ce=Object(c.createVisualComponent)(pe(pe({},ge),{},{propTypes:{data:a.a.PropTypes.object,handleOpen:a.a.PropTypes.func,handleUpdate:a.a.PropTypes.func},defaultProps:{
data:null,handleOpen:function(){},handleUpdate:function(){}},render:function(e){var t,n,r,o,i,l,m,d,p,f=Object(c.useContext)(s).data.authorizedProfiles,b=u.a.Css.css(ee||(d=[""],p||(p=d.slice(0)),
ee=Object.freeze(Object.defineProperties(d,{raw:{value:Object.freeze(p)}
})))),g=a.a.Common.VisualComponent.getAttrs(e,b),C=a.a.Utils.NestingLevel.getNestingLevel(e,ge),v=a.a.Common.Element.create("div",g,a.a.Utils.Content.getChildren(e.children,e,ge))
;return C?a.a.Common.Element.create("div",g,a.a.Common.Element.create(a.a.BlockLayout.Tile,null,a.a.Common.Element.create(a.a.BlockLayout.Block,{actions:function(){
if(!0===a.a.Common.Tools.hasSomeProfiles(f,[se]))return[{icon:"mdi-pencil",content:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:le.menuActions.editProgramme}),onClick:function(){
return e.handleUpdate(e.data)}}]}()},a.a.Common.Element.create(a.a.BlockLayout.Row,null,a.a.Common.Element.create(a.a.Bricks.Link,null,a.a.Common.Element.create(a.a.BlockLayout.Text,{weight:"primary"
},a.a.Common.Element.create(a.a.Bricks.Link,{onClick:function(){return e.handleOpen(e.data.data)}
},null===(t=e.data.data)||void 0===t?void 0:t.name))))),a.a.Common.Element.create(a.a.BlockLayout.Line,null),a.a.Common.Element.create(a.a.BlockLayout.Block,null,a.a.Common.Element.create(a.a.BlockLayout.Row,null,a.a.Common.Element.create(a.a.Bricks.Row,null,a.a.Common.Element.create(a.a.Bricks.Column,{
colWidth:"xs-4"},a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:le.tile.name})),a.a.Common.Element.create(a.a.Bricks.Column,{colWidth:"xs-8"
},null===(n=e.data.data)||void 0===n?void 0:n.name))),a.a.Common.Element.create(a.a.BlockLayout.Row,null,a.a.Common.Element.create(a.a.Bricks.Row,null,a.a.Common.Element.create(a.a.Bricks.Column,{
colWidth:"xs-4"},a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:le.tile.description})),a.a.Common.Element.create(a.a.Bricks.Column,{colWidth:"xs-8"
},null===(r=e.data.data)||void 0===r?void 0:r.description))),a.a.Common.Element.create(a.a.BlockLayout.Row,null,a.a.Common.Element.create(a.a.Bricks.Row,null,a.a.Common.Element.create(a.a.Bricks.Column,{
colWidth:"xs-4"},a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:le.tile.form})),a.a.Common.Element.create(a.a.Bricks.Column,{colWidth:"xs-8"
},null===(o=e.data.data)||void 0===o?void 0:o.forms))),a.a.Common.Element.create(a.a.BlockLayout.Row,null,a.a.Common.Element.create(a.a.Bricks.Row,null,a.a.Common.Element.create(a.a.Bricks.Column,{
colWidth:"xs-4"},a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:le.tile.language})," "),a.a.Common.Element.create(a.a.Bricks.Column,{colWidth:"xs-8"
},null===(i=e.data.data)||void 0===i?void 0:i.languages))),a.a.Common.Element.create(a.a.BlockLayout.Row,null,a.a.Common.Element.create(a.a.Bricks.Row,null,a.a.Common.Element.create(a.a.Bricks.Column,{
colWidth:"xs-4"},a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:le.tile.degree})," "),a.a.Common.Element.create(a.a.Bricks.Column,{colWidth:"xs-8"
},null===(l=e.data.data)||void 0===l?void 0:l.degree))),a.a.Common.Element.create(a.a.BlockLayout.Row,null,a.a.Common.Element.create(a.a.Bricks.Row,null,a.a.Common.Element.create(a.a.Bricks.Column,{
colWidth:"xs-4"},a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:le.tile.created})),a.a.Common.Element.create(a.a.Bricks.Column,{colWidth:"xs-8"},a.a.Common.Element.create(a.a.Bricks.DateTime,{
timeZone:a.a.Environment.dateTimeZone,value:null===(m=e.data.data)||void 0===m?void 0:m.sys.cts}))))))):a.a.Common.Element.create(a.a.Bricks.LinkModal,{children:"Visual Component",hidden:e.hidden,
component:v})}}));function ve(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter((function(t){
return Object.getOwnPropertyDescriptor(e,t).enumerable}))),n.push.apply(n,r)}return n}function ye(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{}
;t%2?ve(Object(n),!0).forEach((function(t){he(e,t,n[t])})):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):ve(Object(n)).forEach((function(t){
Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(n,t))}))}return e}function he(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}
var Oe,je={displayName:"UU5.Bricks.VisualComponent",nestingLevel:"bigBoxCollection"},ke=Object(c.createVisualComponent)(ye(ye({},je),{},{propTypes:{data:a.a.PropTypes.array,
handleOpen:a.a.PropTypes.func,handleCreate:a.a.PropTypes.func,handleUpdate:a.a.PropTypes.func},defaultProps:{data:[],handleOpen:function(){},handleCreate:function(){},handleUpdate:function(){}},
render:function(e){Object(c.useRef)();var t,n,r,o=Object(c.useContext)(s).data.authorizedProfiles,i=u.a.Css.css(be||(n=[""],r||(r=n.slice(0)),be=Object.freeze(Object.defineProperties(n,{raw:{
value:Object.freeze(r)}
})))),l=a.a.Common.VisualComponent.getAttrs(e,i),m=a.a.Utils.NestingLevel.getNestingLevel(e,je),d=a.a.Common.Element.create("div",l,a.a.Utils.Content.getChildren(e.children,e,je))
;return m?a.a.Common.Element.create("div",l,a.a.Common.Element.create(ie.a.ControllerProvider,{data:e.data?e.data:[]
},!0===a.a.Common.Tools.hasSomeProfiles(o,[se])?a.a.Common.Element.create(ie.a.ActionBar,{title:"",actions:function(t){t.screenSize;return[{content:{en:"Add study programme",
cs:"Přidej studijní program"},onClick:function(){null==e||e.handleCreate()},icon:"mdi-plus-circle",colorSchema:"primary",bgStyle:"filled",active:!0}]}}):null,a.a.Common.Element.create(ie.a.Grid,{
tileMinWidth:200,tileMaxWidth:500,tileSpacing:8,rowSpacing:8},a.a.Common.Element.create(Ce,{key:null===(t=e.data)||void 0===t?void 0:t.id,handleOpen:e.handleOpen,handleUpdate:e.handleUpdate
})))):a.a.Common.Element.create(a.a.Bricks.LinkModal,{children:"Visual Component",hidden:e.hidden,component:d})}})),Ee={header:{cs:"Studijní programy",en:"Study programmes"},info:{
cs:"Přídání studijního programu",en:"Add new study programme"},modal:{header:{creation:{cs:"Vytvoření studijního programu",en:"Creation of study programme"},edit:{cs:"Editace studijního programu",
en:"Edit of study programme"}},onSaveDone:{creation:{cs:"Úspěšně vytvořeno",en:"Successfully created"},edit:{cs:"Úspěšně upraveno",en:"Successfully edited"}},onSaveFail:{creation:{
cs:"Chyba běhěm vytváření",en:"Error has occured during creation"},edit:{cs:"Chyba běhěm editace",en:"Error has occured during editing"}}}};function Pe(e,t,n,r,o,a,c){try{var i=e[a](c),l=i.value
}catch(e){return void n(e)}i.done?t(l):Promise.resolve(l).then(r,o)}function we(e){return function(){var t=this,n=arguments;return new Promise((function(r,o){var a=e.apply(t,n);function c(e){
Pe(a,r,o,c,i,"next",e)}function i(e){Pe(a,r,o,c,i,"throw",e)}c(void 0)}))}}function Se(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e)
;t&&(r=r.filter((function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable}))),n.push.apply(n,r)}return n}function Be(e){for(var t=1;t<arguments.length;t++){
var n=null!=arguments[t]?arguments[t]:{};t%2?Se(Object(n),!0).forEach((function(t){Le(e,t,n[t])
})):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):Se(Object(n)).forEach((function(t){Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(n,t))
}))}return e}function Le(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}var xe,De={displayName:"UU5.Bricks.VisualComponent",
nestingLevel:"bigBoxCollection"},Ae=Object(c.createVisualComponent)(Be(Be({},De),{},{propTypes:{},defaultProps:{},render:function(e){var t,n,r=function(e){
a.a.Environment.setRoute("studyProgrammeDetail",{id:e.id})},o=_.a.Css.css(Oe||(t=[""],n||(n=t.slice(0)),Oe=Object.freeze(Object.defineProperties(t,{raw:{value:Object.freeze(n)}
})))),i=a.a.Common.VisualComponent.getAttrs(e,o),l=a.a.Utils.NestingLevel.getNestingLevel(e,De),u=Object(c.useDataList)({handlerMap:{load:m.a.listStudyProgrammes,createItem:m.a.createStudyProgramme},
itemHandlerMap:{load:m.a.getStudyProgramme,update:m.a.updateStudyProgramme},initialDtoIn:{pageInfo:{}}}),s=u.state,d=u.data,p=(u.newData,u.pendingData,
u.errorData),f=u.handlerMap,b=Object(c.useRef)(),g=Object(c.useRef)(),C=Object(c.useRef)(),v=Object(c.useCallback)((function(e,t){var n=g.current;n.open({
header:e?a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:Ee.modal.header.edit}):a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:Ee.modal.header.creation}),content:a.a.Common.Element.create(ae,{onSave:t,
onSaveDone:function(t){n.close(),t.component.getAlertBus().setAlert({content:e?a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:Ee.modal.onSaveDone.edit}):a.a.Common.Element.create(a.a.Bricks.Lsi,{
lsi:Ee.modal.onSaveDone.creation}),colorSchema:"success"})},onSaveFail:function(t){console.debug(t),t.component.getAlertBus().setAlert({content:e?a.a.Common.Element.create(a.a.Bricks.Lsi,{
lsi:Ee.modal.onSaveFail.edit}):a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:Ee.modal.onSaveFail.creation}),colorSchema:"danger"})},onCancel:function(){return n.close()},studyProgramme:e})})
}),[]),y=Object(c.useCallback)((function(){v(null,function(){var e=we(regeneratorRuntime.mark((function e(t){var n,r,o,a;return regeneratorRuntime.wrap((function(e){for(;;)switch(e.prev=e.next){
case 0:return n=t.component,r=t.values,e.prev=1,e.next=4,f.createItem(r);case 4:o=e.sent,e.next=11;break;case 7:e.prev=7,e.t0=e.catch(1),a=e.t0,console.error(a);case 11:if(!C.current){e.next=13;break}
return e.abrupt("return");case 13:a?n.saveFail(a):n.saveDone(o);case 14:case"end":return e.stop()}}),e,null,[[1,7]])})));return function(t){return e.apply(this,arguments)}}())
}),[v,f.createItem,f.load,C]),h=Object(c.useCallback)((function(e){console.debug(e),v(e.data,function(){var t=we(regeneratorRuntime.mark((function t(n){var r,o,a,c
;return regeneratorRuntime.wrap((function(t){for(;;)switch(t.prev=t.next){case 0:return r=n.component,o=n.values,t.prev=1,t.next=4,e.handlerMap.update(o);case 4:a=t.sent,t.next=11;break;case 7:
t.prev=7,t.t0=t.catch(1),c=t.t0,console.error(c);case 11:if(!C.current){t.next=13;break}return t.abrupt("return");case 13:c?r.saveFail(c):r.saveDone(a),c||e.data.name===a.name||f.load();case 15:
case"end":return t.stop()}}),t,null,[[1,7]])})));return function(e){return t.apply(this,arguments)}}())
}),[v,f.load,C]),O=a.a.Common.Element.create("div",i,a.a.Utils.Content.getChildren(e.children,e,De));return l?a.a.Common.Element.create("div",i,a.a.Common.Element.create(a.a.Bricks.Section,{style:{
padding:"10px"},header:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:Ee.header})},function(){var e;switch(s){case"pendingNoData":case"pending":e=a.a.Common.Element.create(a.a.Bricks.Loading,null)
;break;case"ready":case"readyNoData":e=a.a.Common.Element.create(ke,{data:d,handleOpen:r,handleCreate:y,handleUpdate:h});break;case"error":case"errorNoData":
e=a.a.Common.Element.create(a.a.Common.Error,{errorData:p})}return e}()),a.a.Common.Element.create(a.a.Bricks.AlertBus,{ref_:b}),a.a.Common.Element.create(a.a.Bricks.Modal,{controlled:!1,ref_:g,
mountContent:"onEachOpen",overflow:!0})):a.a.Common.Element.create(a.a.Bricks.LinkModal,{children:"Visual Component",hidden:e.hidden,component:O})}}));var Te,Re=function(){
return u.a.Css.css(xe||(e=["\n  margin: 0 24px;\n  padding: 6px\n"],t||(t=e.slice(0)),xe=Object.freeze(Object.defineProperties(e,{raw:{value:Object.freeze(t)}}))));var e,t};function Ue(e,t){
var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter((function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable}))),n.push.apply(n,r)}
return n}function ze(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{};t%2?Ue(Object(n),!0).forEach((function(t){Fe(e,t,n[t])
})):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):Ue(Object(n)).forEach((function(t){Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(n,t))
}))}return e}function Fe(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}var Ne,_e={displayName:"UU5.Bricks.VisualComponent",
nestingLevel:"bigBoxCollection"},Ve=Object(c.createVisualComponent)(ze(ze({},_e),{},{propTypes:{data:a.a.PropTypes.object},defaultProps:{data:null},render:function(e){
var t,n,r,o=u.a.Css.css(Te||(n=[""],r||(r=n.slice(0)),Te=Object.freeze(Object.defineProperties(n,{raw:{value:Object.freeze(r)}
})))),c=a.a.Common.VisualComponent.getAttrs(e,o),i=a.a.Utils.NestingLevel.getNestingLevel(e,_e),l=a.a.Common.Element.create("div",c,a.a.Utils.Content.getChildren(e.children,e,_e))
;return i?a.a.Common.Element.create("div",c,a.a.Common.Element.create(a.a.Bricks.Card,{className:Re()},a.a.Common.Element.create(a.a.Bricks.Section,{header:null===(t=e.data)||void 0===t?void 0:t.name,
underline:!0,level:2},a.a.Common.Element.create(a.a.BlockLayout.Block,null,a.a.Common.Element.create(a.a.BlockLayout.Row,null,a.a.Common.Element.create(a.a.BlockLayout.Column,{width:300
},"Name"),a.a.Common.Element.create(a.a.BlockLayout.Column,{textAlign:"left"},e.data.name)),a.a.Common.Element.create(a.a.BlockLayout.Row,null,a.a.Common.Element.create(a.a.BlockLayout.Column,{
width:300},"Description"),a.a.Common.Element.create(a.a.BlockLayout.Column,{textAlign:"left"
},e.data.description)),a.a.Common.Element.create(a.a.BlockLayout.Line,null),a.a.Common.Element.create(a.a.BlockLayout.Row,null,a.a.Common.Element.create(a.a.BlockLayout.Column,{width:300
},"Degree"),a.a.Common.Element.create(a.a.BlockLayout.Column,{textAlign:"left"},e.data.degree)),a.a.Common.Element.create(a.a.BlockLayout.Row,null,a.a.Common.Element.create(a.a.BlockLayout.Column,{
width:300},"Form"),a.a.Common.Element.create(a.a.BlockLayout.Column,{textAlign:"left"
},e.data.forms)),a.a.Common.Element.create(a.a.BlockLayout.Row,null,a.a.Common.Element.create(a.a.BlockLayout.Column,{width:300},"Languages"),a.a.Common.Element.create(a.a.BlockLayout.Column,{
textAlign:"left"},e.data.languages)),a.a.Common.Element.create(a.a.BlockLayout.Line,null),a.a.Common.Element.create(a.a.BlockLayout.Row,null,a.a.Common.Element.create(a.a.BlockLayout.Column,{width:300
},"Credits"),a.a.Common.Element.create(a.a.BlockLayout.Column,{textAlign:"left"
},e.data.credits)),a.a.Common.Element.create(a.a.BlockLayout.Line,null),a.a.Common.Element.create(a.a.BlockLayout.Row,null,a.a.Common.Element.create(a.a.BlockLayout.Column,{width:300
},"State"),a.a.Common.Element.create(a.a.BlockLayout.Column,{textAlign:"left"},e.data.state)))))):a.a.Common.Element.create(a.a.Bricks.LinkModal,{children:"Visual Component",hidden:e.hidden,
component:l})}})),Me={header:{cs:"Předměty",en:"Subjects"},info:{cs:"Přídání předmětu",en:"Add new subject"},modal:{header:{creation:{cs:"Vytvoření předmětu",en:"Creation of subject"},edit:{
cs:"Editace předmětu",en:"Edit of subject"}},onSaveDone:{creation:{cs:"Úspěšně vytvořeno",en:"Successfully created"},edit:{cs:"Úspěšně upraveno",en:"Successfully edited"}},onSaveFail:{creation:{
cs:"Chyba běhěm vytváření",en:"Error has occured during creation"},edit:{cs:"Chyba běhěm editace",en:"Error has occured during editing"}}}};function Ie(e,t){var n=Object.keys(e)
;if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter((function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable}))),n.push.apply(n,r)}return n}
function qe(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{};t%2?Ie(Object(n),!0).forEach((function(t){We(e,t,n[t])
})):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):Ie(Object(n)).forEach((function(t){Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(n,t))
}))}return e}function We(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}var Ge,He={displayName:"UU5.Bricks.VisualComponent",
nestingLevel:"bigBoxCollection"},Ye=Object(c.createVisualComponent)(qe(qe({},He),{},{propTypes:{data:a.a.PropTypes.array,studyProgrammeId:a.a.PropTypes.string,handleSubjectAdd:a.a.PropTypes.func,
handleSubjectRemove:a.a.PropTypes.func},defaultProps:{data:[],studyProgrammeId:"",handleSubjectAdd:function(){},handleSubjectRemove:function(){}},render:function(e){var t,n,r=[{cell:function(e){
return a.a.Common.Element.create(a.a.Bricks.Link,{onClick:function(){o(e.data.data)}},a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:e.data.data.name}))},
header:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:{en:"Species",cs:"Název"}})},{cell:function(e){return a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:e.data.data.credits})},
header:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:{en:"Credits",cs:"Kredity"}})},{cell:function(t){var n;return a.a.Common.Element.create(a.a.Bricks.Lsi,{
lsi:null===(n=t.data.data.studyProgrammes.find((function(t){return t.studyProgrammeId===(null==e?void 0:e.studyProgrammeId)})))||void 0===n?void 0:n.semester})},
header:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:{en:"semester",cs:"semester"}})},{cell:function(t){return 1==i()?a.a.Common.Element.create(a.a.Bricks.Button,{content:"Odstaň",onClick:function(){
e.handleSubjectRemove(t.data.data.id)}}):null},cellPadding:"4px 8px"}],o=function(e){a.a.Environment.setRoute("subjectDetail",{id:e.id})},i=function(){
return a.a.Common.Tools.hasSomeProfiles(l,[ue,se])},l=(Object(c.useRef)(),Object(c.useContext)(s).data.authorizedProfiles),m=u.a.Css.css(Ne||(t=[""],n||(n=t.slice(0)),
Ne=Object.freeze(Object.defineProperties(t,{raw:{value:Object.freeze(n)}
})))),d=a.a.Common.VisualComponent.getAttrs(e,m),p=a.a.Utils.NestingLevel.getNestingLevel(e,He),f=a.a.Common.Element.create("div",d,a.a.Utils.Content.getChildren(e.children,e,He))
;return p?a.a.Common.Element.create("div",d,a.a.Common.Element.create(ie.a.ControllerProvider,{data:e.data?e.data:[]},a.a.Common.Element.create(ie.a.ActionBar,{title:"",actions:!0===i()?function(t){
t.screenSize;return[{content:{en:"Add subject",cs:"Přidej předmět"},onClick:function(){null==e||e.handleSubjectAdd()},icon:"mdi-plus-circle",colorSchema:"primary",bgStyle:"filled",active:!0}]}:[]
}),a.a.Common.Element.create(ie.a.List,{rowPadding:"4px 16px",tileRowSpacing:8,tileListPadding:"8px 16px",columns:r}))):a.a.Common.Element.create(a.a.Bricks.LinkModal,{children:"Visual Component",
hidden:e.hidden,component:f})}})),Je={header:{cs:"Vyber předěmět",en:"Select subjects"},info:{cs:"Vybrání předmětu",en:"Subject selection"},form:{subjects:{cs:"Předměty",en:"Subjects"},semester:{
cs:"Semestr",en:"Sememster"}},submit:{cs:"Přidej",en:"Add"}},Ke=Object(c.createVisualComponentWithRef)({displayName:C.TAG+"SubjectsSelectModal",propTypes:{onSave:a.a.PropTypes.func,
onSaveDone:a.a.PropTypes.func,onSaveFail:a.a.PropTypes.func,onCancel:a.a.PropTypes.func},defaultProps:{onSave:function(){},onSaveDone:function(){},onSaveFail:function(){},onCancel:function(){}},
render:function(e){var t=Object(c.useDataList)({handlerMap:{load:m.a.listSubjects},itemHandlerMap:{},initialDtoIn:{pageInfo:{}}}),n=t.state,r=t.data,o=(t.newData,t.pendingData,t.errorData)
;t.handlerMap;return a.a.Common.Element.create(a.a.Common.Fragment,null,function(){var t;switch(n){case"pendingNoData":case"pending":t=a.a.Common.Element.create(a.a.Bricks.Loading,null);break
;case"ready":case"readyNoData":t=a.a.Common.Element.create(a.a.Common.Fragment,null,a.a.Common.Element.create(a.a.Forms.Form,{onSave:e.onSave,onSaveDone:e.onSaveDone,onSaveFail:e.onSaveFail,
onCancel:e.onCancel},a.a.Common.Element.create(a.a.Forms.Select,{label:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:Je.form.subjects}),name:"subjectId",required:!0},null==r?void 0:r.map((function(e){
return a.a.Common.Element.create(a.a.Forms.Select.Option,{key:e.data.id,value:e.data.id,content:e.data.name})}))),a.a.Common.Element.create(a.a.Forms.Number,{
label:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:Je.form.semester}),name:"semester",value:0,min:0,max:10,step:1,valueType:"number",required:!0}),a.a.Common.Element.create(a.a.Forms.Controls,{
controlled:!1})));break;case"error":case"errorNoData":t=a.a.Common.Element.create(a.a.Common.Error,{errorData:o})}return t}())}});function $e(e,t,n,r,o,a,c){try{var i=e[a](c),l=i.value}catch(e){
return void n(e)}i.done?t(l):Promise.resolve(l).then(r,o)}function Qe(e){return function(){var t=this,n=arguments;return new Promise((function(r,o){var a=e.apply(t,n);function c(e){
$e(a,r,o,c,i,"next",e)}function i(e){$e(a,r,o,c,i,"throw",e)}c(void 0)}))}}function Ze(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e)
;t&&(r=r.filter((function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable}))),n.push.apply(n,r)}return n}function Xe(e){for(var t=1;t<arguments.length;t++){
var n=null!=arguments[t]?arguments[t]:{};t%2?Ze(Object(n),!0).forEach((function(t){et(e,t,n[t])
})):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):Ze(Object(n)).forEach((function(t){Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(n,t))
}))}return e}function et(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}var tt,nt={displayName:"UU5.Bricks.VisualComponent",
nestingLevel:"bigBoxCollection"},rt=Object(c.createVisualComponent)(Xe(Xe({},nt),{},{propTypes:{studyProgrammeId:a.a.PropTypes.string},defaultProps:{studyProgrammeId:""},render:function(e){
var t,n,r=u.a.Css.css(Ge||(t=[""],n||(n=t.slice(0)),Ge=Object.freeze(Object.defineProperties(t,{raw:{value:Object.freeze(n)}
})))),o=a.a.Common.VisualComponent.getAttrs(e,r),i=a.a.Utils.NestingLevel.getNestingLevel(e,nt),l=Object(c.useDataList)({handlerMap:{load:m.a.listSubjectsByStudyProgramme,
asignSubject:m.a.asignSubject,removeSubject:m.a.removeSubject},itemHandlerMap:{},initialDtoIn:{pageInfo:{},studyProgrammeId:e.studyProgrammeId}}),s=l.state,d=l.data,p=(l.newData,l.pendingData,
l.errorData),f=l.handlerMap,b=Object(c.useRef)(),g=Object(c.useRef)(),C=Object(c.useRef)(),v=Object(c.useCallback)((function(e,t){var n=g.current;n.open({header:"Vyber předmět",
content:a.a.Common.Element.create(Ke,{onSave:t,onSaveDone:function(t){n.close(),t.component.getAlertBus().setAlert({content:e?a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:Me.modal.onSaveDone.edit
}):a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:Me.modal.onSaveDone.creation}),colorSchema:"success"})},onSaveFail:function(t){console.debug(t),t.component.getAlertBus().setAlert({
content:e?a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:Me.modal.onSaveFail.edit}):a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:Me.modal.onSaveFail.creation}),colorSchema:"danger"})},
onCancel:function(){return n.close()}})})}),[]),y=Object(c.useCallback)((function(){v(null,function(){var t=Qe(regeneratorRuntime.mark((function t(n){var r,o,a,c,i
;return regeneratorRuntime.wrap((function(t){for(;;)switch(t.prev=t.next){case 0:return r=n.component,o=n.values,t.prev=1,i={id:o.subjectId,studyProgrammeId:e.studyProgrammeId,semester:o.semester},
t.next=5,f.asignSubject(i);case 5:a=t.sent,t.next=12;break;case 8:t.prev=8,t.t0=t.catch(1),c=t.t0,console.error(c);case 12:if(!C.current){t.next=14;break}return t.abrupt("return");case 14:
c?r.saveFail(c):r.saveDone(a);case 15:case"end":return t.stop()}}),t,null,[[1,8]])})));return function(e){return t.apply(this,arguments)}}())
}),[v,f.asignSubject,f.load,C]),h=Object(c.useCallback)(function(){var t=Qe(regeneratorRuntime.mark((function t(n){var r,o;return regeneratorRuntime.wrap((function(t){for(;;)switch(t.prev=t.next){
case 0:return t.prev=0,r={id:n,studyProgrammeId:e.studyProgrammeId},t.next=4,f.removeSubject(r);case 4:return t.sent,t.next=7,f.load({studyProgrammeId:e.studyProgrammeId});case 7:t.next=13;break
;case 9:t.prev=9,t.t0=t.catch(0),o=t.t0,console.error(o);case 13:case"end":return t.stop()}}),t,null,[[0,9]])})));return function(e){return t.apply(this,arguments)}
}(),[f.load,C]),O=a.a.Common.Element.create("div",o,a.a.Utils.Content.getChildren(e.children,e,nt));return i?a.a.Common.Element.create("div",o,a.a.Common.Element.create(a.a.Bricks.Section,{
header:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:Me.header})},function(){var t;switch(s){case"pendingNoData":case"pending":t=a.a.Common.Element.create(a.a.Bricks.Loading,null);break;case"ready":
case"readyNoData":t=a.a.Common.Element.create(a.a.Common.Fragment,null,a.a.Common.Element.create(Ye,{data:d,studyProgrammeId:e.studyProgrammeId,handleSubjectAdd:y,handleSubjectRemove:h}));break
;case"error":case"errorNoData":t=a.a.Common.Element.create(a.a.Common.Error,{errorData:p})}return t}()),a.a.Common.Element.create(a.a.Bricks.AlertBus,{ref_:b
}),a.a.Common.Element.create(a.a.Bricks.Modal,{controlled:!1,ref_:g,mountContent:"onEachOpen",overflow:!0})):a.a.Common.Element.create(a.a.Bricks.LinkModal,{children:"Visual Component",
hidden:e.hidden,component:O})}})),ot={};function at(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter((function(t){
return Object.getOwnPropertyDescriptor(e,t).enumerable}))),n.push.apply(n,r)}return n}function ct(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{}
;t%2?at(Object(n),!0).forEach((function(t){it(e,t,n[t])})):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):at(Object(n)).forEach((function(t){
Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(n,t))}))}return e}function it(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}
var lt,ut={displayName:"UU5.Bricks.VisualComponent",nestingLevel:"bigBoxCollection"},st=Object(c.createVisualComponent)(ct(ct({},ut),{},{propTypes:{},defaultProps:{},render:function(e){
var t,n,r=_.a.Css.css(tt||(t=[""],n||(n=t.slice(0)),tt=Object.freeze(Object.defineProperties(t,{raw:{value:Object.freeze(n)}
})))),o=a.a.Common.VisualComponent.getAttrs(e,r),i=a.a.Utils.NestingLevel.getNestingLevel(e,ut),l=Object(c.useDataObject)({handlerMap:{load:m.a.getStudyProgramme},initialDtoIn:{pageInfo:{},
id:e.params.id}}),u=l.state,s=l.data,d=l.errorData,p=(l.pendingData,l.handlerMap,
Object(c.useRef)()),f=Object(c.useRef)(),b=a.a.Common.Element.create("div",o,a.a.Utils.Content.getChildren(e.children,e,ut))
;return i?a.a.Common.Element.create("div",o,a.a.Common.Element.create(a.a.Bricks.Section,{style:{padding:"10px"},header:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:ot.header})},function(){var t
;switch(u){case"pendingNoData":case"pending":t=a.a.Common.Element.create(a.a.Bricks.Loading,null);break;case"ready":case"readyNoData":
t=a.a.Common.Element.create(a.a.Common.Fragment,null,a.a.Common.Element.create(Ve,{data:s}),a.a.Common.Element.create(rt,{studyProgrammeId:e.params.id}));break;case"error":case"errorNoData":
t=a.a.Common.Element.create(a.a.Common.Error,{errorData:d})}return t}()),a.a.Common.Element.create(a.a.Bricks.AlertBus,{ref_:p}),a.a.Common.Element.create(a.a.Bricks.Modal,{controlled:!1,ref_:f,
mountContent:"onEachOpen",overflow:!0})):a.a.Common.Element.create(a.a.Bricks.LinkModal,{children:"Visual Component",hidden:e.hidden,component:b})}}));function mt(e,t){var n=Object.keys(e)
;if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter((function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable}))),n.push.apply(n,r)}return n}
function dt(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{};t%2?mt(Object(n),!0).forEach((function(t){pt(e,t,n[t])
})):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):mt(Object(n)).forEach((function(t){Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(n,t))
}))}return e}function pt(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}var ft,bt={displayName:"UU5.Bricks.VisualComponent",
nestingLevel:"bigBoxCollection"},gt=Object(c.createVisualComponent)(dt(dt({},bt),{},{propTypes:{data:a.a.PropTypes.array,handleOpen:a.a.PropTypes.func,handleCreate:a.a.PropTypes.func},defaultProps:{
data:[],handleOpen:function(){},handleCreate:function(){}},render:function(e){var t,n,r=[{cell:function(t){return a.a.Common.Element.create(a.a.Bricks.Link,{onClick:function(){
null==e||e.handleOpen(t.data.data)}},a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:t.data.data.name}))},header:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:{en:"Species",cs:"Název"}})},{
cell:function(e){return a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:e.data.data.credits})},header:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:{en:"Credits",cs:"Kredity"}})},{cell:function(e){
return a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:e.data.data.language})},header:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:{en:"Language",cs:"Jazyk"}})},{cell:function(e){
return a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:e.data.data.guarantor})},header:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:{en:"Guarantor",cs:"Garant"}})}],o=(Object(c.useRef)(),
u.a.Css.css(lt||(t=[""],n||(n=t.slice(0)),lt=Object.freeze(Object.defineProperties(t,{raw:{value:Object.freeze(n)}
}))))),i=a.a.Common.VisualComponent.getAttrs(e,o),l=a.a.Utils.NestingLevel.getNestingLevel(e,bt),s=a.a.Common.Element.create("div",i,a.a.Utils.Content.getChildren(e.children,e,bt))
;return l?a.a.Common.Element.create("div",i,a.a.Common.Element.create(ie.a.ControllerProvider,{data:e.data?e.data:[]},a.a.Common.Element.create(ie.a.ActionBar,{title:"",actions:function(t){
t.screenSize;return[{content:{en:"Add subject",cs:"Přidej předmět"},onClick:function(){null==e||e.handleCreate()},icon:"mdi-plus-circle",colorSchema:"primary",bgStyle:"filled",active:!0}]}
}),a.a.Common.Element.create(ie.a.List,{rowPadding:"4px 16px",tileRowSpacing:8,tileListPadding:"8px 16px",columns:r}))):a.a.Common.Element.create(a.a.Bricks.LinkModal,{children:"Visual Component",
hidden:e.hidden,component:s})}})),Ct={header:{cs:"Přídání studijního programu",en:"Add new study programme"},info:{cs:"Přídání studijního programu",en:"Add new study programme"},form:{name:{
cs:"Název",en:"Name"},goal:{cs:"Cíl předmětu",en:"Goal"},languages:{czech:{cs:"Česky",en:"Czech"},english:{cs:"Anglicky",en:"English"},cs:"Vyučovací jazyk",en:"Language"},credits:{
cs:"Počet kreditů za celé studium",en:"Credist per studium"},semester:{cs:"Semestr",en:"Semester"},teachers:{cs:"Učitelé",en:"Teachers"},guarantor:{cs:"Garant",en:"Guarantors"}},submit:{cs:"Přidej",
en:"Add"}},vt=Object(c.createVisualComponentWithRef)({displayName:C.TAG+"SubjectsCreateModal",propTypes:{subject:a.a.PropTypes.object,onSave:a.a.PropTypes.func,onSaveDone:a.a.PropTypes.func,
onSaveFail:a.a.PropTypes.func,onCancel:a.a.PropTypes.func},defaultProps:{subject:null,onSave:function(){},onSaveDone:function(){},onSaveFail:function(){},onCancel:function(){}},render:function(e){
return a.a.Common.Element.create(a.a.Forms.Form,{onSave:e.onSave,onSaveDone:e.onSaveDone,onSaveFail:e.onSaveFail,onCancel:e.onCancel},a.a.Common.Element.create(a.a.Forms.Text,{
label:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:Ct.form.name}),name:"name",value:null!=e&&e.subject?null==e?void 0:e.subject.name:void 0,inputAttrs:{maxLength:255},controlled:!1,required:!0
}),a.a.Common.Element.create(a.a.Forms.Text,{label:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:Ct.form.goal}),name:"goal",value:null!=e&&e.subject?null==e?void 0:e.subject.goal:void 0,inputAttrs:{
maxLength:255},controlled:!1,required:!0}),a.a.Common.Element.create(a.a.Forms.Select,{label:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:Ct.form.languages}),name:"language",
value:null!=e&&e.subject?null==e?void 0:e.subject.language:void 0,required:!0},a.a.Common.Element.create(a.a.Forms.Select.Option,{value:"CZ",content:a.a.Common.Element.create(a.a.Bricks.Lsi,{
lsi:Ct.form.languages.czech})}),a.a.Common.Element.create(a.a.Forms.Select.Option,{value:"EN",content:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:Ct.form.languages.english})
})),a.a.Common.Element.create(a.a.Forms.Number,{label:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:Ct.form.credits}),name:"credits",value:null!=e&&e.subject?null==e?void 0:e.subject.credits:void 0,
min:0,max:300,step:1,valueType:"number",required:!0}),a.a.Common.Element.create(a.a.Forms.TagSelect,{label:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:Ct.form.teachers}),name:"teachers",
value:null!=e&&e.subject?null==e?void 0:e.subject.teachers:void 0,allowCustomTags:!0,required:!0}),a.a.Common.Element.create(a.a.Forms.Text,{label:a.a.Common.Element.create(a.a.Bricks.Lsi,{
lsi:Ct.form.guarantor}),name:"guarantor",value:null!=e&&e.subject?null==e?void 0:e.subject.guarantor:void 0,inputAttrs:{maxLength:255},controlled:!1,required:!0
}),a.a.Common.Element.create(a.a.Forms.Controls,{controlled:!1}))}}),yt={header:{cs:"Předměty",en:"Subjects"},info:{cs:"Přídání předmětu",en:"Add new subject"},modal:{header:{creation:{
cs:"Přídání předmětu",en:"Subject adding"},edit:{cs:"Editace předmětu",en:"Subject editing"}},onSaveDone:{creation:{cs:"Úspěšně vytvořeno",en:"Successfully created"},edit:{cs:"Úspěšně upraveno",
en:"Successfully edited"}},onSaveFail:{creation:{cs:"Chyba běhěm vytváření",en:"Error has occured during creation"},edit:{cs:"Chyba běhěm editace",en:"Error has occured during editing"}}}}
;function ht(e,t,n,r,o,a,c){try{var i=e[a](c),l=i.value}catch(e){return void n(e)}i.done?t(l):Promise.resolve(l).then(r,o)}function Ot(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){
var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter((function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable}))),n.push.apply(n,r)}return n}function jt(e){
for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{};t%2?Ot(Object(n),!0).forEach((function(t){kt(e,t,n[t])
})):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):Ot(Object(n)).forEach((function(t){Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(n,t))
}))}return e}function kt(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}var Et,Pt={displayName:"UU5.Bricks.VisualComponent",
nestingLevel:"bigBoxCollection"},wt=Object(c.createVisualComponent)(jt(jt({},Pt),{},{propTypes:{},defaultProps:{},render:function(e){
var t,n,r=Object(c.useContext)(s).data.authorizedProfiles,o=_.a.Css.css(ft||(t=[""],n||(n=t.slice(0)),ft=Object.freeze(Object.defineProperties(t,{raw:{value:Object.freeze(n)}
})))),i=a.a.Common.VisualComponent.getAttrs(e,o),l=a.a.Utils.NestingLevel.getNestingLevel(e,Pt),u=Object(c.useDataList)({handlerMap:{load:m.a.listSubjects,createItem:m.a.createSubject},
itemHandlerMap:{update:m.a.updateSubject},initialDtoIn:{pageInfo:{}}}),d=u.state,p=u.data,f=(u.newData,u.pendingData,
u.errorData),b=u.handlerMap,g=Object(c.useRef)(),C=Object(c.useRef)(),v=Object(c.useRef)(),y=function(e){a.a.Environment.setRoute("subjectDetail",{id:e.id})},h=Object(c.useCallback)((function(e,t){
var n=C.current;n.open({header:e?a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:yt.modal.header.edit}):a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:yt.modal.header.creation}),
content:a.a.Common.Element.create(vt,{onSave:t,onSaveDone:function(t){n.close(),t.component.getAlertBus().setAlert({content:e?a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:yt.modal.onSaveDone.edit
}):a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:yt.modal.onSaveDone.creation}),colorSchema:"success"})},onSaveFail:function(t){console.debug(t),t.component.getAlertBus().setAlert({
content:e?a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:yt.modal.onSaveFail.edit}):a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:yt.modal.onSaveFail.creation}),colorSchema:"danger"})},
onCancel:function(){return n.close()},subject:e})})}),[]),O=Object(c.useCallback)((function(){h(null,function(){var e,t=(e=regeneratorRuntime.mark((function e(t){var n,r,o,a
;return regeneratorRuntime.wrap((function(e){for(;;)switch(e.prev=e.next){case 0:return n=t.component,r=t.values,e.prev=1,e.next=4,b.createItem(r);case 4:o=e.sent,e.next=11;break;case 7:e.prev=7,
e.t0=e.catch(1),a=e.t0,console.error(a);case 11:if(!v.current){e.next=13;break}return e.abrupt("return");case 13:a?n.saveFail(a):n.saveDone(o);case 14:case"end":return e.stop()}}),e,null,[[1,7]])})),
function(){var t=this,n=arguments;return new Promise((function(r,o){var a=e.apply(t,n);function c(e){ht(a,r,o,c,i,"next",e)}function i(e){ht(a,r,o,c,i,"throw",e)}c(void 0)}))});return function(e){
return t.apply(this,arguments)}}())}),[h,b.createItem,b.load,v]),j=a.a.Common.Element.create("div",i,a.a.Utils.Content.getChildren(e.children,e,Pt))
;return l?a.a.Common.Element.create("div",i,!0===a.a.Common.Tools.hasSomeProfiles(r,[ue,se])?a.a.Common.Element.create(a.a.Common.Fragment,null,a.a.Common.Element.create(a.a.Bricks.Section,{style:{
padding:"10px"},header:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:yt.header})},function(){var e;switch(d){case"pendingNoData":case"pending":e=a.a.Common.Element.create(a.a.Bricks.Loading,null)
;break;case"ready":case"readyNoData":e=a.a.Common.Element.create(a.a.Common.Fragment,null,a.a.Common.Element.create(gt,{data:p,handleOpen:y,handleCreate:O}));break;case"error":case"errorNoData":
e=a.a.Common.Element.create(a.a.Common.Error,{errorData:f})}return e}()),a.a.Common.Element.create(a.a.Bricks.AlertBus,{ref_:g}),a.a.Common.Element.create(a.a.Bricks.Modal,{controlled:!1,ref_:C,
mountContent:"onEachOpen",overflow:!0})):a.a.Common.Element.create(a.a.Common.Fragment,null,a.a.Common.Element.create(a.a.Common.Error,{content:"Nemáte oprávnění toto zobrazit"
}),a.a.Common.Element.create(a.a.Bricks.Image,{src:"https://c.tenor.com/bIJa2uRURiQAAAAd/lord-of-the-rings-you-shall-not-pass.gif"}))):a.a.Common.Element.create(a.a.Bricks.LinkModal,{
children:"Visual Component",hidden:e.hidden,component:j})}}));var St,Bt=function(){return u.a.Css.css(Et||(e=["\n  margin: 0 24px;\n  padding: 6px\n"],t||(t=e.slice(0)),
Et=Object.freeze(Object.defineProperties(e,{raw:{value:Object.freeze(t)}}))));var e,t};function Lt(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e)
;t&&(r=r.filter((function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable}))),n.push.apply(n,r)}return n}function xt(e){for(var t=1;t<arguments.length;t++){
var n=null!=arguments[t]?arguments[t]:{};t%2?Lt(Object(n),!0).forEach((function(t){Dt(e,t,n[t])
})):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):Lt(Object(n)).forEach((function(t){Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(n,t))
}))}return e}function Dt(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}var At,Tt={displayName:"UU5.Bricks.VisualComponent",
nestingLevel:"bigBoxCollection"},Rt=Object(c.createVisualComponent)(xt(xt({},Tt),{},{propTypes:{data:a.a.PropTypes.object,onEdit:a.a.PropTypes.func},defaultProps:{data:null,onEdit:function(){}},
render:function(e){var t,n,r,o=Object(c.useContext)(s).data.authorizedProfiles,i=u.a.Css.css(St||(n=[""],r||(r=n.slice(0)),St=Object.freeze(Object.defineProperties(n,{raw:{value:Object.freeze(r)}
})))),l=a.a.Common.VisualComponent.getAttrs(e,i),m=a.a.Utils.NestingLevel.getNestingLevel(e,Tt),d=a.a.Common.Element.create("div",l,a.a.Utils.Content.getChildren(e.children,e,Tt))
;return m?a.a.Common.Element.create("div",l,a.a.Common.Element.create(a.a.Bricks.Card,{className:Bt()},a.a.Common.Element.create(a.a.Bricks.Section,{header:null===(t=e.data)||void 0===t?void 0:t.name,
underline:!0,level:2},a.a.Common.Element.create(a.a.BlockLayout.Block,null,a.a.Common.Element.create(a.a.BlockLayout.Row,null,a.a.Common.Element.create(a.a.BlockLayout.Column,{width:300
},"Name"),a.a.Common.Element.create(a.a.BlockLayout.Column,{textAlign:"left"},e.data.name),!0===a.a.Common.Tools.hasSomeProfiles(o,[se,ue])?a.a.Common.Element.create(a.a.Bricks.Button,{
onClick:function(){e.onEdit(e.data)}},"Edit"):null),a.a.Common.Element.create(a.a.BlockLayout.Row,null,a.a.Common.Element.create(a.a.BlockLayout.Column,{width:300
},"Goal"),a.a.Common.Element.create(a.a.BlockLayout.Column,{textAlign:"left"
},e.data.goal)),a.a.Common.Element.create(a.a.BlockLayout.Line,null),a.a.Common.Element.create(a.a.BlockLayout.Row,null,a.a.Common.Element.create(a.a.BlockLayout.Column,{width:300
},"Credits"),a.a.Common.Element.create(a.a.BlockLayout.Column,{textAlign:"left"},e.data.credits)),a.a.Common.Element.create(a.a.BlockLayout.Row,null,a.a.Common.Element.create(a.a.BlockLayout.Column,{
width:300},"Language"),a.a.Common.Element.create(a.a.BlockLayout.Column,{textAlign:"left"
},e.data.language)),a.a.Common.Element.create(a.a.BlockLayout.Row,null,a.a.Common.Element.create(a.a.BlockLayout.Column,{width:300},"Teachers"),a.a.Common.Element.create(a.a.BlockLayout.Column,{
textAlign:"left"},e.data.teachers)),a.a.Common.Element.create(a.a.BlockLayout.Line,null),a.a.Common.Element.create(a.a.BlockLayout.Row,null,a.a.Common.Element.create(a.a.BlockLayout.Column,{width:300
},"Guarantor"),a.a.Common.Element.create(a.a.BlockLayout.Column,{textAlign:"left"
},e.data.guarantor)),a.a.Common.Element.create(a.a.BlockLayout.Line,null),a.a.Common.Element.create(a.a.BlockLayout.Row,null,a.a.Common.Element.create(a.a.BlockLayout.Column,{width:300
},"State"),a.a.Common.Element.create(a.a.BlockLayout.Column,{textAlign:"left"},e.data.state)))))):a.a.Common.Element.create(a.a.Bricks.LinkModal,{children:"Visual Component",hidden:e.hidden,
component:d})}})),Ut={header:{cs:"Předměty",en:"Subjects"},info:{cs:"Přídání předmětu",en:"Add new subject"}},zt={header:{cs:"Témata",en:"Topics"},info:{cs:"Přídání téma",en:"Add new topic"},modal:{
header:{creation:{cs:"Vytvoření tématu",en:"Creation of topic"},edit:{cs:"Editace tématu",en:"Edit of topic"}},onSaveDone:{creation:{cs:"Úspěšně vytvořeno",en:"Successfully created"},edit:{
cs:"Úspěšně upraveno",en:"Successfully edited"}},onSaveFail:{creation:{cs:"Chyba běhěm vytváření",en:"Error has occured during creation"},edit:{cs:"Chyba běhěm editace",
en:"Error has occured during editing"}}}},Ft={menuActions:{editProgramme:{cs:"Edituj stud. program",en:"Edit programme"},addDigitalContent:{cs:"test",en:"Add digital content"}},tile:{header:{
cs:"Téma",en:"Topic"},name:{cs:"Název: ",en:"Name: "}}};function Nt(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter((function(t){
return Object.getOwnPropertyDescriptor(e,t).enumerable}))),n.push.apply(n,r)}return n}function _t(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{}
;t%2?Nt(Object(n),!0).forEach((function(t){Vt(e,t,n[t])})):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):Nt(Object(n)).forEach((function(t){
Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(n,t))}))}return e}function Vt(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}
var Mt,It={displayName:"UU5.Bricks.VisualComponent",nestingLevel:"bigBoxCollection"},qt=Object(c.createVisualComponent)(_t(_t({},It),{},{propTypes:{data:a.a.PropTypes.object,
handleOpen:a.a.PropTypes.func,handleUpdate:a.a.PropTypes.func,handleDigitalContentAdd:a.a.PropTypes.func,handleDigitalContentRemove:a.a.PropTypes.func},defaultProps:{data:null,handleOpen:function(){},
handleUpdate:function(){},handleDigitalContentAdd:function(){},handleDigitalContentRemove:function(){}},render:function(e){var t,n,r,o,c,i=[{icon:"mdi-plus",content:"Přidej",onClick:function(){
return e.handleDigitalContentAdd(e.data)}}],l=u.a.Css.css(At||(o=[""],c||(c=o.slice(0)),At=Object.freeze(Object.defineProperties(o,{raw:{value:Object.freeze(c)}
})))),s=a.a.Common.VisualComponent.getAttrs(e,l),m=a.a.Utils.NestingLevel.getNestingLevel(e,It),d=a.a.Common.Element.create("div",s,a.a.Utils.Content.getChildren(e.children,e,It))
;return m?a.a.Common.Element.create("div",s,a.a.Common.Element.create(a.a.BlockLayout.Tile,null,a.a.Common.Element.create(a.a.BlockLayout.Block,{actions:i
},a.a.Common.Element.create(a.a.BlockLayout.Row,{weight:"primary"},a.a.Common.Element.create(a.a.BlockLayout.Column,{width:150},a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:Ft.tile.name
})),a.a.Common.Element.create(a.a.BlockLayout.Column,{width:150
},null===(t=e.data.data)||void 0===t?void 0:t.name))),a.a.Common.Element.create(a.a.BlockLayout.Line,null),a.a.Common.Element.create(a.a.BlockLayout.Block,null,null===(n=e.data.data)||void 0===n||null===(r=n.digitalContents)||void 0===r?void 0:r.map((function(t){
return a.a.Common.Element.create(a.a.BlockLayout.Row,null,a.a.Common.Element.create(a.a.BlockLayout.Column,{width:200},t.name),a.a.Common.Element.create(a.a.BlockLayout.Column,{width:200
},a.a.Common.Element.create(a.a.Bricks.Link,{href:t.link,target:"_blank"},"odkaz")),(function(){
return"video"===t.type?a.a.Common.Element.create(a.a.Common.Fragment,null,a.a.Common.Element.create(a.a.BlockLayout.Column,null,a.a.Common.Element.create(a.a.Bricks.Icon,{icon:"plus4u-video"
})),a.a.Common.Element.create(a.a.BlockLayout.Column,null,a.a.Common.Element.create(a.a.Bricks.YoutubeVideo,{src:t.link
}))):"youtube"===t.type?a.a.Common.Element.create(a.a.Common.Fragment,null,a.a.Common.Element.create(a.a.BlockLayout.Column,null,a.a.Common.Element.create(a.a.Bricks.Icon,{icon:"plus4u-video"
})),a.a.Common.Element.create(a.a.BlockLayout.Column,null,a.a.Common.Element.create(a.a.Bricks.YoutubeVideo,{size:"xs",src:t.link
}))):"uuBook"===t.type?a.a.Common.Element.create(a.a.Common.Fragment,null,a.a.Common.Element.create(a.a.BlockLayout.Column,null,a.a.Common.Element.create(a.a.Bricks.Icon,{icon:"plus4u-book"
}))):"uuCourse"===t.type?a.a.Common.Element.create(a.a.Common.Fragment,null,a.a.Common.Element.create(a.a.BlockLayout.Column,null,a.a.Common.Element.create(a.a.Bricks.Icon,{icon:"plus4u-do-it"
}))):"link"===t.type?a.a.Common.Element.create(a.a.Common.Fragment,null,a.a.Common.Element.create(a.a.BlockLayout.Column,null,a.a.Common.Element.create(a.a.Bricks.Icon,{icon:"plus4u-link"
}))):a.a.Common.Element.create(a.a.Bricks.Icon,{icon:"plus4u5-close"})}),a.a.Common.Element.create(a.a.BlockLayout.Column,{width:150},a.a.Common.Element.create(a.a.Bricks.Button,{onClick:function(){
null==e||e.handleDigitalContentRemove(e.data,t.id)}},"Odstraň")))}))))):a.a.Common.Element.create(a.a.Bricks.LinkModal,{children:"Visual Component",hidden:e.hidden,component:d})}}));function Wt(e,t){
var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter((function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable}))),n.push.apply(n,r)}
return n}function Gt(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{};t%2?Wt(Object(n),!0).forEach((function(t){Ht(e,t,n[t])
})):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):Wt(Object(n)).forEach((function(t){Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(n,t))
}))}return e}function Ht(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}var Yt,Jt={displayName:"UU5.Bricks.VisualComponent",
nestingLevel:"bigBoxCollection"},Kt=Object(c.createVisualComponent)(Gt(Gt({},Jt),{},{propTypes:{data:a.a.PropTypes.array,handleTopicAdd:a.a.PropTypes.func,handleDigitalContentAdd:a.a.PropTypes.func,
handleDigitalContentRemove:a.a.PropTypes.func},defaultProps:{data:[],handleTopicAdd:function(){},handleDigitalContentAdd:function(){},handleDigitalContentRemove:function(){}},render:function(e){
a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:{en:"Species",cs:"Název"}}),Object(c.useRef)();var t,n,r,o=Object(c.useContext)(s).data.authorizedProfiles,i=u.a.Css.css(Mt||(n=[""],r||(r=n.slice(0)),
Mt=Object.freeze(Object.defineProperties(n,{raw:{value:Object.freeze(r)}
})))),l=a.a.Common.VisualComponent.getAttrs(e,i),m=a.a.Utils.NestingLevel.getNestingLevel(e,Jt),d=a.a.Common.Element.create("div",l,a.a.Utils.Content.getChildren(e.children,e,Jt))
;return m?a.a.Common.Element.create("div",l,a.a.Common.Element.create(ie.a.ControllerProvider,{data:e.data?e.data:[]},a.a.Common.Element.create(ie.a.ActionBar,{title:"",
actions:!0===a.a.Common.Tools.hasSomeProfiles(o,[ue,se])?function(t){t.screenSize;return[{content:{en:"Add topic",cs:"Přidej téma"},onClick:function(){null==e||e.handleTopicAdd()},
icon:"mdi-plus-circle",colorSchema:"primary",bgStyle:"filled",active:!0}]}:[]}),a.a.Common.Element.create(ie.a.Grid,{tileMinWidth:400,tileMaxWidth:1e3,tileSpacing:8,rowSpacing:8
},a.a.Common.Element.create(qt,{key:null===(t=e.data)||void 0===t?void 0:t.id,handleOpen:e.handleOpen,handleUpdate:e.handleUpdate,handleDigitalContentAdd:e.handleDigitalContentAdd,
handleDigitalContentRemove:e.handleDigitalContentRemove})))):a.a.Common.Element.create(a.a.Bricks.LinkModal,{children:"Visual Component",hidden:e.hidden,component:d})}})),$t={header:{
cs:"Přídání tématu",en:"Add digital content"},info:{cs:"Přídání tématu",en:"Add digital content"},form:{name:{cs:"Název",en:"Name"},description:{cs:"Popis",en:"Description"}},submit:{cs:"Přidej",
en:"Add"}},Qt=Object(c.createVisualComponentWithRef)({displayName:C.TAG+"DigitalContentCreateModal",propTypes:{onSave:a.a.PropTypes.func,onSaveDone:a.a.PropTypes.func,onSaveFail:a.a.PropTypes.func,
onCancel:a.a.PropTypes.func},defaultProps:{onSave:function(){},onSaveDone:function(){},onSaveFail:function(){},onCancel:function(){}},render:function(e){
return a.a.Common.Element.create(a.a.Forms.Form,{onSave:e.onSave,onSaveDone:e.onSaveDone,onSaveFail:e.onSaveFail,onCancel:e.onCancel},a.a.Common.Element.create(a.a.Forms.Text,{
label:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:$t.form.name}),name:"name",value:"",inputAttrs:{maxLength:255},controlled:!1,required:!0}),a.a.Common.Element.create(a.a.Forms.Text,{
label:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:$t.form.description}),name:"description",value:"",inputAttrs:{maxLength:255},controlled:!1,required:!0
}),a.a.Common.Element.create(a.a.Forms.Controls,{controlled:!1}))}}),Zt={header:{cs:"Přídání digitálního obsahu",en:"Add digital content"},info:{cs:"Přídání digitálního obsahu",
en:"Add digital content"},form:{name:{cs:"Název",en:"Name"},link:{cs:"Odkaz",en:"link"},types:{video:{cs:"Video",en:"Video"},youtube:{cs:"Youtube",en:"Youtube"},link:{cs:"Odkaz",en:"Link"},uuCourse:{
cs:"uuCourse",en:"uuCourse"},uuBook:{cs:"uuBook",en:"uuBook"},cs:"Typ obsahu",en:"Content type"}},submit:{cs:"Přidej",en:"Add"}},Xt=Object(c.createVisualComponentWithRef)({
displayName:C.TAG+"DigitalContentCreateModal",propTypes:{onSave:a.a.PropTypes.func,onSaveDone:a.a.PropTypes.func,onSaveFail:a.a.PropTypes.func,onCancel:a.a.PropTypes.func},defaultProps:{
onSave:function(){},onSaveDone:function(){},onSaveFail:function(){},onCancel:function(){}},render:function(e){return a.a.Common.Element.create(a.a.Forms.Form,{onSave:e.onSave,onSaveDone:e.onSaveDone,
onSaveFail:e.onSaveFail,onCancel:e.onCancel},a.a.Common.Element.create(a.a.Forms.Text,{label:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:Zt.form.name}),name:"name",value:"",inputAttrs:{maxLength:255
},controlled:!1,required:!0}),a.a.Common.Element.create(a.a.Forms.Text,{label:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:Zt.form.link}),name:"link",value:"",inputAttrs:{maxLength:255},
controlled:!1,required:!0}),a.a.Common.Element.create(a.a.Forms.Select,{label:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:Zt.form.types}),name:"type",value:"",required:!0
},a.a.Common.Element.create(a.a.Forms.Select.Option,{value:"video",content:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:Zt.form.types.video})}),a.a.Common.Element.create(a.a.Forms.Select.Option,{
value:"youtube",content:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:Zt.form.types.youtube})}),a.a.Common.Element.create(a.a.Forms.Select.Option,{value:"link",
content:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:Zt.form.types.link})}),a.a.Common.Element.create(a.a.Forms.Select.Option,{value:"uuCourse",content:a.a.Common.Element.create(a.a.Bricks.Lsi,{
lsi:Zt.form.types.uuCourse})}),a.a.Common.Element.create(a.a.Forms.Select.Option,{value:"uuBook",content:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:Zt.form.types.uuBook})
})),a.a.Common.Element.create(a.a.Forms.Controls,{controlled:!1}))}});function en(e,t,n,r,o,a,c){try{var i=e[a](c),l=i.value}catch(e){return void n(e)}i.done?t(l):Promise.resolve(l).then(r,o)}
function tn(e){return function(){var t=this,n=arguments;return new Promise((function(r,o){var a=e.apply(t,n);function c(e){en(a,r,o,c,i,"next",e)}function i(e){en(a,r,o,c,i,"throw",e)}c(void 0)}))}}
function nn(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter((function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable}))),
n.push.apply(n,r)}return n}function rn(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{};t%2?nn(Object(n),!0).forEach((function(t){on(e,t,n[t])
})):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):nn(Object(n)).forEach((function(t){Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(n,t))
}))}return e}function on(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}var an,cn={displayName:"UU5.Bricks.VisualComponent",
nestingLevel:"bigBoxCollection"},ln=Object(c.createVisualComponent)(rn(rn({},cn),{},{propTypes:{subjectId:a.a.PropTypes.string},defaultProps:{subjectId:""},render:function(e){
var t,n,r=u.a.Css.css(Yt||(t=[""],n||(n=t.slice(0)),Yt=Object.freeze(Object.defineProperties(t,{raw:{value:Object.freeze(n)}
})))),o=a.a.Common.VisualComponent.getAttrs(e,r),i=a.a.Utils.NestingLevel.getNestingLevel(e,cn),l=Object(c.useDataList)({handlerMap:{load:m.a.listTopicsInSubject,addTopic:m.a.addTopic,
addDigitalContent:m.a.addDigitalContent,removeDigitalContent:m.a.removeDigitalContent},itemHandlerMap:{},initialDtoIn:{pageInfo:{},subjectId:e.subjectId}}),s=l.state,d=l.data,p=(l.newData,
l.pendingData,l.errorData),f=l.handlerMap,b=Object(c.useRef)(),g=Object(c.useRef)(),C=Object(c.useRef)(),v=Object(c.useCallback)((function(e){var t=g.current;t.open({header:"Přidej téma",
content:a.a.Common.Element.create(Qt,{onSave:e,onSaveDone:function(e){t.close(),e.component.getAlertBus().setAlert({content:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:zt.modal.onSaveDone.creation
}),colorSchema:"success"})},onSaveFail:function(e){console.debug(e),e.component.getAlertBus().setAlert({content:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:zt.modal.onSaveFail.creation}),
colorSchema:"danger"})},onCancel:function(){return t.close()}})})}),[]),y=Object(c.useCallback)((function(t){v(function(){var t=tn(regeneratorRuntime.mark((function t(n){var r,o,a,c,i
;return regeneratorRuntime.wrap((function(t){for(;;)switch(t.prev=t.next){case 0:return r=n.component,o=n.values,i=rn(rn({},o),{},{subjectId:e.subjectId}),t.prev=2,t.next=5,f.addTopic(i);case 5:
a=t.sent,t.next=12;break;case 8:t.prev=8,t.t0=t.catch(2),c=t.t0,console.error(c);case 12:if(!C.current){t.next=14;break}return t.abrupt("return");case 14:c?r.saveFail(c):r.saveDone(a);case 15:
case"end":return t.stop()}}),t,null,[[2,8]])})));return function(e){return t.apply(this,arguments)}}())}),[v,f.addTopic,f.load,C]),h=Object(c.useCallback)((function(e){var t=g.current;t.open({
header:"Přidej digitální obsah",content:a.a.Common.Element.create(Xt,{onSave:e,onSaveDone:function(e){t.close(),e.component.getAlertBus().setAlert({content:a.a.Common.Element.create(a.a.Bricks.Lsi,{
lsi:zt.modal.onSaveDone.creation}),colorSchema:"success"})},onSaveFail:function(e){console.debug(e),e.component.getAlertBus().setAlert({content:a.a.Common.Element.create(a.a.Bricks.Lsi,{
lsi:zt.modal.onSaveFail.creation}),colorSchema:"danger"})},onCancel:function(){return t.close()}})})}),[]),O=Object(c.useCallback)((function(e){h(function(){
var t=tn(regeneratorRuntime.mark((function t(n){var r,o,a,c,i;return regeneratorRuntime.wrap((function(t){for(;;)switch(t.prev=t.next){case 0:return r=n.component,o=n.values,i=rn(rn({},o),{},{
id:e.data.id}),t.prev=2,t.next=5,f.addDigitalContent(i);case 5:a=t.sent,t.next=12;break;case 8:t.prev=8,t.t0=t.catch(2),c=t.t0,console.error(c);case 12:if(!C.current){t.next=14;break}
return t.abrupt("return");case 14:c?r.saveFail(c):r.saveDone(a);case 15:case"end":return t.stop()}}),t,null,[[2,8]])})));return function(e){return t.apply(this,arguments)}}())
}),[h,f.addDigitalContent,f.load,C]),j=Object(c.useCallback)(function(){var t=tn(regeneratorRuntime.mark((function t(n,r){var o,a;return regeneratorRuntime.wrap((function(t){
for(;;)switch(t.prev=t.next){case 0:return t.prev=0,o={id:n.data.id,digitalContentId:r},t.next=4,f.removeDigitalContent(o);case 4:return t.sent,t.next=7,f.load({subjectId:e.subjectId});case 7:
t.next=13;break;case 9:t.prev=9,t.t0=t.catch(0),a=t.t0,console.error(a);case 13:case"end":return t.stop()}}),t,null,[[0,9]])})));return function(e,n){return t.apply(this,arguments)}
}(),[f.load]),k=a.a.Common.Element.create("div",o,a.a.Utils.Content.getChildren(e.children,e,cn));return i?a.a.Common.Element.create("div",o,a.a.Common.Element.create(a.a.Bricks.Section,{
header:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:zt.header})},function(){var e;switch(s){case"pendingNoData":case"pending":e=a.a.Common.Element.create(a.a.Bricks.Loading,null);break;case"ready":
case"readyNoData":e=a.a.Common.Element.create(a.a.Common.Fragment,null,a.a.Common.Element.create(Kt,{data:d,handleTopicAdd:y,handleDigitalContentAdd:O,handleDigitalContentRemove:j}));break
;case"error":case"errorNoData":e=a.a.Common.Element.create(a.a.Common.Error,{errorData:p})}return e}()),a.a.Common.Element.create(a.a.Bricks.AlertBus,{ref_:b
}),a.a.Common.Element.create(a.a.Bricks.Modal,{controlled:!1,ref_:g,mountContent:"onEachOpen",overflow:!0})):a.a.Common.Element.create(a.a.Bricks.LinkModal,{children:"Visual Component",
hidden:e.hidden,component:k})}}));function un(e,t,n,r,o,a,c){try{var i=e[a](c),l=i.value}catch(e){return void n(e)}i.done?t(l):Promise.resolve(l).then(r,o)}function sn(e,t){var n=Object.keys(e)
;if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter((function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable}))),n.push.apply(n,r)}return n}
function mn(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{};t%2?sn(Object(n),!0).forEach((function(t){dn(e,t,n[t])
})):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):sn(Object(n)).forEach((function(t){Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(n,t))
}))}return e}function dn(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}var pn={displayName:"UU5.Bricks.VisualComponent",
nestingLevel:"bigBoxCollection"},fn=Object(c.createVisualComponent)(mn(mn({},pn),{},{propTypes:{},defaultProps:{},render:function(e){var t,n,r=function(){
return a.a.Common.Tools.hasSomeProfiles(o,[me,se,ue])},o=Object(c.useContext)(s).data.authorizedProfiles,i=_.a.Css.css(an||(t=[""],n||(n=t.slice(0)),an=Object.freeze(Object.defineProperties(t,{raw:{
value:Object.freeze(n)}})))),l=a.a.Common.VisualComponent.getAttrs(e,i),u=a.a.Utils.NestingLevel.getNestingLevel(e,pn),d=Object(c.useDataObject)({handlerMap:{load:m.a.getSubject,
update:m.a.updateSubject},initialDtoIn:{pageInfo:{},id:e.params.id}}),p=d.state,f=d.data,b=d.errorData,g=(d.pendingData,
d.handlerMap),C=Object(c.useRef)(),v=Object(c.useRef)(),y=Object(c.useRef)(),h=Object(c.useCallback)((function(e,t){var n=v.current;n.open({header:"Edituj předmět",
content:a.a.Common.Element.create(vt,{onSave:t,onSaveDone:function(e){n.close(),e.component.getAlertBus().setAlert({content:"Edit proběhl v pořádku",colorSchema:"success"})},onSaveFail:function(e){
console.debug(e),e.component.getAlertBus().setAlert({content:"Edit neproběhl v pořádku",colorSchema:"danger"})},onCancel:function(){return n.close()},subject:e})})
}),[]),O=Object(c.useCallback)((function(e){h(e,function(){var t,n=(t=regeneratorRuntime.mark((function t(n){var r,o,a,c;return regeneratorRuntime.wrap((function(t){for(;;)switch(t.prev=t.next){
case 0:return r=n.component,o=n.values,t.prev=1,t.next=4,g.update(mn(mn({},o),{},{id:e.id}));case 4:a=t.sent,console.debug(a),t.next=12;break;case 8:t.prev=8,t.t0=t.catch(1),c=t.t0,console.error(c)
;case 12:if(!y.current){t.next=14;break}return t.abrupt("return");case 14:c?r.saveFail(c):r.saveDone(a),c||e.name===a.name||g.load({id:a.id});case 16:case"end":return t.stop()}}),t,null,[[1,8]])})),
function(){var e=this,n=arguments;return new Promise((function(r,o){var a=t.apply(e,n);function c(e){un(a,r,o,c,i,"next",e)}function i(e){un(a,r,o,c,i,"throw",e)}c(void 0)}))});return function(e){
return n.apply(this,arguments)}}())}),[h,g.load,y]),j=a.a.Common.Element.create("div",l,a.a.Utils.Content.getChildren(e.children,e,pn))
;return u?a.a.Common.Element.create("div",l,a.a.Common.Element.create(a.a.Bricks.Section,{style:{padding:"10px"},header:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:Ut.header})},function(){var t
;switch(p){case"pendingNoData":case"pending":t=a.a.Common.Element.create(a.a.Bricks.Loading,null);break;case"ready":case"readyNoData":
t=a.a.Common.Element.create(a.a.Common.Fragment,null,a.a.Common.Element.create(Rt,{data:f,onEdit:O}),!0===r()?a.a.Common.Element.create(ln,{subjectId:e.params.id}):null);break;case"error":
case"errorNoData":t=a.a.Common.Element.create(a.a.Common.Error,{errorData:b})}return t}()),a.a.Common.Element.create(a.a.Bricks.AlertBus,{ref_:C}),a.a.Common.Element.create(a.a.Bricks.Modal,{
controlled:!1,ref_:v,mountContent:"onEachOpen",overflow:!0})):a.a.Common.Element.create(a.a.Bricks.LinkModal,{children:"Visual Component",hidden:e.hidden,component:j})}}));function bn(){
return(bn=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var n=arguments[t];for(var r in n)Object.prototype.hasOwnProperty.call(n,r)&&(e[r]=n[r])}return e}).apply(this,arguments)}
function gn(e,t){return function(e){if(Array.isArray(e))return e}(e)||function(e,t){var n=null==e?null:"undefined"!=typeof Symbol&&e[Symbol.iterator]||e["@@iterator"];if(null==n)return
;var r,o,a=[],c=!0,i=!1;try{for(n=n.call(e);!(c=(r=n.next()).done)&&(a.push(r.value),!t||a.length!==t);c=!0);}catch(e){i=!0,o=e}finally{try{c||null==n.return||n.return()}finally{if(i)throw o}}return a
}(e,t)||function(e,t){if(!e)return;if("string"==typeof e)return Cn(e,t);var n=Object.prototype.toString.call(e).slice(8,-1);"Object"===n&&e.constructor&&(n=e.constructor.name)
;if("Map"===n||"Set"===n)return Array.from(e);if("Arguments"===n||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n))return Cn(e,t)}(e,t)||function(){
throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")}()}function Cn(e,t){
(null==t||t>e.length)&&(t=e.length);for(var n=0,r=new Array(t);n<t;n++)r[n]=e[n];return r}function vn(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e)
;t&&(r=r.filter((function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable}))),n.push.apply(n,r)}return n}function yn(e){for(var t=1;t<arguments.length;t++){
var n=null!=arguments[t]?arguments[t]:{};t%2?vn(Object(n),!0).forEach((function(t){hn(e,t,n[t])
})):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):vn(Object(n)).forEach((function(t){Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(n,t))
}))}return e}function hn(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}var On,jn={displayName:u.a.TAG+"SpaReady"
},kn=a.a.Common.Component.lazy((function(){return n.e(0).then(n.bind(null,26))})),En=a.a.Common.Component.lazy((function(){return n.e(0).then(n.bind(null,25))
})),Pn=a.a.Common.Component.lazy((function(){return n.e(0).then(n.bind(null,24))})),wn={"":"home",home:{component:a.a.Common.Element.create(re,null)},studyProgrammes:{
component:a.a.Common.Element.create(Ae,null)},studyProgrammeDetail:{component:a.a.Common.Element.create(st,null),params:{id:""}},subjectsList:{component:a.a.Common.Element.create(wt,null)},
subjectDetail:{component:a.a.Common.Element.create(fn,null)},about:{component:a.a.Common.Element.create(kn,null)},"sys/uuAppWorkspace/initUve":{component:a.a.Common.Element.create(En,null)},
controlPanel:{component:a.a.Common.Element.create(Pn,null)}},Sn=Object(c.createVisualComponent)(yn(yn({},jn),{},{render:function(e){var t=gn(Object(c.useState)((function(){
return a.a.Common.Url.parse(window.location.href).useCase||"home"})),1)[0];return a.a.Common.Element.create(l.a.App.MenuProvider,{activeItemId:t},a.a.Common.Element.create(l.a.App.Page,bn({},e,{
top:a.a.Common.Element.create(l.a.App.TopBt,null),topFixed:"smart",bottom:a.a.Common.Element.create(N,null),type:3,displayedLanguages:["cs","en"],left:a.a.Common.Element.create(B,null),
leftWidth:"!xs-300px !s-300px !m-288px !l-288px !xl-288px",leftFixed:!0,leftRelative:"m l xl",leftResizable:"m l xl",leftResizableMinWidth:220,leftResizableMaxWidth:500,isLeftOpen:"m l xl",
showLeftToggleButton:!0,fullPage:!0}),a.a.Common.Element.create(l.a.App.MenuConsumer,null,(function(e){var t=e.setActiveItemId;return a.a.Common.Element.create(a.a.Common.Router,{routes:wn,
controlled:!1,onRouteChanged:function(e){var n=e.useCase;e.parameters;return t(n||"home")}})}))))}})),Bn=Object(c.createVisualComponent)({displayName:u.a.TAG+"SpaAuthenticated",render:function(){
return a.a.Common.Element.create(h,null,a.a.Common.Element.create(s.Consumer,null,(function(e){var t=e.state,n=e.errorData;switch(t){case"pending":case"pendingNoData":
return a.a.Common.Element.create(a.a.Bricks.Loading,null);case"error":case"errorNoData":return a.a.Common.Element.create(a.a.Bricks.Error,{error:n.error});case"ready":case"readyNoData":default:
return a.a.Common.Element.create(Sn,null)}})))}});function Ln(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter((function(t){
return Object.getOwnPropertyDescriptor(e,t).enumerable}))),n.push.apply(n,r)}return n}function xn(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{}
;t%2?Ln(Object(n),!0).forEach((function(t){Dn(e,t,n[t])})):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):Ln(Object(n)).forEach((function(t){
Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(n,t))}))}return e}function Dn(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}
function An(e,t){return t||(t=e.slice(0)),Object.freeze(Object.defineProperties(e,{raw:{value:Object.freeze(t)}}))}var Tn={displayName:u.a.TAG+"SpaUnauthorized"},Rn=function(){
return u.a.Css.css(On||(On=An(["\n    width: 390px;\n    max-width: 100%;\n    margin: 56px auto 0;\n    text-align: center;\n  "])))};Object(c.createVisualComponent)(xn(xn({},Tn),{},{
render:function(e){e.children;var t=a.a.Common.VisualComponent.getAttrs(e,Rn());return a.a.Common.Element.create("div",t,a.a.Common.Element.create("p",null,"Hi"))}}));function Un(){
return(Un=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var n=arguments[t];for(var r in n)Object.prototype.hasOwnProperty.call(n,r)&&(e[r]=n[r])}return e}).apply(this,arguments)}
function zn(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter((function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable}))),
n.push.apply(n,r)}return n}function Fn(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{};t%2?zn(Object(n),!0).forEach((function(t){Nn(e,t,n[t])
})):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):zn(Object(n)).forEach((function(t){Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(n,t))
}))}return e}function Nn(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}var _n={displayName:u.a.TAG+"Spa"
},Vn=Object(c.createVisualComponent)(Fn(Fn({},_n),{},{render:function(e){return a.a.Common.Element.create(l.a.App.Spa,Un({},e,{appName:"uuSubject",
notAuthenticatedContent:a.a.Common.Element.create(Bn,null)}),a.a.Common.Element.create(Bn,null))}}));if(a.a.Environment.appVersion="0.3.5",!navigator.userAgent.match(/iPhone|iPad|iPod/)){
var Mn=document.createElement("link");Mn.rel="manifest",Mn.href="assets/manifest.json",document.head.appendChild(Mn)}function In(e){e,
a.a.Common.DOM.render(a.a.Common.Element.create(r.AppContainer,null,a.a.Common.Element.create(Vn,null)),document.getElementById(e))}},function(e,t){e.exports=s},function(e,t){e.exports=m
},function(e,t){e.exports=d},function(e,t){e.exports=p}])}));