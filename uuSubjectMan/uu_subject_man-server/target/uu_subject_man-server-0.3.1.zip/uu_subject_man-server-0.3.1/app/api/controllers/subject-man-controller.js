"use strict";
const SubjectManAbl = require("../../abl/subject-man-abl.js");

class SubjectManController {

  load(ucEnv) {
    let authorizationResult = ucEnv.getAuthorizationResult();
    let authorizedProfiles = authorizationResult.getAuthorizedProfiles();
    let appConfig = SubjectManAbl.load(ucEnv.getUri(), ucEnv.getDtoIn());

    return {
      "appConfig": appConfig,
      "authorizedProfiles": authorizedProfiles
    }
  }
  init(ucEnv) {
    return SubjectManAbl.init(ucEnv.getUri(), ucEnv.getDtoIn(), ucEnv.getSession());
  }
}

module.exports = new SubjectManController();
