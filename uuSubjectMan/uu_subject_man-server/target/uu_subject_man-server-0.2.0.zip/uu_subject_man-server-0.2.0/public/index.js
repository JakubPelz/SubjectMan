/*!
 * UAF COMMERCIAL LICENSE
 * ----------------------
 * 1. PREAMBLE and Definitions
 *   1.1 These UAF Commercial License Terms ("UAF CLT") govern licensing of the Unicorn Application Framework (UAF).
 *     The Customer and Unicorn concluded an agreement for the provision of Solution that is using UAF or its parts
 *     (the "Agreement").
 *   1.2 The provisions of these UAF CLT shall govern the relationship between the Customer and Unicorn regarding
 *     the UAF License granted under the Agreement. For the avoidance of doubt, in case of any conflict between these
 *     UAF CLT and the Agreement, the provisions of the Agreement always prevail.
 *   1.3 The "UAF Components", and each of them individually as "UAF Component", shall mean the components of the Unicorn
 *     Application Framework, which are listed and described in the Attachment I to these UAF CLT.
 *   1.4 "UAF" shall mean the Unicorn Application Framework the scope of which is described in Attachment I, including all
 *     associated documentation and preparatory design materials, in particular blueprints, models, user manuals,
 *     training materials, comprehensive instructions and guidelines for drafting, production, operation and maintenance of
 *     software solutions, reference architecture, ready-made components and tools, use cases and tutorials.
 *   1.5 The "Knowledge Base" shall mean the online materials, internet fora and other resources made available by Unicorn
 *     online with regard to the UAF, intended for the broad customer and developer community.
 *   1.6 The "License" shall mean the binding terms and conditions for use of the UAF by the Customer. The License is
 *     described in Clause 2 and may be further specified or modified by the Agreement.
 *   1.7 The "Solution" shall mean any product or service developed under the Agreement using the UAF or any of
 *     UAF Components or its other parts, further specified in the Agreement.
 * 2. LICENSE GRANT
 *   2.1 The Customer shall be hereby granted a non-exclusive and non-transferable worldwide license to use the UAF for
 *     the purpose of the Solution described in the Agreement. For this purpose, the Customer shall be entitled to modify
 *     the UAF and create derivative works based on the UAF.
 *   2.2 The Customer is entitled to grant third parties a sub-license allowing them to use the UAF or any derivative works
 *     based on the UAF under commercial terms of its choice, provided that:
 *     2.2.1 use of the UAF and any derivative works based on the UAF by third parties is limited to testing, handover and
 *       operation of the Solution or its use as a service,
 *     2.2.2 third parties are not entitled to use the UAF or any derivative works based on the UAF independently of
 *       the Solution,
 *     2.2.3 third parties are not provided access to source code of the UAF unless such right is granted by the Agreement
 *       or if they conclude a commercial license agreement with Unicorn.
 *   2.3 The Solution or its parts based on the UAF shall bear a prominent copyright notice "Based on Unicorn Application
 *     Framework Copyright (c) Unicorn" integrated
 *     2.3.1 in the graphical user interface of the Solution or its relevant part or
 *     2.3.2 in accompanying file if the Solution or its relevant part do not have graphical user interface or
 *     2.3.3 in Solution's documentation.
 *   2.4 The License shall be valid for the whole duration of copyright to the UAF, unless other duration of the License is
 *     specified in the Agreement.
 *   2.5 The Customer is entitled to access the Knowledge Base only if expressly agreed in the Agreement.
 *   2.6 The Unicorn retains all rights to the UAF not covered by the provisions of this Clause 2. Unless explicitly
 *     permitted by applicable law, the Customer may not use the UAF in any other way than provided by the provisions of
 *     this Clause 2 and may not allow such use on its behalf by any of its employees or agents.
 *   2.7 The price for the License is included in the price stipulated in the Agreement.
 * 3. MODIFICATIONS
 *   3.1 The Customer explicitly acknowledges that the UAF is under continuous development and any UAF Component or other
 *     part of the UAF may be modified, replaced or removed by the Unicorn from the UAF in any of its future versions.
 *   3.2 This License covers also any new version of UAF if some parts of the UAF are modified or replaced.
 *   3.3 If any part of the UAF is removed by Unicorn in any of its future versions, the License for such version of
 *     the UAF is reduced appropriately and covers only the remaining parts of UAF. Sub-licenses previously granted to
 *     third parties in accordance with Clause 2.2 remain unaffected.
 * 4. THIRD PARTY LICENSE TERMS
 *   4.1 UAF is using third party software tools (the "Third Party Software") that is an integral part of the UAF. Some of
 *     these tools are free software or open-source SW.
 *   4.2 The list of Third Party Software used in the UAF including its license terms and authors is provided as part of
 *     Attachment I to these UAF CLT.
 *   4.3 For the use of the above mentioned Third Party Software, the Customer acknowledges its license terms referred to
 *     in Attachment I to these UAF CLT.
 * 5. NO TRADEMARK OR PATENT LICENSE
 *   5.1 These UAF CLT cover only copyright use of the UAF. If not expressly agreed otherwise, the Customer shall not be
 *     granted any trademark and/or patent license here under and nothing in these UAF CLT shall be interpreted in a way it
 *     does so.
 * 6. LIMITED WARRANTY
 *   6.1 IF NOT STIPULATED OTHER WISE OR REQUIRED BY APPLICABLE LAW, THE UAF IS PROVIDED ON "AS IS" BASIS,
 *     WITH NO WARRANTY OF, INCLUDING WITHOUT LIMITATION, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE ENTIRE
 *     RISK AS TO THE QUALITY AND PERFORMANCE OF THE UAF IS CARRIED SOLELY BY THE CUSTOMER, UNLESS OTHERWISE AGREED BETWEEN
 *     THE UNICORN AND THE CUSTOMER IN THE AGREEMENT.
 * 7. LIMITATION OF LIABILITY
 *   7.1 TO THE EXTENT PERMITTED BY APPLICABLE LAW, THE UNICORN WILL NOT BE HELD LIABLE FOR ANY DAMAGES CAUSED BY
 *     THE DISTRIBUTION OR USE OF THE UAF. THIS ALSO INCLUDES ANY CONSEQUENTIAL AND/OR INCIDENTAL DAMAGES, MONETARY OR NOT,
 *     THAT ARE CONNECTED WITH THE DISTRIBUTION OR USE OF THE UAF, UNLESS OTHERWISE AGREED BETWEEN THE UNICORN AND
 *     THE CUSTOMER IN THE AGREEMENT.
 * 8. THIRD PARTY CLAIMS
 *   8.1 The Unicorn will defend or settle, at its option and expense, any action brought against the Customer in a member
 *     state of the European Union which concerns an allegation that the UAF provided infringes a patent or copyright or
 *     misappropriates a trade secret in such jurisdiction. The Unicorn shall pay costs and damages finally awarded against
 *     the Customer that are attributable to such action. The Customer declares to understand and agrees that following
 *     conditions must be fulfilled in order to make Unicorn's obligations under this Clause 8 effective and enforceable:
 *     The Customer must (a) notify Unicorn promptly in writing of the action or any reasonable threat of it,
 *     (b) provide the Unicorn with all reasonable information and assistance it will request to settle or defend the action, and
 *     (c) grant the Unicorn sole authority and control of the defense or settlement of the action.
 *   8.2 If a claim is made under Clause 8.1 the Unicorn may, at its sole option and expense:
 *     (a) replace or modify the UAF so that it becomes non-infringing,
 *     (b) procure for the Customer the right to continue using the UAF unmodified.
 *   8.3 The Unicorn shall not be held liable to the Customer if the action is based on:
 *     (a) the combination of UAF with any product not provided by Unicorn,
 *     (b) the modification of the UAF other than by Unicorn,
 *     (c) the use of other than a current unaltered release of the UAF,
 *     (d) a product that the Customer makes, uses, or sells,
 *     (e) infringement by the Customer that is deemed willful. In the case under (e) the Customer shall reimburse
 *     the Unicorn for its reasonable attorney fees and other costs related to the action.
 *   8.4 THIS CLAUSE IS SUBJECT TO CLAUSE 7 AND STATES UNICORN'S ENTIRE LIABILITY, CUSTOMER'S SOLE AND EXCLUSIVE REMEDY,
 *     FOR DEFENSE, SETTLEMENT AND DAMAGES, WITH RESPECT TO ANY ALLEGED PATENT OR COPYRIGHT INFRINGEMENT OR TRADE SECRET
 *     MISAPPROPRIATION BY ANY ITEM PROVIDED UNDER THESE TERMS, UNLESS OTHERWISE AGREEMENT BETWEEN UNICORN AND THE CUSTOMER
 *     IN THE AGREEMENT.
 * 9. GENERAL PROVISIONS
 *   9.1 By entering into the Agreement, the Customer signifies its assent to and acceptance of these UAF CLT.
 *   9.2 The License is effective from the moment of execution of the Agreement, if the Agreement does not specify later
 *     date. Where the provisions of the Agreement regarding the License and provisions of these UAF CLT differ, provisions
 *     of the Agreement shall prevail.
 *   9.3 If any provision of the Agreement regarding the License or these UAF CLT is held by a court of competent
 *     jurisdiction to be void, invalid, unenforceable or illegal, such provision shall be severed from the Agreement or
 *     these UAF CLT and the remaining provisions will remain in full force and effect.
 *   9.4 The provisions of Clauses 7 and 8 shall survive any expiration or termination of the Agreement.
 *   9.5 All rights and obligations between the Unicorn and the Customer arising on the basis of these UAF CLT or
 *     in connection with them are governed by the laws of the Czech Republic with the exclusion of both the rules on
 *     the conflict of laws and the United Nations Convention on Contracts for the International Sale of Goods (CISG).
 *   9.6 The resolution of all disputes arising from or connected here to shall be under sole jurisdiction of the courts of
 *     the Czech Republic.
 */
!function(e,t){
"object"==typeof exports&&"object"==typeof module?module.exports=t(require("uu5g04"),require("uu5g04-hooks"),require("uu5g04-bricks"),require("uu5tilesg02"),require("uu_plus4u5g01"),require("uu_plus4u5g01-app"),require("module"),require("uu_plus4u5g01-bricks"),require("uu_oidcg01"),require("react"),require("uu5g04-forms"),require("uu_territoryg01"),require("uu_territoryg01-artifactifc"),require("uu_contentkitg01")):"function"==typeof define&&define.amd?define("index",["uu5g04","uu5g04-hooks","uu5g04-bricks","uu5tilesg02","uu_plus4u5g01","uu_plus4u5g01-app","module","uu_plus4u5g01-bricks","uu_oidcg01","react","uu5g04-forms","uu_territoryg01","uu_territoryg01-artifactifc","uu_contentkitg01"],t):"object"==typeof exports?exports.index=t(require("uu5g04"),require("uu5g04-hooks"),require("uu5g04-bricks"),require("uu5tilesg02"),require("uu_plus4u5g01"),require("uu_plus4u5g01-app"),require("module"),require("uu_plus4u5g01-bricks"),require("uu_oidcg01"),require("react"),require("uu5g04-forms"),require("uu_territoryg01"),require("uu_territoryg01-artifactifc"),require("uu_contentkitg01")):e.index=t(e.uu5g04,e["uu5g04-hooks"],e["uu5g04-bricks"],e.uu5tilesg02,e.uu_plus4u5g01,e["uu_plus4u5g01-app"],e[void 0],e["uu_plus4u5g01-bricks"],e.uu_oidcg01,e.react,e["uu5g04-forms"],e.uu_territoryg01,e["uu_territoryg01-artifactifc"],e.uu_contentkitg01)
}(window,(function(e,t,n,r,o,a,c,i,l,u,s,m,d,p){return function(e){function t(t){for(var n,o,a=t[0],c=t[1],i=0,u=[];i<a.length;i++)o=a[i],
Object.prototype.hasOwnProperty.call(r,o)&&r[o]&&u.push(r[o][0]),r[o]=0;for(n in c)Object.prototype.hasOwnProperty.call(c,n)&&(e[n]=c[n]);for(l&&l(t);u.length;)u.shift()()}var n={},r={1:0}
;function o(t){if(n[t])return n[t].exports;var r=n[t]={i:t,l:!1,exports:{}};return e[t].call(r.exports,r,r.exports,o),r.l=!0,r.exports}o.e=function(e){var t=[],n=r[e];if(0!==n)if(n)t.push(n[2]);else{
var a=new Promise((function(t,o){n=r[e]=[t,o]}));t.push(n[2]=a);var c,i=document.createElement("script");i.charset="utf-8",i.timeout=120,o.nc&&i.setAttribute("nonce",o.nc),i.src=function(e){
return o.p+"chunks/index/"+e+"-0150fd84a7fb3ac0635d.min.js"}(e),0!==i.src.indexOf(window.location.origin+"/")&&(i.crossOrigin="anonymous");var l=new Error;c=function(t){i.onerror=i.onload=null,
clearTimeout(u);var n=r[e];if(0!==n){if(n){var o=t&&("load"===t.type?"missing":t.type),a=t&&t.target&&t.target.src;l.message="Loading chunk "+e+" failed.\n("+o+": "+a+")",l.name="ChunkLoadError",
l.type=o,l.request=a,n[1](l)}r[e]=void 0}};var u=setTimeout((function(){c({type:"timeout",target:i})}),12e4);i.onerror=i.onload=c,document.head.appendChild(i)}return Promise.all(t)},o.m=e,o.c=n,
o.d=function(e,t,n){o.o(e,t)||Object.defineProperty(e,t,{enumerable:!0,get:n})},o.r=function(e){"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{
value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0})},o.t=function(e,t){if(1&t&&(e=o(e)),8&t)return e;if(4&t&&"object"==typeof e&&e&&e.__esModule)return e;var n=Object.create(null)
;if(o.r(n),Object.defineProperty(n,"default",{enumerable:!0,value:e}),2&t&&"string"!=typeof e)for(var r in e)o.d(n,r,function(t){return e[t]}.bind(null,r));return n},o.n=function(e){
var t=e&&e.__esModule?function(){return e.default}:function(){return e};return o.d(t,"a",t),t},o.o=function(e,t){return Object.prototype.hasOwnProperty.call(e,t)},o.p="",o.oe=function(e){
throw console.error(e),e};var a=window.__webpack_jsonp_uu_subject_man_hi_0_2_0_index=window.__webpack_jsonp_uu_subject_man_hi_0_2_0_index||[],c=a.push.bind(a);a.push=t,a=a.slice()
;for(var i=0;i<a.length;i++)t(a[i]);var l=c;return o(o.s=12)}([function(t,n){t.exports=e},function(e,n){e.exports=t},function(e,t,n){"use strict";var r=n(0),o=n.n(r),a=n(9);function c(e,t){
var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter((function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable}))),n.push.apply(n,r)}
return n}function i(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{};t%2?c(Object(n),!0).forEach((function(t){l(e,t,n[t])
})):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):c(Object(n)).forEach((function(t){Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(n,t))}))
}return e}function l(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}var u=a.a.TAG+"Core.";t.a=i(i({},a.a),{},{TAG:u,
Css:o.a.Common.Css.createCssModule(u.replace(/\.$/,"").toLowerCase().replace(/\./g,"-").replace(/[^a-z-]/g,""),"uu_subject_man-hi/uu_subject_man-hi@0.2.0")})},function(e,t,n){"use strict"
;var r=n(0),o=n.n(r),a=n(6),c=n.n(a);function i(e,t,n,r,o,a,c){try{var i=e[a](c),l=i.value}catch(e){return void n(e)}i.done?t(l):Promise.resolve(l).then(r,o)}function l(e){return function(){
var t=this,n=arguments;return new Promise((function(r,o){var a=e.apply(t,n);function c(e){i(a,r,o,c,l,"next",e)}function l(e){i(a,r,o,c,l,"throw",e)}c(void 0)}))}}var u={
APP_BASE_URI:location.protocol+"//"+location.host+o.a.Environment.getAppBasePath(),call:function(e,t,n,r){return l(regeneratorRuntime.mark((function o(){var a
;return regeneratorRuntime.wrap((function(o){for(;;)switch(o.prev=o.next){case 0:return o.next=2,c.a.Common.Calls.call(e,t,n,r);case 2:return a=o.sent,o.abrupt("return",a.data);case 4:case"end":
return o.stop()}}),o)})))()},loadDemoContent:function(e){var t=u.getCommandUri("loadDemoContent");return u.call("get",t,e)},loadIdentityProfiles:function(){
var e=u.getCommandUri("sys/uuAppWorkspace/initUve");return u.call("get",e,{})},initWorkspace:function(e){var t=u.getCommandUri("sys/uuAppWorkspace/init");return u.call("post",t,e)},
getWorkspace:function(){var e=u.getCommandUri("sys/uuAppWorkspace/get");return u.call("get",e,{})},initAndGetWorkspace:function(e){return l(regeneratorRuntime.mark((function t(){
return regeneratorRuntime.wrap((function(t){for(;;)switch(t.prev=t.next){case 0:return t.next=2,u.initWorkspace(e);case 2:return t.next=4,u.getWorkspace();case 4:return t.abrupt("return",t.sent)
;case 5:case"end":return t.stop()}}),t)})))()},listStudyProgrammes:function(e){return l(regeneratorRuntime.mark((function t(){var n,r;return regeneratorRuntime.wrap((function(t){
for(;;)switch(t.prev=t.next){case 0:return n=u.getCommandUri("studyProgramme/list"),t.next=3,u.call("get",n,e);case 3:return r=t.sent,t.abrupt("return",r);case 5:case"end":return t.stop()}}),t)})))()
},getStudyProgramme:function(e){return l(regeneratorRuntime.mark((function t(){var n,r;return regeneratorRuntime.wrap((function(t){for(;;)switch(t.prev=t.next){case 0:
return n=u.getCommandUri("studyProgramme/get"),t.next=3,u.call("get",n,e);case 3:return r=t.sent,t.abrupt("return",r);case 5:case"end":return t.stop()}}),t)})))()},createStudyProgramme:function(e){
return l(regeneratorRuntime.mark((function t(){var n,r;return regeneratorRuntime.wrap((function(t){for(;;)switch(t.prev=t.next){case 0:return n=u.getCommandUri("studyProgramme/create"),t.next=3,
u.call("post",n,e);case 3:return r=t.sent,t.abrupt("return",r);case 5:case"end":return t.stop()}}),t)})))()},updateStudyProgramme:function(e){return l(regeneratorRuntime.mark((function t(){var n,r
;return regeneratorRuntime.wrap((function(t){for(;;)switch(t.prev=t.next){case 0:return n=u.getCommandUri("studyProgramme/update"),t.next=3,u.call("post",n,e);case 3:return r=t.sent,
t.abrupt("return",r);case 5:case"end":return t.stop()}}),t)})))()},listSubjects:function(e){return l(regeneratorRuntime.mark((function t(){var n,r;return regeneratorRuntime.wrap((function(t){
for(;;)switch(t.prev=t.next){case 0:return n=u.getCommandUri("subject/list"),t.next=3,u.call("get",n,e);case 3:return r=t.sent,t.abrupt("return",r);case 5:case"end":return t.stop()}}),t)})))()},
listSubjectsByStudyProgramme:function(e){return l(regeneratorRuntime.mark((function t(){var n,r;return regeneratorRuntime.wrap((function(t){for(;;)switch(t.prev=t.next){case 0:
return n=u.getCommandUri("subject/listByStudyProgramme"),t.next=3,u.call("get",n,e);case 3:return r=t.sent,t.abrupt("return",r);case 5:case"end":return t.stop()}}),t)})))()},getSubject:function(e){
return l(regeneratorRuntime.mark((function t(){var n,r;return regeneratorRuntime.wrap((function(t){for(;;)switch(t.prev=t.next){case 0:return n=u.getCommandUri("subject/get"),t.next=3,
u.call("get",n,e);case 3:return r=t.sent,t.abrupt("return",r);case 5:case"end":return t.stop()}}),t)})))()},createSubject:function(e){return l(regeneratorRuntime.mark((function t(){var n,r
;return regeneratorRuntime.wrap((function(t){for(;;)switch(t.prev=t.next){case 0:return n=u.getCommandUri("subject/create"),t.next=3,u.call("post",n,e);case 3:return r=t.sent,t.abrupt("return",r)
;case 5:case"end":return t.stop()}}),t)})))()},asignSubject:function(e){return l(regeneratorRuntime.mark((function t(){var n,r;return regeneratorRuntime.wrap((function(t){for(;;)switch(t.prev=t.next){
case 0:return n=u.getCommandUri("subject/assignSubject"),t.next=3,u.call("post",n,e);case 3:return r=t.sent,t.abrupt("return",r);case 5:case"end":return t.stop()}}),t)})))()},
removeSubject:function(e){return l(regeneratorRuntime.mark((function t(){var n,r;return regeneratorRuntime.wrap((function(t){for(;;)switch(t.prev=t.next){case 0:
return n=u.getCommandUri("subject/removeSubject"),t.next=3,u.call("post",n,e);case 3:return r=t.sent,t.abrupt("return",r);case 5:case"end":return t.stop()}}),t)})))()},listTopicsInSubject:function(e){
return l(regeneratorRuntime.mark((function t(){var n,r;return regeneratorRuntime.wrap((function(t){for(;;)switch(t.prev=t.next){case 0:return n=u.getCommandUri("topic/list"),t.next=3,u.call("get",n,e)
;case 3:return r=t.sent,t.abrupt("return",r);case 5:case"end":return t.stop()}}),t)})))()},addTopic:function(e){return l(regeneratorRuntime.mark((function t(){var n,r
;return regeneratorRuntime.wrap((function(t){for(;;)switch(t.prev=t.next){case 0:return n=u.getCommandUri("topic/create"),t.next=3,u.call("post",n,e);case 3:return r=t.sent,t.abrupt("return",r)
;case 5:case"end":return t.stop()}}),t)})))()},addDigitalContent:function(e){return l(regeneratorRuntime.mark((function t(){var n,r;return regeneratorRuntime.wrap((function(t){
for(;;)switch(t.prev=t.next){case 0:return n=u.getCommandUri("topic/digitalContentAdd"),t.next=3,u.call("post",n,e);case 3:return r=t.sent,t.abrupt("return",r);case 5:case"end":return t.stop()}}),t)
})))()},removeDigitalContent:function(e){return l(regeneratorRuntime.mark((function t(){var n,r;return regeneratorRuntime.wrap((function(t){for(;;)switch(t.prev=t.next){case 0:
return n=u.getCommandUri("topic/digitalContentRemove"),t.next=3,u.call("post",n,e);case 3:return r=t.sent,t.abrupt("return",r);case 5:case"end":return t.stop()}}),t)})))()},getCommandUri:function(e){
return u.APP_BASE_URI+e.replace(/^\/+/,"")}};t.a=u},function(e,t){e.exports=n},function(e,t){e.exports=r},function(e,t){e.exports=o},function(e,t,n){"use strict";t.a={appName:{cs:"Aplikace uuSubject",
en:"Application uuSubject"},left:{home:{cs:"Vítejte",en:"Welcome"},about:{cs:"O aplikaci",en:"About Application"},studyProgrammesList:{cs:"Studijní programy",en:"Study programmes"},subjectsList:{
cs:"Seznam předmětů",en:"Subjects list"}},about:{header:{cs:"O aplikaci uuSubject",en:"About application uuSubject"},creatorsHeader:{cs:"Tvůrci aplikace",en:"Application creators"},termsOfUse:{
cs:"Podmínky užívání",en:"Terms of use"}},bottom:{termsOfUse:{cs:"Podmínky užívání",en:"Terms of use"}},welcome:{cs:"Vítejte na stránkách aplikace uuSubjectMan",en:"Welcome to uuSubjectManApplication"
},auth:{welcome:{cs:"Vítejte",en:"Welcome"},intro:{
cs:'<uu5string/>Tato šablona obsahuje připravenou klientskou a serverovou část. Jednotlivé komponety, které jsou zde zobrazeny,\n          jsou určeny k tomu, aby demonstrovaly možnosti a způsob použití. Je vhodné je upravit, zkopírovat či smazat pro\n          potřeby vyvíjené aplikace. Více o struktuře uuApp se dozvíte v dokumetaci viz&nbsp;\n          <UU5.Bricks.Link\n            href="https://uuapp.plus4u.net/uu-bookkit-maing01/e884539c8511447a977c7ff070e7f2cf/book"\n            target="_blank"\n            content="uuAppDevKit"\n          />.',
en:'<uu5string/>This template consist of prepared client and server side. Shown components demonstrate possibilities and way of\n          using. For application developing purposes they are suitable for modifying, copying and deleting. More about\n          uuApp Structure see documentation&nbsp;\n          <UU5.Bricks.Link\n            href="https://uuapp.plus4u.net/uu-bookkit-maing01/e884539c8511447a977c7ff070e7f2cf/book/page?code=stepByStepApp"\n            target="_blank"\n            content="uuAppDevKit"\n          />.'
},clientSide:{cs:"<uu5string/>Klientská část je implementovaná s využitím komponent z knihoven <UU5.Bricks.LinkUU5 /> a <UU5.Bricks.LinkUuPlus4U5 />.",
en:"<uu5string/>Libraries <UU5.Bricks.LinkUU5/> and <UU5.Bricks.LinkUuPlus4U5 /> are used for developing of client side."},serverSide:{
cs:'<uu5string/>Pro spuštení serverové části je potřeba provést inicializaci workspace podle návodu viz\n          <UU5.Bricks.Link\n            href="https://uuapp.plus4u.net/uu-bookkit-maing01/e884539c8511447a977c7ff070e7f2cf/book/page?code=stepByStepApp"\n            target="_blank"\n            content="uuApp Template Developer Guide"\n          />.',
en:'<uu5string/>It is necessary to initialize application workspace for running server side. See manual\n          <UU5.Bricks.Link\n            href="https://uuapp.plus4u.net/uu-bookkit-maing01/e884539c8511447a977c7ff070e7f2cf/book/page?code=stepByStepApp"\n            target="_blank"\n            content="uuApp Template Developer Guide"\n          />.'
}},unauth:{welcome:{cs:"Vítej návštěvníku",en:"Welcome visitor"},continueToMain:{cs:"Pokračovat na web produktu",en:"Continue to the product web"},notAuthorized:{
cs:"Nemáte dostatečná práva k použití aplikace",en:"You do not have sufficient rights to use the application"}},unauthInit:{buyYourOwn:{cs:"Můžete si koupit vlastní uuSubject.",
en:"You can buy your own uuSubject."},notAuthorized:{cs:"Nemáte právo inicializovat tuto aplikaci uuSubject.",en:"You don't have rights to initialize this uuSubject."}},controlPanel:{rightsError:{
cs:"K zobrazení komponenty nemáte dostatečná práva.",en:"You do not have sufficient rights to display this component."},btNotConnected:{cs:"Aplikace není napojená na Business Territory",
en:"The application is not connected to a Business Territory"}}}},function(e,t,n){"use strict";var r=n(0),o=n.n(r),a=n(9);function c(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){
var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter((function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable}))),n.push.apply(n,r)}return n}function i(e){
for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{};t%2?c(Object(n),!0).forEach((function(t){l(e,t,n[t])
})):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):c(Object(n)).forEach((function(t){Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(n,t))}))
}return e}function l(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}var u=a.a.TAG+"Routes.";t.a=i(i({},a.a),{},{TAG:u,
Css:o.a.Common.Css.createCssModule(u.replace(/\.$/,"").toLowerCase().replace(/\./g,"-").replace(/[^a-z-]/g,""),"uu_subject_man-hi/uu_subject_man-hi@0.2.0")})},function(e,t,n){"use strict"
;var r=n(0),o=n.n(r),a="UuSubjectMan.";t.a={TAG:a,
Css:o.a.Common.Css.createCssModule(a.replace(/\.$/,"").toLowerCase().replace(/\./g,"-").replace(/[^a-z-]/g,""),"uu_subject_man-hi/uu_subject_man-hi@0.2.0")}},function(e,t){e.exports=a
},function(e,t,n){"use strict";e.exports=n(17)},function(e,t,n){e.exports=n(13)},function(e,t,n){function r(e){return(r="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(e){
return typeof e}:function(e){return e&&"function"==typeof Symbol&&e.constructor===Symbol&&e!==Symbol.prototype?"symbol":typeof e})(e)}
var o=n(14),a="undefined"!=typeof document,c=((o?o.uri:a&&(document.currentScript||Array.prototype.slice.call(document.getElementsByTagName("script"),-1)[0]||{}).src)||"").toString()
;"/0.0.0/"===(c=c.split(/\//).slice(0,-1).join("/")+"/").substr(-"/0.0.0/".length)&&(c=c.substr(0,c.length-"/0.0.0/".length)+"/0.2.0/"),n.p=c,e.exports=n(19);var i=e.exports
;i&&"object"===r(i)&&("version"in i||(i.version="0.2.0"),"name"in i||(i.name="uu_subject_man-hi".split(/[\/\\]/).pop()),"namespace"in i||(i.namespace="UuSubjectMan"))},function(e,t){e.exports=c
},function(e,t){e.exports=i},function(e,t){e.exports=l},function(e,t,n){"use strict";Object.defineProperty(t,"__esModule",{value:!0});var r,o=(r=n(18))&&"object"==typeof r&&"default"in r?r.default:r
;function a(e){return a.warnAboutHMRDisabled&&(a.warnAboutHMRDisabled=!0,console.error("React-Hot-Loader: misconfiguration detected, using production version in non-production environment."),
console.error("React-Hot-Loader: Hot Module Replacement is not enabled.")),o.Children.only(e.children)}a.warnAboutHMRDisabled=!1;var c=function e(){return e.shouldWrapWithAppContainer?function(e){
return function(t){return o.createElement(a,null,o.createElement(e,t))}}:function(e){return e}};c.shouldWrapWithAppContainer=!1;t.AppContainer=a,t.hot=c,t.areComponentsEqual=function(e,t){return e===t
},t.setConfig=function(){},t.cold=function(e){return e},t.configureComponent=function(){}},function(e,t){e.exports=u},function(e,t,n){"use strict";n.r(t),n.d(t,"render",(function(){return Fn}))
;var r=n(11),o=n(0),a=n.n(o),c=n(1),i=n(6),l=n.n(i),u=(n(10),n(2)),s=(n(4),n(7));function m(){return(m=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var n=arguments[t]
;for(var r in n)Object.prototype.hasOwnProperty.call(n,r)&&(e[r]=n[r])}return e}).apply(this,arguments)}function d(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){
var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter((function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable}))),n.push.apply(n,r)}return n}function p(e){
for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{};t%2?d(Object(n),!0).forEach((function(t){f(e,t,n[t])
})):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):d(Object(n)).forEach((function(t){Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(n,t))}))
}return e}function f(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}var b,g={displayName:u.a.TAG+"Left"
},C=Object(c.createVisualComponent)(p(p({},g),{},{render:function(e){return a.a.Common.Element.create(l.a.App.Left,m({},e,{logoProps:{backgroundColor:a.a.Environment.colors.blue.c700,
backgroundColorTo:a.a.Environment.colors.blue.c500,title:"uuSubject",companyLogo:l.a.Environment.basePath+"assets/img/unicorn-logo.svg",generation:"1"},aboutItems:[{
content:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:s.a.left.about}),href:"about"}],helpHref:null}),a.a.Common.Element.create(l.a.App.MenuTree,{borderBottom:!0,items:[{id:"home",href:"home",
content:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:s.a.left.home})},{id:"studyProgrammes",href:"studyProgrammes",content:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:s.a.left.studyProgrammesList})
},{id:"subjectsList",href:"subjectsList",content:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:s.a.left.subjectsList})}]}))}}));function v(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){
var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter((function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable}))),n.push.apply(n,r)}return n}function y(e){
for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{};t%2?v(Object(n),!0).forEach((function(t){O(e,t,n[t])
})):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):v(Object(n)).forEach((function(t){Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(n,t))}))
}return e}function O(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}var h={displayName:u.a.TAG+"Bottom"},j=function(){
return u.a.Css.css(b||(e=["\n    padding: 8px 0;\n    text-align: center;\n    border-top: 1px solid rgba(0, 0, 0, 0.12);\n    color: gray;\n  "],t||(t=e.slice(0)),
b=Object.freeze(Object.defineProperties(e,{raw:{value:Object.freeze(t)}}))));var e,t},k=Object(c.createVisualComponent)(y(y({},h),{},{render:function(e){
var t=a.a.Common.VisualComponent.getAttrs(e,j());return a.a.Common.Element.create("div",t,"uuSubjectMan-","0.2.0"," © Unicorn,"," ",a.a.Common.Element.create(a.a.Bricks.Link,{target:"_blank",
href:"TODO"},a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:s.a.bottom.termsOfUse})))}})),E=(n(15),n(16),n(8)),P=n(9);function w(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){
var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter((function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable}))),n.push.apply(n,r)}return n}function B(e){
for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{};t%2?w(Object(n),!0).forEach((function(t){S(e,t,n[t])
})):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):w(Object(n)).forEach((function(t){Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(n,t))}))
}return e}function S(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}var L,D,x,A,T=P.a.TAG+"Bricks.",R=B(B({},P.a),{},{TAG:T,
Css:a.a.Common.Css.createCssModule(T.replace(/\.$/,"").toLowerCase().replace(/\./g,"-").replace(/[^a-z-]/g,""),"uu_subject_man-hi/uu_subject_man-hi@0.2.0")});function U(e,t){var n=Object.keys(e)
;if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter((function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable}))),n.push.apply(n,r)}return n}function F(e){
for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{};t%2?U(Object(n),!0).forEach((function(t){N(e,t,n[t])
})):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):U(Object(n)).forEach((function(t){Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(n,t))}))
}return e}function N(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}function z(e,t){return t||(t=e.slice(0)),
Object.freeze(Object.defineProperties(e,{raw:{value:Object.freeze(t)}}))}var _,V={displayName:R.TAG+"WelcomeRow"},M=function(){
return R.Css.css(L||(L=z(["\n    padding: 24px 0;\n    max-width: 624px;\n    margin: 0 auto;\n  "])))},I=function(){
return R.Css.css(D||(D=z(["\n    text-align: center;\n\n    ","\n  "])),a.a.Utils.ScreenSize.getMinMediaQueries("s","text-align: left;"))},q=function(){
return R.Css.css(x||(x=z(["\n    padding-right: 24px;\n    text-align: center;\n  \n    ","\n  \n    .uu5-bricks-icon {\n      font-size: 48px;\n    }\n  "])),a.a.Utils.ScreenSize.getMinMediaQueries("s","text-align: right;"))
},W=function(e){return R.Css.css(A||(A=z(["\n    margin-top: ",";\n    margin-bottom: ",";\n  "])),e,e)},G=Object(c.createVisualComponent)(F(F({},V),{},{propTypes:{icon:a.a.PropTypes.string,
textPadding:a.a.PropTypes.string},defaultProps:{icon:void 0,textPadding:null},render:function(e){
var t=e.icon,n=e.textPadding,r=e.children,o=a.a.Common.Tools.fillUnit("-"+n),c=a.a.Common.VisualComponent.getAttrs(e,M())
;return a.a.Common.Element.create(a.a.Bricks.Row,c,a.a.Common.Element.create(a.a.Bricks.Column,{className:q(),colWidth:"xs-12 s-2"},a.a.Common.Element.create(a.a.Bricks.Icon,{icon:t,className:W(o)
})),a.a.Common.Element.create(a.a.Bricks.Column,{className:I(),colWidth:"xs-12 s-10",content:a.a.Utils.Content.getChildren(r,e,V)}))}}));function H(e,t){var n=Object.keys(e)
;if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter((function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable}))),n.push.apply(n,r)}return n}function Y(e){
for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{};t%2?H(Object(n),!0).forEach((function(t){K(e,t,n[t])
})):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):H(Object(n)).forEach((function(t){Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(n,t))}))
}return e}function K(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}var $={displayName:E.a.TAG+"Home"},J=function(){
return E.a.Css.css(_||(e=["\n    padding: 56px 0 20px;\n    max-width: 624px;\n    margin: 0 auto;\n    text-align: center;\n  \n    ","\n  \n    .uu5-bricks-header {\n      margin-top: 8px;\n    }\n    \n    .plus4u5-bricks-user-photo {\n      margin: 0 auto;\n    }\n  "],
t||(t=e.slice(0)),_=Object.freeze(Object.defineProperties(e,{raw:{value:Object.freeze(t)}}))),a.a.Utils.ScreenSize.getMinMediaQueries("s","text-align: left;"));var e,t
},Z=Object(c.createVisualComponent)(Y(Y({},$),{},{render:function(e){var t=a.a.Common.VisualComponent.getAttrs(e)
;return a.a.Common.Element.create("div",t,a.a.Common.Element.create(l.a.App.ArtifactSetter,{territoryBaseUri:"",artifactId:""}),a.a.Common.Element.create(a.a.Bricks.Row,{className:J()
},a.a.Common.Element.create(a.a.Bricks.Column,null,a.a.Common.Element.create(a.a.Bricks.Header,{level:"3",content:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:s.a.welcome})
}))),a.a.Common.Element.create(a.a.Bricks.Row,{className:J()}),a.a.Common.Element.create(G,{textPadding:"14px",icon:"mdi-human-greeting"},a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:s.a.auth.intro
})),a.a.Common.Element.create(G,{textPadding:"10px",icon:"mdi-monitor"},a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:s.a.auth.clientSide})),a.a.Common.Element.create(G,{textPadding:"8px",
icon:"mdi-server"},a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:s.a.auth.serverSide})))}})),Q={header:{cs:"Přídání studijního programu",en:"Add new study programme"},info:{
cs:"Přídání studijního programu",en:"Add new study programme"},form:{name:{cs:"Název",en:"Name"},description:{cs:"Popis",en:"Description"},degree:{bachelor:{cs:"Bakalářské",en:"Bachelor"},magister:{
cs:"Magisterské",en:"Magister"},cs:"Stupeň vzdělání",en:"Degree"},form:{fullTime:{cs:"Prezenční",en:"Full time"},partTime:{cs:"Distanční",en:"Part time"},cs:"Forma vyučování",en:"Form"},languages:{
czech:{cs:"Česky",en:"Czech"},english:{cs:"Anglicky",en:"English"},cs:"Vyučovací jazyk",en:"Language"},credits:{cs:"Počet kreditů za celé studium",en:"Credist per studium"}},submit:{cs:"Přidej",
en:"Add"}},X=Object(c.createVisualComponentWithRef)({displayName:R.TAG+"StudyProgrammeAddForm",propTypes:{studyProgramme:a.a.PropTypes.object,onSave:a.a.PropTypes.func,onSaveDone:a.a.PropTypes.func,
onSaveFail:a.a.PropTypes.func,onCancel:a.a.PropTypes.func},defaultProps:{studyProgramme:null,onSave:function(){},onSaveDone:function(){},onSaveFail:function(){},onCancel:function(){}},
render:function(e){return a.a.Common.Element.create(a.a.Forms.Form,{onSave:e.onSave,onSaveDone:e.onSaveDone,onSaveFail:e.onSaveFail,onCancel:e.onCancel},a.a.Common.Element.create(a.a.Forms.Text,{
label:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:Q.form.name}),name:"name",value:null!=e&&e.studyProgramme?null==e?void 0:e.studyProgramme.name:void 0,inputAttrs:{maxLength:255},controlled:!1,
required:!0}),a.a.Common.Element.create(a.a.Forms.Text,{label:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:Q.form.description}),name:"description",
value:null!=e&&e.studyProgramme?null==e?void 0:e.studyProgramme.description:void 0,inputAttrs:{maxLength:255},controlled:!1}),a.a.Common.Element.create(a.a.Forms.Select,{
label:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:Q.form.degree}),name:"degree",value:null!=e&&e.studyProgramme?null==e?void 0:e.studyProgramme.degree:void 0,required:!0
},a.a.Common.Element.create(a.a.Forms.Select.Option,{value:"bachelor",content:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:Q.form.degree.bachelor})
}),a.a.Common.Element.create(a.a.Forms.Select.Option,{value:"magister",content:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:Q.form.degree.magister})})),a.a.Common.Element.create(a.a.Forms.Select,{
label:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:Q.form.form}),name:"forms",value:null!=e&&e.studyProgramme?null==e?void 0:e.studyProgramme.forms:void 0,required:!0
},a.a.Common.Element.create(a.a.Forms.Select.Option,{value:"full-time",content:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:Q.form.form.fullTime})
}),a.a.Common.Element.create(a.a.Forms.Select.Option,{value:"part-time",content:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:Q.form.form.partTime})})),a.a.Common.Element.create(a.a.Forms.Select,{
label:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:Q.form.languages}),name:"languages",value:null!=e&&e.studyProgramme?null==e?void 0:e.studyProgramme.languages:void 0,required:!0
},a.a.Common.Element.create(a.a.Forms.Select.Option,{value:"CZ",content:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:Q.form.languages.czech})}),a.a.Common.Element.create(a.a.Forms.Select.Option,{
value:"EN",content:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:Q.form.languages.english})})),a.a.Common.Element.create(a.a.Forms.Number,{label:a.a.Common.Element.create(a.a.Bricks.Lsi,{
lsi:Q.form.credits}),name:"credits",value:null!=e&&e.studyProgramme?null==e?void 0:e.studyProgramme.credits:void 0,min:0,max:300,step:1,valueType:"number",required:!0
}),a.a.Common.Element.create(a.a.Forms.Controls,{controlled:!1}))}}),ee=n(3),te=n(5),ne=n.n(te);var re,oe,ae,ce,ie={menuActions:{editProgramme:{cs:"Edituj stud. program",en:"Edit programme"}},
tile:(re={header:{cs:"Studijní program",en:"Study programme"},name:{cs:"Název: ",en:"Name: "},description:{cs:"Popis: ",en:"Descr.: "},form:{cs:"Forma: ",en:"Form: "},language:{cs:"Jazyk: ",
en:"Lang.: "},degree:{cs:"Stupeň vzdělání: ",en:"Study degree: "}},oe="degree",ae={cs:"Vytvořeno: ",en:"Created: "},oe in re?Object.defineProperty(re,oe,{value:ae,enumerable:!0,configurable:!0,
writable:!0}):re[oe]=ae,re)};function le(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter((function(t){
return Object.getOwnPropertyDescriptor(e,t).enumerable}))),n.push.apply(n,r)}return n}function ue(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{}
;t%2?le(Object(n),!0).forEach((function(t){se(e,t,n[t])})):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):le(Object(n)).forEach((function(t){
Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(n,t))}))}return e}function se(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}
var me,de={displayName:"UU5.Bricks.VisualComponent",nestingLevel:"bigBoxCollection"},pe=Object(c.createVisualComponent)(ue(ue({},de),{},{propTypes:{data:a.a.PropTypes.object,
handleOpen:a.a.PropTypes.func,handleUpdate:a.a.PropTypes.func},defaultProps:{data:null,handleOpen:function(){},handleUpdate:function(){}},render:function(e){var t,n,r,o,c,i,l,s,m=[{icon:"mdi-pencil",
content:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:ie.menuActions.editProgramme}),onClick:function(){return e.handleUpdate(e.data)}}],d=u.a.Css.css(ce||(l=[""],s||(s=l.slice(0)),
ce=Object.freeze(Object.defineProperties(l,{raw:{value:Object.freeze(s)}
})))),p=a.a.Common.VisualComponent.getAttrs(e,d),f=a.a.Utils.NestingLevel.getNestingLevel(e,de),b=a.a.Common.Element.create("div",p,a.a.Utils.Content.getChildren(e.children,e,de))
;return f?a.a.Common.Element.create("div",p,a.a.Common.Element.create(a.a.BlockLayout.Tile,null,a.a.Common.Element.create(a.a.BlockLayout.Block,{actions:m
},a.a.Common.Element.create(a.a.BlockLayout.Row,null,a.a.Common.Element.create(a.a.Bricks.Link,null,a.a.Common.Element.create(a.a.BlockLayout.Text,{weight:"primary"
},a.a.Common.Element.create(a.a.Bricks.Link,{onClick:function(){return e.handleOpen(e.data.data)}},a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:ie.tile.header
})))))),a.a.Common.Element.create(a.a.BlockLayout.Line,null),a.a.Common.Element.create(a.a.BlockLayout.Block,null,a.a.Common.Element.create(a.a.BlockLayout.Row,null,a.a.Common.Element.create(a.a.Bricks.Row,null,a.a.Common.Element.create(a.a.Bricks.Column,{
colWidth:"xs-4"},a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:ie.tile.name})),a.a.Common.Element.create(a.a.Bricks.Column,{colWidth:"xs-8"
},null===(t=e.data.data)||void 0===t?void 0:t.name))),a.a.Common.Element.create(a.a.BlockLayout.Row,null,a.a.Common.Element.create(a.a.Bricks.Row,null,a.a.Common.Element.create(a.a.Bricks.Column,{
colWidth:"xs-4"},a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:ie.tile.description})),a.a.Common.Element.create(a.a.Bricks.Column,{colWidth:"xs-8"
},null===(n=e.data.data)||void 0===n?void 0:n.description))),a.a.Common.Element.create(a.a.BlockLayout.Row,null,a.a.Common.Element.create(a.a.Bricks.Row,null,a.a.Common.Element.create(a.a.Bricks.Column,{
colWidth:"xs-4"},a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:ie.tile.form})),a.a.Common.Element.create(a.a.Bricks.Column,{colWidth:"xs-8"
},null===(r=e.data.data)||void 0===r?void 0:r.forms))),a.a.Common.Element.create(a.a.BlockLayout.Row,null,a.a.Common.Element.create(a.a.Bricks.Row,null,a.a.Common.Element.create(a.a.Bricks.Column,{
colWidth:"xs-4"},a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:ie.tile.language})," "),a.a.Common.Element.create(a.a.Bricks.Column,{colWidth:"xs-8"
},null===(o=e.data.data)||void 0===o?void 0:o.languages))),a.a.Common.Element.create(a.a.BlockLayout.Row,null,a.a.Common.Element.create(a.a.Bricks.Row,null,a.a.Common.Element.create(a.a.Bricks.Column,{
colWidth:"xs-4"},a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:ie.tile.degree})," "),a.a.Common.Element.create(a.a.Bricks.Column,{colWidth:"xs-8"
},null===(c=e.data.data)||void 0===c?void 0:c.degree))),a.a.Common.Element.create(a.a.BlockLayout.Row,null,a.a.Common.Element.create(a.a.Bricks.Row,null,a.a.Common.Element.create(a.a.Bricks.Column,{
colWidth:"xs-4"},a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:ie.tile.created})),a.a.Common.Element.create(a.a.Bricks.Column,{colWidth:"xs-8"},a.a.Common.Element.create(a.a.Bricks.DateTime,{
timeZone:a.a.Environment.dateTimeZone,value:null===(i=e.data.data)||void 0===i?void 0:i.sys.cts}))))))):a.a.Common.Element.create(a.a.Bricks.LinkModal,{children:"Visual Component",hidden:e.hidden,
component:b})}}));function fe(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter((function(t){
return Object.getOwnPropertyDescriptor(e,t).enumerable}))),n.push.apply(n,r)}return n}function be(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{}
;t%2?fe(Object(n),!0).forEach((function(t){ge(e,t,n[t])})):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):fe(Object(n)).forEach((function(t){
Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(n,t))}))}return e}function ge(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}
var Ce,ve={displayName:"UU5.Bricks.VisualComponent",nestingLevel:"bigBoxCollection"},ye=Object(c.createVisualComponent)(be(be({},ve),{},{propTypes:{data:a.a.PropTypes.array,
handleOpen:a.a.PropTypes.func,handleCreate:a.a.PropTypes.func,handleUpdate:a.a.PropTypes.func},defaultProps:{data:[],handleOpen:function(){},handleCreate:function(){},handleUpdate:function(){}},
render:function(e){Object(c.useRef)();var t,n,r,o=u.a.Css.css(me||(n=[""],r||(r=n.slice(0)),me=Object.freeze(Object.defineProperties(n,{raw:{value:Object.freeze(r)}
})))),i=a.a.Common.VisualComponent.getAttrs(e,o),l=a.a.Utils.NestingLevel.getNestingLevel(e,ve),s=a.a.Common.Element.create("div",i,a.a.Utils.Content.getChildren(e.children,e,ve))
;return l?a.a.Common.Element.create("div",i,a.a.Common.Element.create(ne.a.ControllerProvider,{data:e.data?e.data:[]},a.a.Common.Element.create(ne.a.ActionBar,{title:"",actions:function(t){
t.screenSize;return[{content:{en:"Add study programme",cs:"Přidej studijní program"},onClick:function(){null==e||e.handleCreate()},icon:"mdi-plus-circle",colorSchema:"primary",bgStyle:"filled",
active:!0}]}}),a.a.Common.Element.create(ne.a.Grid,{tileMinWidth:200,tileMaxWidth:500,tileSpacing:8,rowSpacing:8},a.a.Common.Element.create(pe,{key:null===(t=e.data)||void 0===t?void 0:t.id,
handleOpen:e.handleOpen,handleUpdate:e.handleUpdate})))):a.a.Common.Element.create(a.a.Bricks.LinkModal,{children:"Visual Component",hidden:e.hidden,component:s})}})),Oe={header:{
cs:"Studijní programy",en:"Study programmes"},info:{cs:"Přídání studijního programu",en:"Add new study programme"},modal:{header:{creation:{cs:"Vytvoření studijního programu",
en:"Creation of study programme"},edit:{cs:"Editace studijního programu",en:"Edit of study programme"}},onSaveDone:{creation:{cs:"Úspěšně vytvořeno",en:"Successfully created"},edit:{
cs:"Úspěšně upraveno",en:"Successfully edited"}},onSaveFail:{creation:{cs:"Chyba běhěm vytváření",en:"Error has occured during creation"},edit:{cs:"Chyba běhěm editace",
en:"Error has occured during editing"}}}};function he(e,t,n,r,o,a,c){try{var i=e[a](c),l=i.value}catch(e){return void n(e)}i.done?t(l):Promise.resolve(l).then(r,o)}function je(e){return function(){
var t=this,n=arguments;return new Promise((function(r,o){var a=e.apply(t,n);function c(e){he(a,r,o,c,i,"next",e)}function i(e){he(a,r,o,c,i,"throw",e)}c(void 0)}))}}function ke(e,t){
var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter((function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable}))),n.push.apply(n,r)}
return n}function Ee(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{};t%2?ke(Object(n),!0).forEach((function(t){Pe(e,t,n[t])
})):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):ke(Object(n)).forEach((function(t){Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(n,t))
}))}return e}function Pe(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}var we,Be={displayName:"UU5.Bricks.VisualComponent",
nestingLevel:"bigBoxCollection"},Se=Object(c.createVisualComponent)(Ee(Ee({},Be),{},{propTypes:{},defaultProps:{},render:function(e){var t,n,r=function(e){
a.a.Environment.setRoute("studyProgrammeDetail",{id:e.id})},o=E.a.Css.css(Ce||(t=[""],n||(n=t.slice(0)),Ce=Object.freeze(Object.defineProperties(t,{raw:{value:Object.freeze(n)}
})))),i=a.a.Common.VisualComponent.getAttrs(e,o),l=a.a.Utils.NestingLevel.getNestingLevel(e,Be),u=Object(c.useDataList)({handlerMap:{load:ee.a.listStudyProgrammes,createItem:ee.a.createStudyProgramme
},itemHandlerMap:{load:ee.a.getStudyProgramme,update:ee.a.updateStudyProgramme},initialDtoIn:{pageInfo:{}}}),s=u.state,m=u.data,d=(u.newData,u.pendingData,
u.errorData),p=u.handlerMap,f=Object(c.useRef)(),b=Object(c.useRef)(),g=Object(c.useRef)(),C=Object(c.useCallback)((function(e,t){var n=b.current;n.open({
header:e?a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:Oe.modal.header.edit}):a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:Oe.modal.header.creation}),content:a.a.Common.Element.create(X,{onSave:t,
onSaveDone:function(t){n.close(),t.component.getAlertBus().setAlert({content:e?a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:Oe.modal.onSaveDone.edit}):a.a.Common.Element.create(a.a.Bricks.Lsi,{
lsi:Oe.modal.onSaveDone.creation}),colorSchema:"success"})},onSaveFail:function(t){console.debug(t),t.component.getAlertBus().setAlert({content:e?a.a.Common.Element.create(a.a.Bricks.Lsi,{
lsi:Oe.modal.onSaveFail.edit}):a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:Oe.modal.onSaveFail.creation}),colorSchema:"danger"})},onCancel:function(){return n.close()},studyProgramme:e})})
}),[]),v=Object(c.useCallback)((function(){C(null,function(){var e=je(regeneratorRuntime.mark((function e(t){var n,r,o,a;return regeneratorRuntime.wrap((function(e){for(;;)switch(e.prev=e.next){
case 0:return n=t.component,r=t.values,e.prev=1,e.next=4,p.createItem(r);case 4:o=e.sent,e.next=11;break;case 7:e.prev=7,e.t0=e.catch(1),a=e.t0,console.error(a);case 11:if(!g.current){e.next=13;break}
return e.abrupt("return");case 13:a?n.saveFail(a):n.saveDone(o);case 14:case"end":return e.stop()}}),e,null,[[1,7]])})));return function(t){return e.apply(this,arguments)}}())
}),[C,p.createItem,p.load,g]),y=Object(c.useCallback)((function(e){console.debug(e),C(e.data,function(){var t=je(regeneratorRuntime.mark((function t(n){var r,o,a,c
;return regeneratorRuntime.wrap((function(t){for(;;)switch(t.prev=t.next){case 0:return r=n.component,o=n.values,t.prev=1,t.next=4,e.handlerMap.update(o);case 4:a=t.sent,t.next=11;break;case 7:
t.prev=7,t.t0=t.catch(1),c=t.t0,console.error(c);case 11:if(!g.current){t.next=13;break}return t.abrupt("return");case 13:c?r.saveFail(c):r.saveDone(a),c||e.data.name===a.name||p.load();case 15:
case"end":return t.stop()}}),t,null,[[1,7]])})));return function(e){return t.apply(this,arguments)}}())
}),[C,p.load,g]),O=a.a.Common.Element.create("div",i,a.a.Utils.Content.getChildren(e.children,e,Be));return l?a.a.Common.Element.create("div",i,a.a.Common.Element.create(a.a.Bricks.Section,{
header:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:Oe.header})},function(){var e;switch(s){case"pendingNoData":case"pending":e=a.a.Common.Element.create(a.a.Bricks.Loading,null);break;case"ready":
case"readyNoData":e=a.a.Common.Element.create(ye,{data:m,handleOpen:r,handleCreate:v,handleUpdate:y});break;case"error":case"errorNoData":e=a.a.Common.Element.create(a.a.Common.Error,{errorData:d})}
return e}()),a.a.Common.Element.create(a.a.Bricks.AlertBus,{ref_:f}),a.a.Common.Element.create(a.a.Bricks.Modal,{controlled:!1,ref_:b,mountContent:"onEachOpen",overflow:!0
})):a.a.Common.Element.create(a.a.Bricks.LinkModal,{children:"Visual Component",hidden:e.hidden,component:O})}}));var Le,De=function(){
return u.a.Css.css(we||(e=["\n  margin: 0 24px;\n  padding: 6px\n"],t||(t=e.slice(0)),we=Object.freeze(Object.defineProperties(e,{raw:{value:Object.freeze(t)}}))));var e,t};function xe(e,t){
var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter((function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable}))),n.push.apply(n,r)}
return n}function Ae(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{};t%2?xe(Object(n),!0).forEach((function(t){Te(e,t,n[t])
})):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):xe(Object(n)).forEach((function(t){Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(n,t))
}))}return e}function Te(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}var Re,Ue={displayName:"UU5.Bricks.VisualComponent",
nestingLevel:"bigBoxCollection"},Fe=Object(c.createVisualComponent)(Ae(Ae({},Ue),{},{propTypes:{data:a.a.PropTypes.object},defaultProps:{data:null},render:function(e){
var t,n,r,o=u.a.Css.css(Le||(n=[""],r||(r=n.slice(0)),Le=Object.freeze(Object.defineProperties(n,{raw:{value:Object.freeze(r)}
})))),c=a.a.Common.VisualComponent.getAttrs(e,o),i=a.a.Utils.NestingLevel.getNestingLevel(e,Ue),l=a.a.Common.Element.create("div",c,a.a.Utils.Content.getChildren(e.children,e,Ue))
;return i?a.a.Common.Element.create("div",c,a.a.Common.Element.create(a.a.Bricks.Card,{className:De()},a.a.Common.Element.create(a.a.Bricks.Section,{header:null===(t=e.data)||void 0===t?void 0:t.name,
underline:!0,level:2},a.a.Common.Element.create(a.a.BlockLayout.Block,null,a.a.Common.Element.create(a.a.BlockLayout.Row,null,a.a.Common.Element.create(a.a.BlockLayout.Column,{width:300
},"Name"),a.a.Common.Element.create(a.a.BlockLayout.Column,{textAlign:"left"},e.data.name)),a.a.Common.Element.create(a.a.BlockLayout.Row,null,a.a.Common.Element.create(a.a.BlockLayout.Column,{
width:300},"Description"),a.a.Common.Element.create(a.a.BlockLayout.Column,{textAlign:"left"
},e.data.description)),a.a.Common.Element.create(a.a.BlockLayout.Line,null),a.a.Common.Element.create(a.a.BlockLayout.Row,null,a.a.Common.Element.create(a.a.BlockLayout.Column,{width:300
},"Degree"),a.a.Common.Element.create(a.a.BlockLayout.Column,{textAlign:"left"},e.data.degree)),a.a.Common.Element.create(a.a.BlockLayout.Row,null,a.a.Common.Element.create(a.a.BlockLayout.Column,{
width:300},"Form"),a.a.Common.Element.create(a.a.BlockLayout.Column,{textAlign:"left"
},e.data.forms)),a.a.Common.Element.create(a.a.BlockLayout.Row,null,a.a.Common.Element.create(a.a.BlockLayout.Column,{width:300},"Languages"),a.a.Common.Element.create(a.a.BlockLayout.Column,{
textAlign:"left"},e.data.languages)),a.a.Common.Element.create(a.a.BlockLayout.Line,null),a.a.Common.Element.create(a.a.BlockLayout.Row,null,a.a.Common.Element.create(a.a.BlockLayout.Column,{width:300
},"Credits"),a.a.Common.Element.create(a.a.BlockLayout.Column,{textAlign:"left"
},e.data.credits)),a.a.Common.Element.create(a.a.BlockLayout.Line,null),a.a.Common.Element.create(a.a.BlockLayout.Row,null,a.a.Common.Element.create(a.a.BlockLayout.Column,{width:300
},"State"),a.a.Common.Element.create(a.a.BlockLayout.Column,{textAlign:"left"},e.data.state)))))):a.a.Common.Element.create(a.a.Bricks.LinkModal,{children:"Visual Component",hidden:e.hidden,
component:l})}})),Ne={header:{cs:"Předměty",en:"Subjects"},info:{cs:"Přídání předmětu",en:"Add new subject"},modal:{header:{creation:{cs:"Vytvoření předmětu",en:"Creation of subject"},edit:{
cs:"Editace předmětu",en:"Edit of subject"}},onSaveDone:{creation:{cs:"Úspěšně vytvořeno",en:"Successfully created"},edit:{cs:"Úspěšně upraveno",en:"Successfully edited"}},onSaveFail:{creation:{
cs:"Chyba běhěm vytváření",en:"Error has occured during creation"},edit:{cs:"Chyba běhěm editace",en:"Error has occured during editing"}}}};function ze(e,t){var n=Object.keys(e)
;if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter((function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable}))),n.push.apply(n,r)}return n}
function _e(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{};t%2?ze(Object(n),!0).forEach((function(t){Ve(e,t,n[t])
})):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):ze(Object(n)).forEach((function(t){Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(n,t))
}))}return e}function Ve(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}var Me,Ie={displayName:"UU5.Bricks.VisualComponent",
nestingLevel:"bigBoxCollection"},qe=Object(c.createVisualComponent)(_e(_e({},Ie),{},{propTypes:{data:a.a.PropTypes.array,studyProgrammeId:a.a.PropTypes.string,handleSubjectAdd:a.a.PropTypes.func,
handleSubjectRemove:a.a.PropTypes.func},defaultProps:{data:[],studyProgrammeId:"",handleSubjectAdd:function(){},handleSubjectRemove:function(){}},render:function(e){var t,n,r=[{cell:function(e){
return a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:e.data.data.name})},header:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:{en:"Species",cs:"Název"}})},{cell:function(e){
return a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:e.data.data.credits})},header:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:{en:"Credits",cs:"Kredity"}})},{cell:function(t){var n
;return a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:null===(n=t.data.data.studyProgrammes.find((function(t){return t.studyProgrammeId===(null==e?void 0:e.studyProgrammeId)
})))||void 0===n?void 0:n.semester})},header:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:{en:"semester",cs:"semester"}})},{cell:function(t){return a.a.Common.Element.create(a.a.Bricks.Button,{
content:"Odstaň",onClick:function(){e.handleSubjectRemove(t.data.data.id)}})},cellPadding:"4px 8px"}],o=(Object(c.useRef)(),u.a.Css.css(Re||(t=[""],n||(n=t.slice(0)),
Re=Object.freeze(Object.defineProperties(t,{raw:{value:Object.freeze(n)}
}))))),i=a.a.Common.VisualComponent.getAttrs(e,o),l=a.a.Utils.NestingLevel.getNestingLevel(e,Ie),s=a.a.Common.Element.create("div",i,a.a.Utils.Content.getChildren(e.children,e,Ie))
;return l?a.a.Common.Element.create("div",i,a.a.Common.Element.create(ne.a.ControllerProvider,{data:e.data?e.data:[]},a.a.Common.Element.create(ne.a.ActionBar,{title:"",actions:function(t){
t.screenSize;return[{content:{en:"Add subject",cs:"Přidej předmět"},onClick:function(){null==e||e.handleSubjectAdd()},icon:"mdi-plus-circle",colorSchema:"primary",bgStyle:"filled",active:!0}]}
}),a.a.Common.Element.create(ne.a.List,{rowPadding:"4px 16px",tileRowSpacing:8,tileListPadding:"8px 16px",columns:r}))):a.a.Common.Element.create(a.a.Bricks.LinkModal,{children:"Visual Component",
hidden:e.hidden,component:s})}})),We={header:{cs:"Vyber předěmět",en:"Select subjects"},info:{cs:"Vybrání předmětu",en:"Subject selection"},form:{subjects:{cs:"Předměty",en:"Subjects"},semester:{
cs:"Semestr",en:"Sememster"}},submit:{cs:"Přidej",en:"Add"}},Ge=Object(c.createVisualComponentWithRef)({displayName:R.TAG+"SubjectsSelectModal",propTypes:{onSave:a.a.PropTypes.func,
onSaveDone:a.a.PropTypes.func,onSaveFail:a.a.PropTypes.func,onCancel:a.a.PropTypes.func},defaultProps:{onSave:function(){},onSaveDone:function(){},onSaveFail:function(){},onCancel:function(){}},
render:function(e){var t=Object(c.useDataList)({handlerMap:{load:ee.a.listSubjects},itemHandlerMap:{},initialDtoIn:{pageInfo:{}}}),n=t.state,r=t.data,o=(t.newData,t.pendingData,t.errorData)
;t.handlerMap;return a.a.Common.Element.create(a.a.Common.Fragment,null,function(){var t;switch(n){case"pendingNoData":case"pending":t=a.a.Common.Element.create(a.a.Bricks.Loading,null);break
;case"ready":case"readyNoData":t=a.a.Common.Element.create(a.a.Common.Fragment,null,a.a.Common.Element.create(a.a.Forms.Form,{onSave:e.onSave,onSaveDone:e.onSaveDone,onSaveFail:e.onSaveFail,
onCancel:e.onCancel},a.a.Common.Element.create(a.a.Forms.Select,{label:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:We.form.subjects}),name:"subjectId",required:!0},null==r?void 0:r.map((function(e){
return a.a.Common.Element.create(a.a.Forms.Select.Option,{key:e.data.id,value:e.data.id,content:e.data.name})}))),a.a.Common.Element.create(a.a.Forms.Number,{
label:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:We.form.semester}),name:"semester",value:0,min:0,max:10,step:1,valueType:"number",required:!0}),a.a.Common.Element.create(a.a.Forms.Controls,{
controlled:!1})));break;case"error":case"errorNoData":t=a.a.Common.Element.create(a.a.Common.Error,{errorData:o})}return t}())}});function He(e,t,n,r,o,a,c){try{var i=e[a](c),l=i.value}catch(e){
return void n(e)}i.done?t(l):Promise.resolve(l).then(r,o)}function Ye(e){return function(){var t=this,n=arguments;return new Promise((function(r,o){var a=e.apply(t,n);function c(e){
He(a,r,o,c,i,"next",e)}function i(e){He(a,r,o,c,i,"throw",e)}c(void 0)}))}}function Ke(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e)
;t&&(r=r.filter((function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable}))),n.push.apply(n,r)}return n}function $e(e){for(var t=1;t<arguments.length;t++){
var n=null!=arguments[t]?arguments[t]:{};t%2?Ke(Object(n),!0).forEach((function(t){Je(e,t,n[t])
})):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):Ke(Object(n)).forEach((function(t){Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(n,t))
}))}return e}function Je(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}var Ze,Qe={displayName:"UU5.Bricks.VisualComponent",
nestingLevel:"bigBoxCollection"},Xe=Object(c.createVisualComponent)($e($e({},Qe),{},{propTypes:{studyProgrammeId:a.a.PropTypes.string},defaultProps:{studyProgrammeId:""},render:function(e){
var t,n,r=u.a.Css.css(Me||(t=[""],n||(n=t.slice(0)),Me=Object.freeze(Object.defineProperties(t,{raw:{value:Object.freeze(n)}
})))),o=a.a.Common.VisualComponent.getAttrs(e,r),i=a.a.Utils.NestingLevel.getNestingLevel(e,Qe),l=Object(c.useDataList)({handlerMap:{load:ee.a.listSubjectsByStudyProgramme,
asignSubject:ee.a.asignSubject,removeSubject:ee.a.removeSubject},itemHandlerMap:{},initialDtoIn:{pageInfo:{},studyProgrammeId:e.studyProgrammeId}}),s=l.state,m=l.data,d=(l.newData,l.pendingData,
l.errorData),p=l.handlerMap,f=Object(c.useRef)(),b=Object(c.useRef)(),g=Object(c.useRef)(),C=Object(c.useCallback)((function(e,t){var n=b.current;n.open({header:"Vyber předmět",
content:a.a.Common.Element.create(Ge,{onSave:t,onSaveDone:function(t){n.close(),t.component.getAlertBus().setAlert({content:e?a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:Ne.modal.onSaveDone.edit
}):a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:Ne.modal.onSaveDone.creation}),colorSchema:"success"})},onSaveFail:function(t){console.debug(t),t.component.getAlertBus().setAlert({
content:e?a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:Ne.modal.onSaveFail.edit}):a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:Ne.modal.onSaveFail.creation}),colorSchema:"danger"})},
onCancel:function(){return n.close()}})})}),[]),v=Object(c.useCallback)((function(){C(null,function(){var t=Ye(regeneratorRuntime.mark((function t(n){var r,o,a,c,i
;return regeneratorRuntime.wrap((function(t){for(;;)switch(t.prev=t.next){case 0:return r=n.component,o=n.values,t.prev=1,i={id:o.subjectId,studyProgrammeId:e.studyProgrammeId,semester:o.semester},
t.next=5,p.asignSubject(i);case 5:a=t.sent,t.next=12;break;case 8:t.prev=8,t.t0=t.catch(1),c=t.t0,console.error(c);case 12:if(!g.current){t.next=14;break}return t.abrupt("return");case 14:
c?r.saveFail(c):r.saveDone(a);case 15:case"end":return t.stop()}}),t,null,[[1,8]])})));return function(e){return t.apply(this,arguments)}}())
}),[C,p.asignSubject,p.load,g]),y=Object(c.useCallback)(function(){var t=Ye(regeneratorRuntime.mark((function t(n){var r,o;return regeneratorRuntime.wrap((function(t){for(;;)switch(t.prev=t.next){
case 0:return t.prev=0,r={id:n,studyProgrammeId:e.studyProgrammeId},t.next=4,p.removeSubject(r);case 4:return t.sent,t.next=7,p.load({studyProgrammeId:e.studyProgrammeId});case 7:t.next=13;break
;case 9:t.prev=9,t.t0=t.catch(0),o=t.t0,console.error(o);case 13:case"end":return t.stop()}}),t,null,[[0,9]])})));return function(e){return t.apply(this,arguments)}
}(),[p.load,g]),O=a.a.Common.Element.create("div",o,a.a.Utils.Content.getChildren(e.children,e,Qe));return i?a.a.Common.Element.create("div",o,a.a.Common.Element.create(a.a.Bricks.Section,{
header:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:Ne.header})},function(){var t;switch(s){case"pendingNoData":case"pending":t=a.a.Common.Element.create(a.a.Bricks.Loading,null);break;case"ready":
case"readyNoData":t=a.a.Common.Element.create(a.a.Common.Fragment,null,a.a.Common.Element.create(qe,{data:m,studyProgrammeId:e.studyProgrammeId,handleSubjectAdd:v,handleSubjectRemove:y}));break
;case"error":case"errorNoData":t=a.a.Common.Element.create(a.a.Common.Error,{errorData:d})}return t}()),a.a.Common.Element.create(a.a.Bricks.AlertBus,{ref_:f
}),a.a.Common.Element.create(a.a.Bricks.Modal,{controlled:!1,ref_:b,mountContent:"onEachOpen",overflow:!0})):a.a.Common.Element.create(a.a.Bricks.LinkModal,{children:"Visual Component",
hidden:e.hidden,component:O})}})),et={};function tt(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter((function(t){
return Object.getOwnPropertyDescriptor(e,t).enumerable}))),n.push.apply(n,r)}return n}function nt(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{}
;t%2?tt(Object(n),!0).forEach((function(t){rt(e,t,n[t])})):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):tt(Object(n)).forEach((function(t){
Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(n,t))}))}return e}function rt(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}
var ot,at={displayName:"UU5.Bricks.VisualComponent",nestingLevel:"bigBoxCollection"},ct=Object(c.createVisualComponent)(nt(nt({},at),{},{propTypes:{},defaultProps:{},render:function(e){
var t,n,r=E.a.Css.css(Ze||(t=[""],n||(n=t.slice(0)),Ze=Object.freeze(Object.defineProperties(t,{raw:{value:Object.freeze(n)}
})))),o=a.a.Common.VisualComponent.getAttrs(e,r),i=a.a.Utils.NestingLevel.getNestingLevel(e,at),l=Object(c.useDataObject)({handlerMap:{load:ee.a.getStudyProgramme},initialDtoIn:{pageInfo:{},
id:e.params.id}}),u=l.state,s=l.data,m=l.errorData,d=(l.pendingData,l.handlerMap,
Object(c.useRef)()),p=Object(c.useRef)(),f=a.a.Common.Element.create("div",o,a.a.Utils.Content.getChildren(e.children,e,at))
;return i?a.a.Common.Element.create("div",o,a.a.Common.Element.create(a.a.Bricks.Section,{header:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:et.header})},function(){var t;switch(u){
case"pendingNoData":case"pending":t=a.a.Common.Element.create(a.a.Bricks.Loading,null);break;case"ready":case"readyNoData":
t=a.a.Common.Element.create(a.a.Common.Fragment,null,a.a.Common.Element.create(Fe,{data:s}),a.a.Common.Element.create(Xe,{studyProgrammeId:e.params.id}));break;case"error":case"errorNoData":
t=a.a.Common.Element.create(a.a.Common.Error,{errorData:m})}return t}()),a.a.Common.Element.create(a.a.Bricks.AlertBus,{ref_:d}),a.a.Common.Element.create(a.a.Bricks.Modal,{controlled:!1,ref_:p,
mountContent:"onEachOpen",overflow:!0})):a.a.Common.Element.create(a.a.Bricks.LinkModal,{children:"Visual Component",hidden:e.hidden,component:f})}}));function it(e,t){var n=Object.keys(e)
;if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter((function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable}))),n.push.apply(n,r)}return n}
function lt(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{};t%2?it(Object(n),!0).forEach((function(t){ut(e,t,n[t])
})):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):it(Object(n)).forEach((function(t){Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(n,t))
}))}return e}function ut(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}var st,mt={displayName:"UU5.Bricks.VisualComponent",
nestingLevel:"bigBoxCollection"},dt=Object(c.createVisualComponent)(lt(lt({},mt),{},{propTypes:{data:a.a.PropTypes.array,handleOpen:a.a.PropTypes.func,handleCreate:a.a.PropTypes.func},defaultProps:{
data:[],handleOpen:function(){},handleCreate:function(){}},render:function(e){var t,n,r=[{cell:function(t){return a.a.Common.Element.create(a.a.Bricks.Link,{onClick:function(){
null==e||e.handleOpen(t.data.data)}},a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:t.data.data.name}))},header:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:{en:"Species",cs:"Název"}})},{
cell:function(e){return a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:e.data.data.credits})},header:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:{en:"Credits",cs:"Kredity"}})},{cell:function(e){
return a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:e.data.data.language})},header:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:{en:"Language",cs:"Jazyk"}})},{cell:function(e){
return a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:e.data.data.guarantor})},header:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:{en:"Guarantor",cs:"Garant"}})}],o=(Object(c.useRef)(),
u.a.Css.css(ot||(t=[""],n||(n=t.slice(0)),ot=Object.freeze(Object.defineProperties(t,{raw:{value:Object.freeze(n)}
}))))),i=a.a.Common.VisualComponent.getAttrs(e,o),l=a.a.Utils.NestingLevel.getNestingLevel(e,mt),s=a.a.Common.Element.create("div",i,a.a.Utils.Content.getChildren(e.children,e,mt))
;return l?a.a.Common.Element.create("div",i,a.a.Common.Element.create(ne.a.ControllerProvider,{data:e.data?e.data:[]},a.a.Common.Element.create(ne.a.ActionBar,{title:"",actions:function(t){
t.screenSize;return[{content:{en:"Add subject",cs:"Přidej předmět"},onClick:function(){null==e||e.handleCreate()},icon:"mdi-plus-circle",colorSchema:"primary",bgStyle:"filled",active:!0}]}
}),a.a.Common.Element.create(ne.a.List,{rowPadding:"4px 16px",tileRowSpacing:8,tileListPadding:"8px 16px",columns:r}))):a.a.Common.Element.create(a.a.Bricks.LinkModal,{children:"Visual Component",
hidden:e.hidden,component:s})}})),pt={header:{cs:"Přídání studijního programu",en:"Add new study programme"},info:{cs:"Přídání studijního programu",en:"Add new study programme"},form:{name:{
cs:"Název",en:"Name"},goal:{cs:"Cíl předmětu",en:"Goal"},languages:{czech:{cs:"Česky",en:"Czech"},english:{cs:"Anglicky",en:"English"},cs:"Vyučovací jazyk",en:"Language"},credits:{
cs:"Počet kreditů za celé studium",en:"Credist per studium"},semester:{cs:"Semestr",en:"Semester"},teachers:{cs:"Učitelé",en:"Teachers"},guarantor:{cs:"Garant",en:"Guarantors"}},submit:{cs:"Přidej",
en:"Add"}},ft=Object(c.createVisualComponentWithRef)({displayName:R.TAG+"SubjectsCreateModal",propTypes:{subject:a.a.PropTypes.object,onSave:a.a.PropTypes.func,onSaveDone:a.a.PropTypes.func,
onSaveFail:a.a.PropTypes.func,onCancel:a.a.PropTypes.func},defaultProps:{subject:null,onSave:function(){},onSaveDone:function(){},onSaveFail:function(){},onCancel:function(){}},render:function(e){
return a.a.Common.Element.create(a.a.Forms.Form,{onSave:e.onSave,onSaveDone:e.onSaveDone,onSaveFail:e.onSaveFail,onCancel:e.onCancel},a.a.Common.Element.create(a.a.Forms.Text,{
label:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:pt.form.name}),name:"name",value:null!=e&&e.subject?null==e?void 0:e.subject.name:void 0,inputAttrs:{maxLength:255},controlled:!1,required:!0
}),a.a.Common.Element.create(a.a.Forms.Text,{label:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:pt.form.goal}),name:"goal",value:null!=e&&e.subject?null==e?void 0:e.subject.goal:void 0,inputAttrs:{
maxLength:255},controlled:!1,required:!0}),a.a.Common.Element.create(a.a.Forms.Select,{label:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:pt.form.languages}),name:"language",
value:null!=e&&e.subject?null==e?void 0:e.subject.language:void 0,required:!0},a.a.Common.Element.create(a.a.Forms.Select.Option,{value:"CZ",content:a.a.Common.Element.create(a.a.Bricks.Lsi,{
lsi:pt.form.languages.czech})}),a.a.Common.Element.create(a.a.Forms.Select.Option,{value:"EN",content:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:pt.form.languages.english})
})),a.a.Common.Element.create(a.a.Forms.Number,{label:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:pt.form.credits}),name:"credits",value:null!=e&&e.subject?null==e?void 0:e.subject.credits:void 0,
min:0,max:300,step:1,valueType:"number",required:!0}),a.a.Common.Element.create(a.a.Forms.TagSelect,{label:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:pt.form.teachers}),name:"teachers",
value:null!=e&&e.subject?null==e?void 0:e.subject.teachers:void 0,allowCustomTags:!0,required:!0}),a.a.Common.Element.create(a.a.Forms.Text,{label:a.a.Common.Element.create(a.a.Bricks.Lsi,{
lsi:pt.form.guarantor}),name:"guarantor",value:null!=e&&e.subject?null==e?void 0:e.subject.guarantor:void 0,inputAttrs:{maxLength:255},controlled:!1,required:!0
}),a.a.Common.Element.create(a.a.Forms.Controls,{controlled:!1}))}}),bt={header:{cs:"Předměty",en:"Subjects"},info:{cs:"Přídání předmětu",en:"Add new subject"},modal:{header:{creation:{
cs:"Přídání předmětu",en:"Subject adding"},edit:{cs:"Editace předmětu",en:"Subject editing"}},onSaveDone:{creation:{cs:"Úspěšně vytvořeno",en:"Successfully created"},edit:{cs:"Úspěšně upraveno",
en:"Successfully edited"}},onSaveFail:{creation:{cs:"Chyba běhěm vytváření",en:"Error has occured during creation"},edit:{cs:"Chyba běhěm editace",en:"Error has occured during editing"}}}}
;function gt(e,t,n,r,o,a,c){try{var i=e[a](c),l=i.value}catch(e){return void n(e)}i.done?t(l):Promise.resolve(l).then(r,o)}function Ct(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){
var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter((function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable}))),n.push.apply(n,r)}return n}function vt(e){
for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{};t%2?Ct(Object(n),!0).forEach((function(t){yt(e,t,n[t])
})):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):Ct(Object(n)).forEach((function(t){Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(n,t))
}))}return e}function yt(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}var Ot,ht={displayName:"UU5.Bricks.VisualComponent",
nestingLevel:"bigBoxCollection"},jt=Object(c.createVisualComponent)(vt(vt({},ht),{},{propTypes:{},defaultProps:{},render:function(e){var t,n,r=E.a.Css.css(st||(t=[""],n||(n=t.slice(0)),
st=Object.freeze(Object.defineProperties(t,{raw:{value:Object.freeze(n)}})))),o=a.a.Common.VisualComponent.getAttrs(e,r),i=a.a.Utils.NestingLevel.getNestingLevel(e,ht),l=Object(c.useDataList)({
handlerMap:{load:ee.a.listSubjects,createItem:ee.a.createSubject},itemHandlerMap:{},initialDtoIn:{pageInfo:{}}}),u=l.state,s=l.data,m=(l.newData,l.pendingData,
l.errorData),d=l.handlerMap,p=Object(c.useRef)(),f=Object(c.useRef)(),b=Object(c.useRef)(),g=function(e){a.a.Environment.setRoute("subjectDetail",{id:e.id})},C=Object(c.useCallback)((function(e,t){
var n=f.current;n.open({header:e?a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:bt.modal.header.edit}):a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:bt.modal.header.creation}),
content:a.a.Common.Element.create(ft,{onSave:t,onSaveDone:function(t){n.close(),t.component.getAlertBus().setAlert({content:e?a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:bt.modal.onSaveDone.edit
}):a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:bt.modal.onSaveDone.creation}),colorSchema:"success"})},onSaveFail:function(t){console.debug(t),t.component.getAlertBus().setAlert({
content:e?a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:bt.modal.onSaveFail.edit}):a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:bt.modal.onSaveFail.creation}),colorSchema:"danger"})},
onCancel:function(){return n.close()},subject:e})})}),[]),v=Object(c.useCallback)((function(){C(null,function(){var e,t=(e=regeneratorRuntime.mark((function e(t){var n,r,o,a
;return regeneratorRuntime.wrap((function(e){for(;;)switch(e.prev=e.next){case 0:return n=t.component,r=t.values,e.prev=1,e.next=4,d.createItem(r);case 4:o=e.sent,e.next=11;break;case 7:e.prev=7,
e.t0=e.catch(1),a=e.t0,console.error(a);case 11:if(!b.current){e.next=13;break}return e.abrupt("return");case 13:a?n.saveFail(a):n.saveDone(o);case 14:case"end":return e.stop()}}),e,null,[[1,7]])})),
function(){var t=this,n=arguments;return new Promise((function(r,o){var a=e.apply(t,n);function c(e){gt(a,r,o,c,i,"next",e)}function i(e){gt(a,r,o,c,i,"throw",e)}c(void 0)}))});return function(e){
return t.apply(this,arguments)}}())}),[C,d.createItem,d.load,b]),y=a.a.Common.Element.create("div",o,a.a.Utils.Content.getChildren(e.children,e,ht))
;return i?a.a.Common.Element.create("div",o,a.a.Common.Element.create(a.a.Bricks.Section,{header:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:bt.header})},function(){var e;switch(u){
case"pendingNoData":case"pending":e=a.a.Common.Element.create(a.a.Bricks.Loading,null);break;case"ready":case"readyNoData":
e=a.a.Common.Element.create(a.a.Common.Fragment,null,a.a.Common.Element.create(dt,{data:s,handleOpen:g,handleCreate:v}));break;case"error":case"errorNoData":
e=a.a.Common.Element.create(a.a.Common.Error,{errorData:m})}return e}()),a.a.Common.Element.create(a.a.Bricks.AlertBus,{ref_:p}),a.a.Common.Element.create(a.a.Bricks.Modal,{controlled:!1,ref_:f,
mountContent:"onEachOpen",overflow:!0})):a.a.Common.Element.create(a.a.Bricks.LinkModal,{children:"Visual Component",hidden:e.hidden,component:y})}}));var kt,Et=function(){
return u.a.Css.css(Ot||(e=["\n  margin: 0 24px;\n  padding: 6px\n"],t||(t=e.slice(0)),Ot=Object.freeze(Object.defineProperties(e,{raw:{value:Object.freeze(t)}}))));var e,t};function Pt(e,t){
var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter((function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable}))),n.push.apply(n,r)}
return n}function wt(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{};t%2?Pt(Object(n),!0).forEach((function(t){Bt(e,t,n[t])
})):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):Pt(Object(n)).forEach((function(t){Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(n,t))
}))}return e}function Bt(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}var St,Lt={displayName:"UU5.Bricks.VisualComponent",
nestingLevel:"bigBoxCollection"},Dt=Object(c.createVisualComponent)(wt(wt({},Lt),{},{propTypes:{data:a.a.PropTypes.object},defaultProps:{data:null},render:function(e){
var t,n,r,o=u.a.Css.css(kt||(n=[""],r||(r=n.slice(0)),kt=Object.freeze(Object.defineProperties(n,{raw:{value:Object.freeze(r)}
})))),c=a.a.Common.VisualComponent.getAttrs(e,o),i=a.a.Utils.NestingLevel.getNestingLevel(e,Lt),l=a.a.Common.Element.create("div",c,a.a.Utils.Content.getChildren(e.children,e,Lt))
;return i?a.a.Common.Element.create("div",c,a.a.Common.Element.create(a.a.Bricks.Card,{className:Et()},a.a.Common.Element.create(a.a.Bricks.Section,{header:null===(t=e.data)||void 0===t?void 0:t.name,
underline:!0,level:2},a.a.Common.Element.create(a.a.BlockLayout.Block,null,a.a.Common.Element.create(a.a.BlockLayout.Row,null,a.a.Common.Element.create(a.a.BlockLayout.Column,{width:300
},"Name"),a.a.Common.Element.create(a.a.BlockLayout.Column,{textAlign:"left"},e.data.name)),a.a.Common.Element.create(a.a.BlockLayout.Row,null,a.a.Common.Element.create(a.a.BlockLayout.Column,{
width:300},"Goal"),a.a.Common.Element.create(a.a.BlockLayout.Column,{textAlign:"left"
},e.data.goal)),a.a.Common.Element.create(a.a.BlockLayout.Line,null),a.a.Common.Element.create(a.a.BlockLayout.Row,null,a.a.Common.Element.create(a.a.BlockLayout.Column,{width:300
},"Credits"),a.a.Common.Element.create(a.a.BlockLayout.Column,{textAlign:"left"},e.data.credits)),a.a.Common.Element.create(a.a.BlockLayout.Row,null,a.a.Common.Element.create(a.a.BlockLayout.Column,{
width:300},"Language"),a.a.Common.Element.create(a.a.BlockLayout.Column,{textAlign:"left"
},e.data.language)),a.a.Common.Element.create(a.a.BlockLayout.Row,null,a.a.Common.Element.create(a.a.BlockLayout.Column,{width:300},"Teachers"),a.a.Common.Element.create(a.a.BlockLayout.Column,{
textAlign:"left"},e.data.teachers)),a.a.Common.Element.create(a.a.BlockLayout.Line,null),a.a.Common.Element.create(a.a.BlockLayout.Row,null,a.a.Common.Element.create(a.a.BlockLayout.Column,{width:300
},"Guarantor"),a.a.Common.Element.create(a.a.BlockLayout.Column,{textAlign:"left"
},e.data.guarantor)),a.a.Common.Element.create(a.a.BlockLayout.Line,null),a.a.Common.Element.create(a.a.BlockLayout.Row,null,a.a.Common.Element.create(a.a.BlockLayout.Column,{width:300
},"State"),a.a.Common.Element.create(a.a.BlockLayout.Column,{textAlign:"left"},e.data.state)))))):a.a.Common.Element.create(a.a.Bricks.LinkModal,{children:"Visual Component",hidden:e.hidden,
component:l})}})),xt={header:{cs:"Předměty",en:"Subjects"},info:{cs:"Přídání předmětu",en:"Add new subject"}},At={header:{cs:"Témata",en:"Topics"},info:{cs:"Přídání téma",en:"Add new topic"},modal:{
header:{creation:{cs:"Vytvoření tématu",en:"Creation of topic"},edit:{cs:"Editace tématu",en:"Edit of topic"}},onSaveDone:{creation:{cs:"Úspěšně vytvořeno",en:"Successfully created"},edit:{
cs:"Úspěšně upraveno",en:"Successfully edited"}},onSaveFail:{creation:{cs:"Chyba běhěm vytváření",en:"Error has occured during creation"},edit:{cs:"Chyba běhěm editace",
en:"Error has occured during editing"}}}},Tt={menuActions:{editProgramme:{cs:"Edituj stud. program",en:"Edit programme"},addDigitalContent:{cs:"test",en:"Add digital content"}},tile:{header:{
cs:"Téma",en:"Topic"},name:{cs:"Název: ",en:"Name: "}}};function Rt(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter((function(t){
return Object.getOwnPropertyDescriptor(e,t).enumerable}))),n.push.apply(n,r)}return n}function Ut(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{}
;t%2?Rt(Object(n),!0).forEach((function(t){Ft(e,t,n[t])})):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):Rt(Object(n)).forEach((function(t){
Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(n,t))}))}return e}function Ft(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}
var Nt,zt={displayName:"UU5.Bricks.VisualComponent",nestingLevel:"bigBoxCollection"},_t=Object(c.createVisualComponent)(Ut(Ut({},zt),{},{propTypes:{data:a.a.PropTypes.object,
handleOpen:a.a.PropTypes.func,handleUpdate:a.a.PropTypes.func,handleDigitalContentAdd:a.a.PropTypes.func,handleDigitalContentRemove:a.a.PropTypes.func},defaultProps:{data:null,handleOpen:function(){},
handleUpdate:function(){},handleDigitalContentAdd:function(){},handleDigitalContentRemove:function(){}},render:function(e){var t,n,r,o,c,i=[{icon:"mdi-plus",content:"Přidej",onClick:function(){
return e.handleDigitalContentAdd(e.data)}}],l=u.a.Css.css(St||(o=[""],c||(c=o.slice(0)),St=Object.freeze(Object.defineProperties(o,{raw:{value:Object.freeze(c)}
})))),s=a.a.Common.VisualComponent.getAttrs(e,l),m=a.a.Utils.NestingLevel.getNestingLevel(e,zt),d=a.a.Common.Element.create("div",s,a.a.Utils.Content.getChildren(e.children,e,zt))
;return m?a.a.Common.Element.create("div",s,a.a.Common.Element.create(a.a.BlockLayout.Tile,null,a.a.Common.Element.create(a.a.BlockLayout.Block,{actions:i
},a.a.Common.Element.create(a.a.BlockLayout.Row,{weight:"primary"},a.a.Common.Element.create(a.a.BlockLayout.Column,{width:150},a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:Tt.tile.name
})),a.a.Common.Element.create(a.a.BlockLayout.Column,{width:150
},null===(t=e.data.data)||void 0===t?void 0:t.name))),a.a.Common.Element.create(a.a.BlockLayout.Line,null),a.a.Common.Element.create(a.a.BlockLayout.Block,null,null===(n=e.data.data)||void 0===n||null===(r=n.digitalContents)||void 0===r?void 0:r.map((function(t){
return a.a.Common.Element.create(a.a.BlockLayout.Row,null,a.a.Common.Element.create(a.a.BlockLayout.Column,{width:200},t.name),a.a.Common.Element.create(a.a.BlockLayout.Column,{width:200
},a.a.Common.Element.create(a.a.Bricks.Link,{href:t.link,target:"_blank"},"odkaz")),(function(){
return"video"===t.type?a.a.Common.Element.create(a.a.Common.Fragment,null,a.a.Common.Element.create(a.a.BlockLayout.Column,null,a.a.Common.Element.create(a.a.Bricks.Icon,{icon:"plus4u-video"
})),a.a.Common.Element.create(a.a.BlockLayout.Column,null,a.a.Common.Element.create(a.a.Bricks.YoutubeVideo,{src:t.link
}))):"youtube"===t.type?a.a.Common.Element.create(a.a.Common.Fragment,null,a.a.Common.Element.create(a.a.BlockLayout.Column,null,a.a.Common.Element.create(a.a.Bricks.Icon,{icon:"plus4u-video"
})),a.a.Common.Element.create(a.a.BlockLayout.Column,null,a.a.Common.Element.create(a.a.Bricks.YoutubeVideo,{size:"xs",src:t.link
}))):"uuBook"===t.type?a.a.Common.Element.create(a.a.Common.Fragment,null,a.a.Common.Element.create(a.a.BlockLayout.Column,null,a.a.Common.Element.create(a.a.Bricks.Icon,{icon:"plus4u-book"
}))):"uuCourse"===t.type?a.a.Common.Element.create(a.a.Common.Fragment,null,a.a.Common.Element.create(a.a.BlockLayout.Column,null,a.a.Common.Element.create(a.a.Bricks.Icon,{icon:"plus4u-do-it"
}))):"link"===t.type?a.a.Common.Element.create(a.a.Common.Fragment,null,a.a.Common.Element.create(a.a.BlockLayout.Column,null,a.a.Common.Element.create(a.a.Bricks.Icon,{icon:"plus4u-link"
}))):a.a.Common.Element.create(a.a.Bricks.Icon,{icon:"plus4u5-close"})}),a.a.Common.Element.create(a.a.BlockLayout.Column,{width:150},a.a.Common.Element.create(a.a.Bricks.Button,{onClick:function(){
null==e||e.handleDigitalContentRemove(e.data,t.id)}},"Odstraň")))}))))):a.a.Common.Element.create(a.a.Bricks.LinkModal,{children:"Visual Component",hidden:e.hidden,component:d})}}));function Vt(e,t){
var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter((function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable}))),n.push.apply(n,r)}
return n}function Mt(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{};t%2?Vt(Object(n),!0).forEach((function(t){It(e,t,n[t])
})):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):Vt(Object(n)).forEach((function(t){Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(n,t))
}))}return e}function It(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}var qt,Wt={displayName:"UU5.Bricks.VisualComponent",
nestingLevel:"bigBoxCollection"},Gt=Object(c.createVisualComponent)(Mt(Mt({},Wt),{},{propTypes:{data:a.a.PropTypes.array,handleTopicAdd:a.a.PropTypes.func,handleDigitalContentAdd:a.a.PropTypes.func,
handleDigitalContentRemove:a.a.PropTypes.func},defaultProps:{data:[],handleTopicAdd:function(){},handleDigitalContentAdd:function(){},handleDigitalContentRemove:function(){}},render:function(e){
a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:{en:"Species",cs:"Název"}}),Object(c.useRef)();var t,n,r,o=u.a.Css.css(Nt||(n=[""],r||(r=n.slice(0)),Nt=Object.freeze(Object.defineProperties(n,{raw:{
value:Object.freeze(r)}
})))),i=a.a.Common.VisualComponent.getAttrs(e,o),l=a.a.Utils.NestingLevel.getNestingLevel(e,Wt),s=a.a.Common.Element.create("div",i,a.a.Utils.Content.getChildren(e.children,e,Wt))
;return l?a.a.Common.Element.create("div",i,a.a.Common.Element.create(ne.a.ControllerProvider,{data:e.data?e.data:[]},a.a.Common.Element.create(ne.a.ActionBar,{title:"",actions:function(t){
t.screenSize;return[{content:{en:"Add topic",cs:"Přidej téma"},onClick:function(){null==e||e.handleTopicAdd()},icon:"mdi-plus-circle",colorSchema:"primary",bgStyle:"filled",active:!0}]}
}),a.a.Common.Element.create(ne.a.Grid,{tileMinWidth:400,tileMaxWidth:1e3,tileSpacing:8,rowSpacing:8},a.a.Common.Element.create(_t,{key:null===(t=e.data)||void 0===t?void 0:t.id,
handleOpen:e.handleOpen,handleUpdate:e.handleUpdate,handleDigitalContentAdd:e.handleDigitalContentAdd,handleDigitalContentRemove:e.handleDigitalContentRemove
})))):a.a.Common.Element.create(a.a.Bricks.LinkModal,{children:"Visual Component",hidden:e.hidden,component:s})}})),Ht={header:{cs:"Přídání tématu",en:"Add digital content"},info:{cs:"Přídání tématu",
en:"Add digital content"},form:{name:{cs:"Název",en:"Name"},description:{cs:"Popis",en:"Description"}},submit:{cs:"Přidej",en:"Add"}},Yt=Object(c.createVisualComponentWithRef)({
displayName:R.TAG+"DigitalContentCreateModal",propTypes:{onSave:a.a.PropTypes.func,onSaveDone:a.a.PropTypes.func,onSaveFail:a.a.PropTypes.func,onCancel:a.a.PropTypes.func},defaultProps:{
onSave:function(){},onSaveDone:function(){},onSaveFail:function(){},onCancel:function(){}},render:function(e){return a.a.Common.Element.create(a.a.Forms.Form,{onSave:e.onSave,onSaveDone:e.onSaveDone,
onSaveFail:e.onSaveFail,onCancel:e.onCancel},a.a.Common.Element.create(a.a.Forms.Text,{label:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:Ht.form.name}),name:"name",value:"",inputAttrs:{maxLength:255
},controlled:!1,required:!0}),a.a.Common.Element.create(a.a.Forms.Text,{label:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:Ht.form.description}),name:"description",value:"",inputAttrs:{maxLength:255
},controlled:!1,required:!0}),a.a.Common.Element.create(a.a.Forms.Controls,{controlled:!1}))}}),Kt={header:{cs:"Přídání digitálního obsahu",en:"Add digital content"},info:{
cs:"Přídání digitálního obsahu",en:"Add digital content"},form:{name:{cs:"Název",en:"Name"},link:{cs:"Odkaz",en:"link"},types:{video:{cs:"Video",en:"Video"},youtube:{cs:"Youtube",en:"Youtube"},link:{
cs:"Odkaz",en:"Link"},uuCourse:{cs:"uuCourse",en:"uuCourse"},uuBook:{cs:"uuBook",en:"uuBook"},cs:"Typ obsahu",en:"Content type"}},submit:{cs:"Přidej",en:"Add"}
},$t=Object(c.createVisualComponentWithRef)({displayName:R.TAG+"DigitalContentCreateModal",propTypes:{onSave:a.a.PropTypes.func,onSaveDone:a.a.PropTypes.func,onSaveFail:a.a.PropTypes.func,
onCancel:a.a.PropTypes.func},defaultProps:{onSave:function(){},onSaveDone:function(){},onSaveFail:function(){},onCancel:function(){}},render:function(e){
return a.a.Common.Element.create(a.a.Forms.Form,{onSave:e.onSave,onSaveDone:e.onSaveDone,onSaveFail:e.onSaveFail,onCancel:e.onCancel},a.a.Common.Element.create(a.a.Forms.Text,{
label:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:Kt.form.name}),name:"name",value:"",inputAttrs:{maxLength:255},controlled:!1,required:!0}),a.a.Common.Element.create(a.a.Forms.Text,{
label:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:Kt.form.link}),name:"link",value:"",inputAttrs:{maxLength:255},controlled:!1,required:!0}),a.a.Common.Element.create(a.a.Forms.Select,{
label:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:Kt.form.types}),name:"type",value:"",required:!0},a.a.Common.Element.create(a.a.Forms.Select.Option,{value:"video",
content:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:Kt.form.types.video})}),a.a.Common.Element.create(a.a.Forms.Select.Option,{value:"youtube",content:a.a.Common.Element.create(a.a.Bricks.Lsi,{
lsi:Kt.form.types.youtube})}),a.a.Common.Element.create(a.a.Forms.Select.Option,{value:"link",content:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:Kt.form.types.link})
}),a.a.Common.Element.create(a.a.Forms.Select.Option,{value:"uuCourse",content:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:Kt.form.types.uuCourse})
}),a.a.Common.Element.create(a.a.Forms.Select.Option,{value:"uuBook",content:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:Kt.form.types.uuBook})})),a.a.Common.Element.create(a.a.Forms.Controls,{
controlled:!1}))}});function Jt(e,t,n,r,o,a,c){try{var i=e[a](c),l=i.value}catch(e){return void n(e)}i.done?t(l):Promise.resolve(l).then(r,o)}function Zt(e){return function(){var t=this,n=arguments
;return new Promise((function(r,o){var a=e.apply(t,n);function c(e){Jt(a,r,o,c,i,"next",e)}function i(e){Jt(a,r,o,c,i,"throw",e)}c(void 0)}))}}function Qt(e,t){var n=Object.keys(e)
;if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter((function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable}))),n.push.apply(n,r)}return n}
function Xt(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{};t%2?Qt(Object(n),!0).forEach((function(t){en(e,t,n[t])
})):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):Qt(Object(n)).forEach((function(t){Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(n,t))
}))}return e}function en(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}var tn,nn={displayName:"UU5.Bricks.VisualComponent",
nestingLevel:"bigBoxCollection"},rn=Object(c.createVisualComponent)(Xt(Xt({},nn),{},{propTypes:{subjectId:a.a.PropTypes.string},defaultProps:{subjectId:""},render:function(e){
var t,n,r=u.a.Css.css(qt||(t=[""],n||(n=t.slice(0)),qt=Object.freeze(Object.defineProperties(t,{raw:{value:Object.freeze(n)}
})))),o=a.a.Common.VisualComponent.getAttrs(e,r),i=a.a.Utils.NestingLevel.getNestingLevel(e,nn),l=Object(c.useDataList)({handlerMap:{load:ee.a.listTopicsInSubject,addTopic:ee.a.addTopic,
addDigitalContent:ee.a.addDigitalContent,removeDigitalContent:ee.a.removeDigitalContent},itemHandlerMap:{},initialDtoIn:{pageInfo:{},subjectId:e.subjectId}}),s=l.state,m=l.data,d=(l.newData,
l.pendingData,l.errorData),p=l.handlerMap,f=Object(c.useRef)(),b=Object(c.useRef)(),g=Object(c.useRef)(),C=Object(c.useCallback)((function(e){var t=b.current;t.open({header:"Přidej téma",
content:a.a.Common.Element.create(Yt,{onSave:e,onSaveDone:function(e){t.close(),e.component.getAlertBus().setAlert({content:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:At.modal.onSaveDone.creation
}),colorSchema:"success"})},onSaveFail:function(e){console.debug(e),e.component.getAlertBus().setAlert({content:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:At.modal.onSaveFail.creation}),
colorSchema:"danger"})},onCancel:function(){return t.close()}})})}),[]),v=Object(c.useCallback)((function(t){C(function(){var t=Zt(regeneratorRuntime.mark((function t(n){var r,o,a,c,i
;return regeneratorRuntime.wrap((function(t){for(;;)switch(t.prev=t.next){case 0:return r=n.component,o=n.values,i=Xt(Xt({},o),{},{subjectId:e.subjectId}),t.prev=2,t.next=5,p.addTopic(i);case 5:
a=t.sent,t.next=12;break;case 8:t.prev=8,t.t0=t.catch(2),c=t.t0,console.error(c);case 12:if(!g.current){t.next=14;break}return t.abrupt("return");case 14:c?r.saveFail(c):r.saveDone(a);case 15:
case"end":return t.stop()}}),t,null,[[2,8]])})));return function(e){return t.apply(this,arguments)}}())}),[C,p.addTopic,p.load,g]),y=Object(c.useCallback)((function(e){var t=b.current;t.open({
header:"Přidej digitální obsah",content:a.a.Common.Element.create($t,{onSave:e,onSaveDone:function(e){t.close(),e.component.getAlertBus().setAlert({content:a.a.Common.Element.create(a.a.Bricks.Lsi,{
lsi:At.modal.onSaveDone.creation}),colorSchema:"success"})},onSaveFail:function(e){console.debug(e),e.component.getAlertBus().setAlert({content:a.a.Common.Element.create(a.a.Bricks.Lsi,{
lsi:At.modal.onSaveFail.creation}),colorSchema:"danger"})},onCancel:function(){return t.close()}})})}),[]),O=Object(c.useCallback)((function(e){y(function(){
var t=Zt(regeneratorRuntime.mark((function t(n){var r,o,a,c,i;return regeneratorRuntime.wrap((function(t){for(;;)switch(t.prev=t.next){case 0:return r=n.component,o=n.values,i=Xt(Xt({},o),{},{
id:e.data.id}),t.prev=2,t.next=5,p.addDigitalContent(i);case 5:a=t.sent,t.next=12;break;case 8:t.prev=8,t.t0=t.catch(2),c=t.t0,console.error(c);case 12:if(!g.current){t.next=14;break}
return t.abrupt("return");case 14:c?r.saveFail(c):r.saveDone(a);case 15:case"end":return t.stop()}}),t,null,[[2,8]])})));return function(e){return t.apply(this,arguments)}}())
}),[y,p.addDigitalContent,p.load,g]),h=Object(c.useCallback)(function(){var t=Zt(regeneratorRuntime.mark((function t(n,r){var o,a;return regeneratorRuntime.wrap((function(t){
for(;;)switch(t.prev=t.next){case 0:return t.prev=0,o={id:n.data.id,digitalContentId:r},t.next=4,p.removeDigitalContent(o);case 4:return t.sent,t.next=7,p.load({subjectId:e.subjectId});case 7:
t.next=13;break;case 9:t.prev=9,t.t0=t.catch(0),a=t.t0,console.error(a);case 13:case"end":return t.stop()}}),t,null,[[0,9]])})));return function(e,n){return t.apply(this,arguments)}
}(),[p.load]),j=a.a.Common.Element.create("div",o,a.a.Utils.Content.getChildren(e.children,e,nn));return i?a.a.Common.Element.create("div",o,a.a.Common.Element.create(a.a.Bricks.Section,{
header:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:At.header})},function(){var e;switch(s){case"pendingNoData":case"pending":e=a.a.Common.Element.create(a.a.Bricks.Loading,null);break;case"ready":
case"readyNoData":e=a.a.Common.Element.create(a.a.Common.Fragment,null,a.a.Common.Element.create(Gt,{data:m,handleTopicAdd:v,handleDigitalContentAdd:O,handleDigitalContentRemove:h}));break
;case"error":case"errorNoData":e=a.a.Common.Element.create(a.a.Common.Error,{errorData:d})}return e}()),a.a.Common.Element.create(a.a.Bricks.AlertBus,{ref_:f
}),a.a.Common.Element.create(a.a.Bricks.Modal,{controlled:!1,ref_:b,mountContent:"onEachOpen",overflow:!0})):a.a.Common.Element.create(a.a.Bricks.LinkModal,{children:"Visual Component",
hidden:e.hidden,component:j})}}));function on(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter((function(t){
return Object.getOwnPropertyDescriptor(e,t).enumerable}))),n.push.apply(n,r)}return n}function an(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{}
;t%2?on(Object(n),!0).forEach((function(t){cn(e,t,n[t])})):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):on(Object(n)).forEach((function(t){
Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(n,t))}))}return e}function cn(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}
var ln={displayName:"UU5.Bricks.VisualComponent",nestingLevel:"bigBoxCollection"},un=Object(c.createVisualComponent)(an(an({},ln),{},{propTypes:{},defaultProps:{},render:function(e){
var t,n,r=E.a.Css.css(tn||(t=[""],n||(n=t.slice(0)),tn=Object.freeze(Object.defineProperties(t,{raw:{value:Object.freeze(n)}
})))),o=a.a.Common.VisualComponent.getAttrs(e,r),i=a.a.Utils.NestingLevel.getNestingLevel(e,ln),l=Object(c.useDataObject)({handlerMap:{load:ee.a.getSubject},initialDtoIn:{pageInfo:{},id:e.params.id}
}),u=l.state,s=l.data,m=l.errorData,d=(l.pendingData,l.handlerMap,Object(c.useRef)()),p=Object(c.useRef)(),f=a.a.Common.Element.create("div",o,a.a.Utils.Content.getChildren(e.children,e,ln))
;return i?a.a.Common.Element.create("div",o,a.a.Common.Element.create(a.a.Bricks.Section,{header:a.a.Common.Element.create(a.a.Bricks.Lsi,{lsi:xt.header})},function(){var t;switch(u){
case"pendingNoData":case"pending":t=a.a.Common.Element.create(a.a.Bricks.Loading,null);break;case"ready":case"readyNoData":
t=a.a.Common.Element.create(a.a.Common.Fragment,null,a.a.Common.Element.create(Dt,{data:s}),a.a.Common.Element.create(rn,{subjectId:e.params.id}));break;case"error":case"errorNoData":
t=a.a.Common.Element.create(a.a.Common.Error,{errorData:m})}return t}()),a.a.Common.Element.create(a.a.Bricks.AlertBus,{ref_:d}),a.a.Common.Element.create(a.a.Bricks.Modal,{controlled:!1,ref_:p,
mountContent:"onEachOpen",overflow:!0})):a.a.Common.Element.create(a.a.Bricks.LinkModal,{children:"Visual Component",hidden:e.hidden,component:f})}}));function sn(){
return(sn=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var n=arguments[t];for(var r in n)Object.prototype.hasOwnProperty.call(n,r)&&(e[r]=n[r])}return e}).apply(this,arguments)}
function mn(e,t){return function(e){if(Array.isArray(e))return e}(e)||function(e,t){var n=null==e?null:"undefined"!=typeof Symbol&&e[Symbol.iterator]||e["@@iterator"];if(null==n)return
;var r,o,a=[],c=!0,i=!1;try{for(n=n.call(e);!(c=(r=n.next()).done)&&(a.push(r.value),!t||a.length!==t);c=!0);}catch(e){i=!0,o=e}finally{try{c||null==n.return||n.return()}finally{if(i)throw o}}return a
}(e,t)||function(e,t){if(!e)return;if("string"==typeof e)return dn(e,t);var n=Object.prototype.toString.call(e).slice(8,-1);"Object"===n&&e.constructor&&(n=e.constructor.name)
;if("Map"===n||"Set"===n)return Array.from(e);if("Arguments"===n||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n))return dn(e,t)}(e,t)||function(){
throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")}()}function dn(e,t){
(null==t||t>e.length)&&(t=e.length);for(var n=0,r=new Array(t);n<t;n++)r[n]=e[n];return r}function pn(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e)
;t&&(r=r.filter((function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable}))),n.push.apply(n,r)}return n}function fn(e){for(var t=1;t<arguments.length;t++){
var n=null!=arguments[t]?arguments[t]:{};t%2?pn(Object(n),!0).forEach((function(t){bn(e,t,n[t])
})):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):pn(Object(n)).forEach((function(t){Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(n,t))
}))}return e}function bn(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}var gn,Cn={displayName:u.a.TAG+"SpaAuthenticated"
},vn=a.a.Common.Component.lazy((function(){return n.e(0).then(n.bind(null,26))})),yn=a.a.Common.Component.lazy((function(){return n.e(0).then(n.bind(null,25))
})),On=a.a.Common.Component.lazy((function(){return n.e(0).then(n.bind(null,24))})),hn={"":"home",home:{component:a.a.Common.Element.create(Z,null)},studyProgrammes:{
component:a.a.Common.Element.create(Se,null)},studyProgrammeDetail:{component:a.a.Common.Element.create(ct,null),params:{id:""}},subjectsList:{component:a.a.Common.Element.create(jt,null)},
subjectDetail:{component:a.a.Common.Element.create(un,null)},about:{component:a.a.Common.Element.create(vn,null)},"sys/uuAppWorkspace/initUve":{component:a.a.Common.Element.create(yn,null)},
controlPanel:{component:a.a.Common.Element.create(On,null)}},jn=Object(c.createVisualComponent)(fn(fn({},Cn),{},{render:function(e){var t=mn(Object(c.useState)((function(){
return a.a.Common.Url.parse(window.location.href).useCase||"home"})),1)[0];return a.a.Common.Element.create(l.a.App.MenuProvider,{activeItemId:t},a.a.Common.Element.create(l.a.App.Page,sn({},e,{
top:a.a.Common.Element.create(l.a.App.TopBt,null),topFixed:"smart",bottom:a.a.Common.Element.create(k,null),type:3,displayedLanguages:["cs","en"],left:a.a.Common.Element.create(C,null),
leftWidth:"!xs-300px !s-300px !m-288px !l-288px !xl-288px",leftFixed:!0,leftRelative:"m l xl",leftResizable:"m l xl",leftResizableMinWidth:220,leftResizableMaxWidth:500,isLeftOpen:"m l xl",
showLeftToggleButton:!0,fullPage:!0}),a.a.Common.Element.create(l.a.App.MenuConsumer,null,(function(e){var t=e.setActiveItemId;return a.a.Common.Element.create(a.a.Common.Router,{routes:hn,
controlled:!1,onRouteChanged:function(e){var n=e.useCase;e.parameters;return t(n||"home")}})}))))}}));function kn(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){
var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter((function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable}))),n.push.apply(n,r)}return n}function En(e){
for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{};t%2?kn(Object(n),!0).forEach((function(t){Pn(e,t,n[t])
})):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):kn(Object(n)).forEach((function(t){Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(n,t))
}))}return e}function Pn(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}function wn(e,t){return t||(t=e.slice(0)),
Object.freeze(Object.defineProperties(e,{raw:{value:Object.freeze(t)}}))}var Bn={displayName:u.a.TAG+"SpaUnauthorized"},Sn=function(){
return u.a.Css.css(gn||(gn=wn(["\n    width: 390px;\n    max-width: 100%;\n    margin: 56px auto 0;\n    text-align: center;\n  "])))};Object(c.createVisualComponent)(En(En({},Bn),{},{
render:function(e){e.children;var t=a.a.Common.VisualComponent.getAttrs(e,Sn());return a.a.Common.Element.create("div",t,a.a.Common.Element.create("p",null,"Hi"))}}));function Ln(){
return(Ln=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var n=arguments[t];for(var r in n)Object.prototype.hasOwnProperty.call(n,r)&&(e[r]=n[r])}return e}).apply(this,arguments)}
function Dn(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter((function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable}))),
n.push.apply(n,r)}return n}function xn(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{};t%2?Dn(Object(n),!0).forEach((function(t){An(e,t,n[t])
})):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):Dn(Object(n)).forEach((function(t){Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(n,t))
}))}return e}function An(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}var Tn={displayName:u.a.TAG+"Spa"
},Rn=Object(c.createVisualComponent)(xn(xn({},Tn),{},{render:function(e){return a.a.Common.Element.create(l.a.App.Spa,Ln({},e,{appName:"uuSubject"}),a.a.Common.Element.create(jn,null))}}))
;if(a.a.Environment.appVersion="0.2.0",!navigator.userAgent.match(/iPhone|iPad|iPod/)){var Un=document.createElement("link");Un.rel="manifest",Un.href="assets/manifest.json",
document.head.appendChild(Un)}function Fn(e){e,a.a.Common.DOM.render(a.a.Common.Element.create(r.AppContainer,null,a.a.Common.Element.create(Rn,null)),document.getElementById(e))}},function(e,t){
e.exports=s},function(e,t){e.exports=m},function(e,t){e.exports=d},function(e,t){e.exports=p}])}));