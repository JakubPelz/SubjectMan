export default {
    header: {
        cs: "Předměty",
        en: "Subjects",
    },
    info: {
        cs: "Přídání předmětu",
        en: "Add new subject",
    }
}