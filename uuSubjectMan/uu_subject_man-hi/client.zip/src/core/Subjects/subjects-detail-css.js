import Config from "../config/config";

const subjectsDetail = () => Config.Css.css`
  margin: 0 24px;
  padding: 6px
`;

export default {
  subjectsDetail
  };