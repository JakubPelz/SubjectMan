import Config from "../config/config";

const studyProgrammeDetail = () => Config.Css.css`
  margin: 0 24px;
  padding: 6px
`;

export default {
    studyProgrammeDetail
  };