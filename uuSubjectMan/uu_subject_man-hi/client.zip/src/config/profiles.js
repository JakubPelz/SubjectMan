// This file was auto-generated according to the "namespace" setting in package.json.
// Manual changes to this file are discouraged, if values are inconsistent with package.json setting.
import UU5 from "uu5g04";

const TAG = "UuSubjectMan.";

export default {
  TAG,
  TEACHERS: "Teachers",
  STUDYDEP: "StudyCoordinators",
  STUDENS: "Students",
  AUTHORITIES: "Authorities"
};
