export default {
    header: {
        cs: "Přídání digitálního obsahu",
        en: "Add digital content",
    },
    info: {
        cs: "Přídání digitálního obsahu",
        en: "Add digital content",
    },
    form: {
        name:{
            cs: "Název",
            en: "Name"
        },
        link:{
            cs:"Odkaz",
            en:"link"
        },
        types:{
            video:{
                cs:"Video",
                en:"Video"
            },
            youtube:{
                cs:"Youtube",
                en:"Youtube"
            },
            link:{
                cs:"Odkaz",
                en:"Link"
            },
            uuCourse:{
                cs:"uuCourse",
                en:"uuCourse"
            },
            uuBook:{
                cs:"uuBook",
                en:"uuBook"
            },
            cs:"Typ obsahu",
            en:"Content type"
        }
    },
    submit: {
        cs: "Přidej",
        en: "Add",
    }
};
