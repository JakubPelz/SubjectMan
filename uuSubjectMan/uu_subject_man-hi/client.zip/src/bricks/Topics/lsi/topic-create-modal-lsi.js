export default {
    header: {
        cs: "Přídání tématu",
        en: "Add digital content",
    },
    info: {
        cs: "Přídání tématu",
        en: "Add digital content",
    },
    form: {
        name:{
            cs: "Název",
            en: "Name"
        },
        description:{
            cs: "Popis",
            en: "Description"
        },
    },
    submit: {
        cs: "Přidej",
        en: "Add",
    }
};
